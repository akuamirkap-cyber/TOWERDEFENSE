import * as THREE from 'three';
import type { Track } from './trackLayout';
import { clamp, curve1D, fbm, ridged, smoothstep, lerp } from './noise';

export const OX = -204;
export const OZ = 0;

export const LAKE = { x: -70, z: -330, r: 175, y: 392 };

/* ------------------------------------------------------------------ */
/* Natural mountain (before the road is carved into it)                 */
/* ------------------------------------------------------------------ */
const HZ = [
  [-1700, 470],
  [-950, 620],
  [-400, 490],
  [-110, 396],
  [120, 378],
  [1000, 178],
  [1750, 52],
  [2400, 18],
  [3300, 10],
  [4100, 50],
  [5600, 380],
  [8200, 760],
];

export function baseHeight(x: number, z: number): number {
  let h = curve1D(HZ, z);
  const ax = Math.abs(x);
  const mount = 1 - smoothstep(1700, 2600, z);
  const far = smoothstep(2900, 5600, z);
  const vScale = clamp((h - 20) / 170, 0, 1);

  // two side valleys + flanking ridges: the road zig-zags down a spur between them
  const valley = -125 * Math.exp(-Math.pow((ax - 405) / 98, 2)) * vScale;
  const flank = 235 * smoothstep(470, 1050, ax);
  h += (valley + flank) * mount;

  const corridor = 0.3 + 0.7 * smoothstep(120, 320, ax);
  h += fbm(x / 310 + 11, z / 310, 4) * 36 * corridor * (0.25 + 0.75 * mount);
  h += fbm(x / 85, z / 85, 3) * 3.2 * corridor;

  // jagged rocky ridges (Haruna's craggy skyline)
  const pk = ridged(x / 650 + 2.3, z / 650 + 7.1, 4);
  h += Math.pow(pk, 2.4) * 300 * smoothstep(520, 1150, ax) * mount;
  h += 190 * Math.pow(ridged(x / 520, z / 520 - 3, 4), 2.2) * smoothstep(-60, -800, z);
  // dome of "Haruna-Fuji"
  const dx = x - 520;
  const dz = z + 900;
  h += 210 * Math.exp(-(dx * dx + dz * dz) / (2 * 380 * 380));
  // southern ranges seen from the valley
  h += far * (300 * ridged(x / 1000 + 5, z / 1000, 4) + 130 * fbm(x / 420, z / 420, 3));

  // caldera lake basin
  const lx = x - LAKE.x;
  const lz = z - LAKE.z;
  const r = Math.sqrt(lx * lx + lz * lz);
  const w = 1 - smoothstep(190, 340, r);
  if (w > 0) {
    const target = LAKE.y - 16 + 30 * smoothstep(70, 200, r) + fbm(x / 60, z / 60, 2) * 3;
    h = lerp(h, target, w);
  }
  return h;
}

/* ------------------------------------------------------------------ */
/* Environment masks shared by terrain colouring & props                 */
/* ------------------------------------------------------------------ */
export const autumnMask = (x: number, z: number) => smoothstep(0.1, 0.5, fbm(x / 430 + 40, z / 430 + 7, 3));
export const blossomMask = (x: number, z: number) => smoothstep(0.32, 0.55, fbm(x / 240 + 90, z / 240 - 40, 3));
export const meadowMask = (x: number, z: number) => smoothstep(0.25, 0.5, fbm(x / 200 - 33, z / 200 + 12, 3));

/* ------------------------------------------------------------------ */
/* Road spatial index + carving                                           */
/* ------------------------------------------------------------------ */
export interface Platform {
  x: number;
  z: number;
  r: number;
  y: number;
}

export const ROAD_HALF = 4.6;
export const BED = 0.7;
export const FLAT = 8.0;
const SLOPE_CUT = 1.15;
const SLOPE_FILL = 0.95;
const INFLUENCE = 92;

export class RoadField {
  cell = 32;
  minX: number;
  minZ: number;
  nx: number;
  nz: number;
  cells: Int32Array[];
  sx: Float32Array;
  sy: Float32Array;
  sz: Float32Array;
  si: Int32Array;
  platforms: Platform[];

  constructor(public track: Track, platforms: Platform[], stride = 3) {
    this.platforms = platforms;
    const idx: number[] = [];
    for (let i = 0; i < track.n; i += stride) idx.push(i);
    idx.push(track.n - 1);
    this.si = Int32Array.from(idx);
    const m = idx.length;
    this.sx = new Float32Array(m);
    this.sy = new Float32Array(m);
    this.sz = new Float32Array(m);
    let minX = 1e9;
    let minZ = 1e9;
    let maxX = -1e9;
    let maxZ = -1e9;
    for (let k = 0; k < m; k++) {
      const i = idx[k];
      this.sx[k] = track.x[i];
      this.sy[k] = track.y[i];
      this.sz[k] = track.z[i];
      minX = Math.min(minX, track.x[i]);
      maxX = Math.max(maxX, track.x[i]);
      minZ = Math.min(minZ, track.z[i]);
      maxZ = Math.max(maxZ, track.z[i]);
    }
    const pad = INFLUENCE + 40;
    this.minX = minX - pad;
    this.minZ = minZ - pad;
    this.nx = Math.ceil((maxX - minX + pad * 2) / this.cell) + 1;
    this.nz = Math.ceil((maxZ - minZ + pad * 2) / this.cell) + 1;
    const lists: number[][] = Array.from({ length: this.nx * this.nz }, () => []);
    for (let k = 0; k < m; k++) {
      const cx = Math.floor((this.sx[k] - this.minX) / this.cell);
      const cz = Math.floor((this.sz[k] - this.minZ) / this.cell);
      lists[cx + cz * this.nx].push(k);
    }
    this.cells = lists.map((l) => Int32Array.from(l));
  }

  /** carved height of the world */
  height(x: number, z: number): number {
    const base = baseHeight(x, z);
    let lo = -1e9;
    let hi = 1e9;
    const cx = Math.floor((x - this.minX) / this.cell);
    const cz = Math.floor((z - this.minZ) / this.cell);
    const rc = Math.ceil(INFLUENCE / this.cell);
    const R2 = INFLUENCE * INFLUENCE;
    for (let gz = cz - rc; gz <= cz + rc; gz++) {
      if (gz < 0 || gz >= this.nz) continue;
      for (let gx = cx - rc; gx <= cx + rc; gx++) {
        if (gx < 0 || gx >= this.nx) continue;
        const list = this.cells[gx + gz * this.nx];
        for (let q = 0; q < list.length; q++) {
          const k = list[q];
          const dx = x - this.sx[k];
          const dz = z - this.sz[k];
          const d2 = dx * dx + dz * dz;
          if (d2 > R2) continue;
          const e = Math.max(0, Math.sqrt(d2) - FLAT);
          const T = this.sy[k] - BED;
          const l = T - e * SLOPE_FILL;
          const u = T + e * SLOPE_CUT;
          if (l > lo) lo = l;
          if (u < hi) hi = u;
        }
      }
    }
    for (const p of this.platforms) {
      const dx = x - p.x;
      const dz = z - p.z;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d > p.r + INFLUENCE) continue;
      const e = Math.max(0, d - p.r);
      const T = p.y - BED;
      lo = Math.max(lo, T - e * SLOPE_FILL);
      hi = Math.min(hi, T + e * SLOPE_CUT);
    }
    if (lo > hi) return (lo + hi) * 0.5;
    return clamp(base, lo, hi);
  }

  /** distance to centreline (and the nearest sample's track index) within maxR */
  nearest(x: number, z: number, maxR = 40): { d: number; i: number } {
    const cx = Math.floor((x - this.minX) / this.cell);
    const cz = Math.floor((z - this.minZ) / this.cell);
    const rc = Math.ceil(maxR / this.cell);
    let best = maxR * maxR;
    let bi = -1;
    for (let gz = cz - rc; gz <= cz + rc; gz++) {
      if (gz < 0 || gz >= this.nz) continue;
      for (let gx = cx - rc; gx <= cx + rc; gx++) {
        if (gx < 0 || gx >= this.nx) continue;
        const list = this.cells[gx + gz * this.nx];
        for (let q = 0; q < list.length; q++) {
          const k = list[q];
          const dx = x - this.sx[k];
          const dz = z - this.sz[k];
          const d2 = dx * dx + dz * dz;
          if (d2 < best) {
            best = d2;
            bi = this.si[k];
          }
        }
      }
    }
    return { d: bi < 0 ? maxR : Math.sqrt(best), i: bi };
  }

  platformDist(x: number, z: number): number {
    let m = 1e9;
    for (const p of this.platforms) m = Math.min(m, Math.hypot(x - p.x, z - p.z) - p.r);
    return m;
  }
}

/* ------------------------------------------------------------------ */
/* Palette                                                                */
/* ------------------------------------------------------------------ */
const C = (hex: number) => new THREE.Color(hex);
export const PAL = {
  grassLight: C(0xbddc4c),
  grassMid: C(0x6cc04a),
  grassDark: C(0x37a05a),
  forestFloor: C(0x2f8a5c),
  dry: C(0xc3ae56),
  soil: C(0x8e6c4b),
  rock: C(0x8f9196),
  rockWarm: C(0x86745f),
  rockDark: C(0x5c5f6a),
  autumn: C(0xcf7d33),
  autumnY: C(0xd8b045),
  verge: C(0x8aa05a),
  alpine: C(0x77846a),
};

const hash2 = (x: number, z: number) => {
  const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return s - Math.floor(s);
};

const tmpA = new THREE.Color();
const tmpB = new THREE.Color();

export function terrainColor(
  out: THREE.Color,
  x: number,
  z: number,
  h: number,
  slope: number,
  dRoad: number,
  face: number
) {
  const n1 = fbm(x / 60, z / 60, 2);
  const n2 = fbm(x / 17 + 9, z / 17, 2);
  const aut = autumnMask(x, z);
  const mead = meadowMask(x, z);
  // base vegetation
  tmpA.copy(PAL.grassDark).lerp(PAL.grassMid, clamp(0.5 + n1 * 0.9, 0, 1));
  tmpA.lerp(PAL.forestFloor, clamp(0.55 - mead * 0.6 + n2 * 0.25, 0, 0.8));
  tmpA.lerp(PAL.grassLight, mead * clamp(0.45 + n2 * 0.6, 0, 1) * 0.85);
  tmpA.lerp(PAL.autumn, aut * 0.55 * clamp(0.6 + n2, 0.2, 1));
  tmpA.lerp(PAL.autumnY, aut * 0.3 * clamp(n1 + 0.3, 0, 1));
  tmpA.lerp(PAL.dry, mead * 0.18 * (n2 * 0.5 + 0.5));
  // altitude -> alpine
  const alt = smoothstep(430, 600, h + n1 * 40);
  tmpA.lerp(PAL.alpine, alt * 0.7);
  // rock on steep faces
  const rockT = smoothstep(0.2, 0.42, slope + n2 * 0.04);
  tmpB.copy(PAL.rock).lerp(PAL.rockWarm, clamp(0.5 + n1 * 1.2, 0, 1));
  const strata = Math.sin(h * 0.9 + n2 * 2.0) * 0.5 + 0.5;
  tmpB.lerp(PAL.rockDark, strata * 0.28);
  const rockBoost = dRoad < 34 ? 0.15 : 0;
  tmpA.lerp(tmpB, clamp(rockT + rockBoost * smoothstep(0.12, 0.3, slope), 0, 1));
  const alpRock = smoothstep(560, 760, h) * 0.8;
  tmpA.lerp(tmpB, alpRock);
  // road verge
  if (dRoad < FLAT + 1.5) {
    const v = 1 - smoothstep(FLAT - 1, FLAT + 1.5, dRoad);
    tmpA.lerp(PAL.verge, 0.65 * v);
  }
  // wildflower meadows: sparse pink / yellow / white faces
  if (mead > 0.42 && slope < 0.2 && dRoad > 11 && h < 520) {
    const fr = hash2(face * 1.7, 3.3);
    if (fr < 0.07) {
      tmpB.setHex(fr < 0.025 ? 0xf6a0c4 : fr < 0.05 ? 0xffe468 : 0xfff6ec);
      tmpA.lerp(tmpB, 0.72);
    }
  }
  // per-face flat-shaded jitter (the "art" of low-poly)
  const j = (hash2(face, face * 0.37) - 0.5) * 0.12;
  out.copy(tmpA);
  out.r = clamp(out.r * (1 + j), 0, 1);
  out.g = clamp(out.g * (1 + j * 0.8), 0, 1);
  out.b = clamp(out.b * (1 + j), 0, 1);
}

/* ------------------------------------------------------------------ */
/* Meshes                                                                  */
/* ------------------------------------------------------------------ */
export interface NearBounds {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
}

export function buildNearTerrain(field: RoadField, b: NearBounds, cell = 4) {
  const nx = Math.round((b.x1 - b.x0) / cell);
  const nz = Math.round((b.z1 - b.z0) / cell);
  const W = nx + 1;
  const H = new Float32Array(W * (nz + 1));
  for (let iz = 0; iz <= nz; iz++) {
    for (let ix = 0; ix <= nx; ix++) {
      H[ix + iz * W] = field.height(b.x0 + ix * cell, b.z0 + iz * cell);
    }
  }
  const tris = nx * nz * 2;
  const pos = new Float32Array(tris * 9);
  const col = new Float32Array(tris * 9);
  const c = new THREE.Color();
  let p = 0;
  let face = 0;
  const A = new THREE.Vector3();
  const B = new THREE.Vector3();
  const D = new THREE.Vector3();
  const addTri = (
    ax: number, ay: number, az: number,
    bx: number, by: number, bz: number,
    cx: number, cy: number, cz: number
  ) => {
    pos[p] = ax; pos[p + 1] = ay; pos[p + 2] = az;
    pos[p + 3] = bx; pos[p + 4] = by; pos[p + 5] = bz;
    pos[p + 6] = cx; pos[p + 7] = cy; pos[p + 8] = cz;
    A.set(bx - ax, by - ay, bz - az);
    B.set(cx - ax, cy - ay, cz - az);
    D.crossVectors(B, A).normalize();
    const ny = Math.abs(D.y);
    const mx = (ax + bx + cx) / 3;
    const mz = (az + bz + cz) / 3;
    const my = (ay + by + cy) / 3;
    const dr = Math.min(field.nearest(mx, mz, 36).d, 36);
    terrainColor(c, mx, mz, my, 1 - ny, dr, face++);
    for (let k = 0; k < 3; k++) {
      col[p + k * 3] = c.r;
      col[p + k * 3 + 1] = c.g;
      col[p + k * 3 + 2] = c.b;
    }
    p += 9;
  };
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const x0 = b.x0 + ix * cell;
      const z0 = b.z0 + iz * cell;
      const x1 = x0 + cell;
      const z1 = z0 + cell;
      const h00 = H[ix + iz * W];
      const h10 = H[ix + 1 + iz * W];
      const h01 = H[ix + (iz + 1) * W];
      const h11 = H[ix + 1 + (iz + 1) * W];
      if ((ix + iz) & 1) {
        addTri(x0, h00, z0, x0, h01, z1, x1, h11, z1);
        addTri(x0, h00, z0, x1, h11, z1, x1, h10, z0);
      } else {
        addTri(x0, h00, z0, x0, h01, z1, x1, h10, z0);
        addTri(x1, h10, z0, x0, h01, z1, x1, h11, z1);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.computeVertexNormals();
  g.computeBoundingSphere();
  const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
  m.receiveShadow = true;
  m.castShadow = false;
  return m;
}

/** Skirt below the near terrain so no sky/void shows at its borders */
export function buildSkirt(b: NearBounds) {
  const y0 = -60;
  const g = new THREE.BufferGeometry();
  const v: number[] = [];
  const yTop = 600;
  const quad = (a: number[], bb: number[]) => {
    v.push(a[0], yTop, a[1], a[0], y0, a[1], bb[0], yTop, bb[1], bb[0], yTop, bb[1], a[0], y0, a[1], bb[0], y0, bb[1]);
  };
  quad([b.x0, b.z0], [b.x1, b.z0]);
  quad([b.x1, b.z0], [b.x1, b.z1]);
  quad([b.x1, b.z1], [b.x0, b.z1]);
  quad([b.x0, b.z1], [b.x0, b.z0]);
  g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
  return g; // not rendered (kept for possible debugging)
}

export function buildFarTerrain(near: NearBounds, size = 9600, cell = 48) {
  const x0 = -size / 2;
  const z0 = -3000;
  const nx = Math.round(size / cell);
  const nz = Math.round(11200 / cell);
  const W = nx + 1;
  const H = new Float32Array(W * (nz + 1));
  for (let iz = 0; iz <= nz; iz++) {
    for (let ix = 0; ix <= nx; ix++) H[ix + iz * W] = baseHeight(x0 + ix * cell, z0 + iz * cell);
  }
  const pos: number[] = [];
  const col: number[] = [];
  const c = new THREE.Color();
  let face = 100000;
  const A = new THREE.Vector3();
  const B = new THREE.Vector3();
  const D = new THREE.Vector3();
  const field = new THREE.Color();
  const add = (
    ax: number, ay: number, az: number,
    bx: number, by: number, bz: number,
    cx: number, cy: number, cz: number
  ) => {
    A.set(bx - ax, by - ay, bz - az);
    B.set(cx - ax, cy - ay, cz - az);
    D.crossVectors(B, A).normalize();
    const mx = (ax + bx + cx) / 3;
    const mz = (az + bz + cz) / 3;
    const my = (ay + by + cy) / 3;
    terrainColor(c, mx, mz, my, 1 - Math.abs(D.y), 100, face++);
    // distant farmland patchwork on the plain (rice paddies & fields)
    const plain = (1 - smoothstep(30, 60, my)) * smoothstep(1700, 2300, mz) * (1 - smoothstep(2300, 3000, Math.abs(mx)));
    if (plain > 0.01) {
      const hx = Math.floor(mx / 70);
      const hz = Math.floor(mz / 90);
      const hv = hash2(hx, hz);
      field.set(hv < 0.3 ? 0xb9c65a : hv < 0.55 ? 0x84b24b : hv < 0.75 ? 0xd2c46a : hv < 0.9 ? 0x6c9d4c : 0xa9855a);
      c.lerp(field, 0.85 * plain);
    }
    pos.push(ax, ay, az, bx, by, bz, cx, cy, cz);
    for (let k = 0; k < 3; k++) col.push(c.r, c.g, c.b);
  };
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const xa = x0 + ix * cell;
      const za = z0 + iz * cell;
      const xb = xa + cell;
      const zb = za + cell;
      // skip cells fully inside the detailed region
      if (xa >= near.x0 && xb <= near.x1 && za >= near.z0 && zb <= near.z1) continue;
      const h00 = H[ix + iz * W] - 0.5;
      const h10 = H[ix + 1 + iz * W] - 0.5;
      const h01 = H[ix + (iz + 1) * W] - 0.5;
      const h11 = H[ix + 1 + (iz + 1) * W] - 0.5;
      if ((ix + iz) & 1) {
        add(xa, h00, za, xa, h01, zb, xb, h11, zb);
        add(xa, h00, za, xb, h11, zb, xb, h10, za);
      } else {
        add(xa, h00, za, xa, h01, zb, xb, h10, za);
        add(xb, h10, za, xa, h01, zb, xb, h11, zb);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.computeVertexNormals();
  g.computeBoundingSphere();
  const m = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
  m.receiveShadow = false;
  return m;
}

export function buildLake() {
  const seg = 36;
  const g = new THREE.CircleGeometry(LAKE.r, seg, 0, Math.PI * 2);
  g.rotateX(-Math.PI / 2);
  const p = g.attributes.position;
  for (let i = 1; i < p.count; i++) {
    const x = p.getX(i);
    const z = p.getZ(i);
    const a = Math.atan2(z, x);
    const k = 1 + 0.12 * Math.sin(a * 3 + 1) + 0.08 * Math.sin(a * 5 + 2) + 0.05 * Math.sin(a * 9);
    p.setX(i, x * k);
    p.setZ(i, z * k);
    p.setY(i, (Math.random() - 0.5) * 0.25);
  }
  g.computeVertexNormals();
  const m = new THREE.Mesh(
    g.toNonIndexed(),
    new THREE.MeshPhongMaterial({
      color: 0x3aa8cf,
      specular: 0xffffff,
      shininess: 70,
      flatShading: true,
      transparent: true,
      opacity: 0.94,
    })
  );
  m.position.set(LAKE.x, LAKE.y, LAKE.z);
  m.receiveShadow = true;
  return m;
}

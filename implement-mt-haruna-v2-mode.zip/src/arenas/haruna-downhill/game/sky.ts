import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { mulberry32 } from './noise';

export interface TimePreset {
  name: string;
  label: string;
  top: number;
  mid: number;
  horizon: number;
  fog: number;
  fogDensity: number;
  sunColor: number;
  sunIntensity: number;
  sunAz: number; // degrees, 0 = +z (south), 90 = +x (east)
  sunEl: number;
  hemiSky: number;
  hemiGround: number;
  hemiIntensity: number;
  cloud: number;
  exposure: number;
}

export const PRESETS: TimePreset[] = [
  {
    name: 'day',
    label: 'SUNNY DAY',
    top: 0x1c6bd8,
    mid: 0x58a5ee,
    horizon: 0xd0e6f6,
    fog: 0xd0e6f6,
    fogDensity: 0.00027,
    sunColor: 0xffeccb,
    sunIntensity: 3.4,
    sunAz: -138,
    sunEl: 51,
    hemiSky: 0xa6ccff,
    hemiGround: 0xb2c25c,
    hemiIntensity: 1.42,
    cloud: 0xffffff,
    exposure: 1.0,
  },
  {
    name: 'golden',
    label: 'GOLDEN HOUR',
    top: 0x3a6fc4,
    mid: 0xf2b98a,
    horizon: 0xffd9a6,
    fog: 0xffd9a6,
    fogDensity: 0.00034,
    sunColor: 0xffb468,
    sunIntensity: 3.2,
    sunAz: -105,
    sunEl: 17,
    hemiSky: 0xf0cfc0,
    hemiGround: 0xb08048,
    hemiIntensity: 1.35,
    cloud: 0xffd9c0,
    exposure: 1.0,
  },
  {
    name: 'mist',
    label: 'MISTY MORNING',
    top: 0x6f93c4,
    mid: 0xaec8de,
    horizon: 0xe6eef1,
    fog: 0xe6eef1,
    fogDensity: 0.00085,
    sunColor: 0xfff6e2,
    sunIntensity: 2.1,
    sunAz: 140,
    sunEl: 24,
    hemiSky: 0xcfe3f5,
    hemiGround: 0x7d9360,
    hemiIntensity: 1.4,
    cloud: 0xf4f7fa,
    exposure: 1.05,
  },
];

export class Sky {
  group = new THREE.Group();
  dome: THREE.Mesh;
  clouds = new THREE.Group();
  uniforms = {
    top: { value: new THREE.Color() },
    mid: { value: new THREE.Color() },
    horizon: { value: new THREE.Color() },
    sunDir: { value: new THREE.Vector3(0, 1, 0) },
    sunColor: { value: new THREE.Color() },
  };
  cloudMat: THREE.MeshLambertMaterial;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  sunDir = new THREE.Vector3();
  private cloudSpeed: { m: THREE.Object3D; v: number }[] = [];

  constructor(public scene: THREE.Scene) {
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `
        varying vec3 vDir;
        void main(){
          vDir = position;
          vec4 p = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * p;
          gl_Position.z = gl_Position.w * 0.99999;
        }`,
      fragmentShader: `
        uniform vec3 top; uniform vec3 mid; uniform vec3 horizon;
        uniform vec3 sunDir; uniform vec3 sunColor;
        varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = d.y;
          vec3 c = mix(horizon, mid, smoothstep(0.0, 0.22, h));
          c = mix(c, top, smoothstep(0.18, 0.8, h));
          c = mix(c, horizon, smoothstep(0.0, -0.25, h));
          float sd = max(dot(d, normalize(sunDir)), 0.0);
          c += sunColor * (pow(sd, 900.0) * 6.0 + pow(sd, 40.0) * 0.35 + pow(sd, 6.0) * 0.12);
          gl_FragColor = vec4(c, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    });
    this.dome = new THREE.Mesh(new THREE.SphereGeometry(8000, 32, 16), mat);
    this.dome.frustumCulled = false;
    this.dome.renderOrder = -10;
    this.group.add(this.dome);

    // low-poly cumulus: puffy tops, flat bluish bottoms
    this.cloudMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, fog: false, emissive: 0xc9d8ea, emissiveIntensity: 0.8 });
    const rnd = mulberry32(909);
    const cBottom = new THREE.Color(0.84, 0.9, 0.98);
    const cTop = new THREE.Color(1, 1, 1);
    for (let i = 0; i < 64; i++) {
      const parts: THREE.BufferGeometry[] = [];
      const blobs = 6 + Math.floor(rnd() * 6);
      const base = 85 + rnd() * 95;
      for (let b = 0; b < blobs; b++) {
        const g = new THREE.IcosahedronGeometry(base * (0.5 + rnd() * 0.62), 1);
        g.deleteAttribute('uv');
        g.scale(1.25, 0.8, 1.05);
        const mid = Math.abs(b - blobs / 2) / (blobs / 2);
        g.translate((b - blobs / 2) * base * 0.9 + (rnd() - 0.5) * 40, (1 - mid) * base * 0.35 + (rnd() - 0.2) * base * 0.35, (rnd() - 0.5) * base * 0.9);
        parts.push(g.toNonIndexed());
      }
      const geo = mergeGeometries(parts)!;
      const pos = geo.attributes.position;
      const floorY = -base * 0.2;
      let maxY = -1e9;
      for (let v = 0; v < pos.count; v++) {
        let y = pos.getY(v);
        if (y < floorY) y = floorY + (y - floorY) * 0.12;
        pos.setY(v, y);
        maxY = Math.max(maxY, y);
      }
      const col = new Float32Array(pos.count * 3);
      const tmp = new THREE.Color();
      for (let v = 0; v < pos.count; v++) {
        const t = Math.min(1, Math.max(0, (pos.getY(v) - floorY) / (maxY - floorY + 1)));
        tmp.copy(cBottom).lerp(cTop, Math.min(1, t * 1.9));
        col[v * 3] = tmp.r;
        col[v * 3 + 1] = tmp.g;
        col[v * 3 + 2] = tmp.b;
      }
      geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
      geo.computeVertexNormals();
      const m = new THREE.Mesh(geo, this.cloudMat);
      const ang = rnd() * Math.PI * 2;
      const near = i < 14;
      const rad = near ? 1500 + rnd() * 2000 : 3400 + rnd() * 3600;
      m.position.set(Math.cos(ang) * rad, near ? 950 + rnd() * 600 : 620 + rnd() * 650, Math.sin(ang) * rad);
      m.rotation.y = rnd() * Math.PI;
      m.scale.setScalar(near ? 0.8 + rnd() * 0.7 : 1.0 + rnd() * 1.9);
      m.castShadow = false;
      this.clouds.add(m);
      this.cloudSpeed.push({ m, v: 2 + rnd() * 4 });
    }
    this.group.add(this.clouds);
    scene.add(this.group);

    this.sun = new THREE.DirectionalLight(0xffffff, 2.5);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -95;
    sc.right = 95;
    sc.top = 95;
    sc.bottom = -95;
    sc.near = 10;
    sc.far = 520;
    this.sun.shadow.bias = -0.0005;
    this.sun.shadow.normalBias = 0.35;
    scene.add(this.sun);
    scene.add(this.sun.target);
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x888888, 1);
    scene.add(this.hemi);
  }

  apply(p: TimePreset, renderer: THREE.WebGLRenderer) {
    this.uniforms.top.value.set(p.top);
    this.uniforms.mid.value.set(p.mid);
    this.uniforms.horizon.value.set(p.horizon);
    this.uniforms.sunColor.value.set(p.sunColor);
    const az = (p.sunAz * Math.PI) / 180;
    const el = (p.sunEl * Math.PI) / 180;
    this.sunDir.set(Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el)).normalize();
    this.uniforms.sunDir.value.copy(this.sunDir);
    this.sun.color.set(p.sunColor);
    this.sun.intensity = p.sunIntensity;
    this.hemi.color.set(p.hemiSky);
    this.hemi.groundColor.set(p.hemiGround);
    this.hemi.intensity = p.hemiIntensity;
    this.cloudMat.color.set(p.cloud);
    this.cloudMat.emissive.set(p.cloud).multiplyScalar(0.8);
    const f = this.scene.fog as THREE.FogExp2;
    f.color.set(p.fog);
    f.density = p.fogDensity;
    renderer.toneMappingExposure = p.exposure;
  }

  update(dt: number, camPos: THREE.Vector3) {
    this.dome.position.copy(camPos);
    for (const c of this.cloudSpeed) {
      c.m.position.x += c.v * dt;
      if (c.m.position.x > 7000) c.m.position.x = -7000;
    }
  }

  followSun(target: THREE.Vector3) {
    // texel-snapped shadow follow
    const snap = 190 / 2048;
    const tx = Math.round(target.x / snap) * snap;
    const ty = Math.round(target.y / snap) * snap;
    const tz = Math.round(target.z / snap) * snap;
    this.sun.target.position.set(tx, ty, tz);
    this.sun.position.set(tx + this.sunDir.x * 260, ty + this.sunDir.y * 260, tz + this.sunDir.z * 260);
    this.sun.target.updateMatrixWorld();
  }
}

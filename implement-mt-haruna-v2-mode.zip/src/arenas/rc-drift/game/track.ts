import * as THREE from 'three';

// 2D track (x right, y up seen from above). World mapping: X = x, Z = -y.
export interface TrackPoint {
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number; // left normal (points to infield for CCW loop)
  ny: number;
  s: number;
}

export interface NearestResult {
  i: number;
  t: number;
  cx: number;
  cy: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
  offset: number; // signed lateral offset (+ = left / infield)
  s: number; // distance along track
}

// Mt. Haruna Touge (RC scale): technical zig-zag with an uphill hairpin — tight, technical, technical, just like the touge sections of the real course. This is the DEFAULT arena track.
export const HARUNA_CONTROL: [number, number][] = [
  [0.0, -7.4], [8.0, -7.1], [13.5, -4.6], [14.6, -0.5], [11.5, 2.4], [6.5, 1.6], [3.5, -1.8],
  [-1.5, -3.2], [-6.0, -1.6], [-8.0, 1.8], [-11.0, 4.2], [-14.6, 2.2], [-14.2, -2.8], [-10.5, -5.6], [-5.5, -6.9],
];

// Simple flowing loop: long main straight, two wide sweepers and a gentle S.
export const TRACK_CONTROL: [number, number][] = [
  [0, -7.6],
  [11, -7.2],
  [16.2, -4.2],
  [17.2, 1.0],
  [14.0, 5.8],
  [7.5, 7.4],
  [2.5, 5.4],
  [-2.5, 4.6],
  [-7.5, 7.2],
  [-14.0, 6.2],
  [-17.2, 1.2],
  [-16.2, -4.2],
  [-11, -7.2],
];

export type ArenaTrackId = 'haruna' | 'prodrift';
export interface ArenaTrackDef { id: ArenaTrackId; name: string; tag: string; desc: string; control: [number, number][] }
export const TRACKS: Record<ArenaTrackId, ArenaTrackDef> = {
  haruna: { id: 'haruna', name: 'Mt. Haruna Touge', tag: 'DEFAULT', desc: 'Zig-zag teknikal & hairpin ala touge Jepang.', control: HARUNA_CONTROL },
  prodrift: { id: 'prodrift', name: 'PRODRIFT — Sirkuit Pinus', tag: 'OPSIONAL', desc: 'Sweeper lebar & straight panjang — identik dengan balapan PRODRIFT.', control: TRACK_CONTROL },
};
export const DEFAULT_TRACK_ID: ArenaTrackId = 'haruna';
export function readArenaTrackId(): ArenaTrackId {
  try { return localStorage.getItem('rmx-arena.track') === 'prodrift' ? 'prodrift' : 'haruna'; } catch { return DEFAULT_TRACK_ID; }
}

export class Track {
  pts: TrackPoint[] = [];
  length = 0;
  readonly halfWidth = 1.8;
  readonly curve: THREE.CatmullRomCurve3;

  constructor(ctrl: [number, number][] = HARUNA_CONTROL, n = 720) {
    this.curve = new THREE.CatmullRomCurve3(
      ctrl.map(([x, y]) => new THREE.Vector3(x, y, 0)),
      true,
      'centripetal',
    );
    const sp = this.curve.getSpacedPoints(n);
    let s = 0;
    for (let i = 0; i < n; i++) {
      const p = sp[i];
      const next = sp[(i + 1) % n];
      const prev = sp[(i - 1 + n) % n];
      let tx = next.x - prev.x;
      let ty = next.y - prev.y;
      const l = Math.hypot(tx, ty) || 1;
      tx /= l;
      ty /= l;
      if (i > 0) s += Math.hypot(p.x - sp[i - 1].x, p.y - sp[i - 1].y);
      this.pts.push({ x: p.x, y: p.y, tx, ty, nx: -ty, ny: tx, s });
    }
    this.length = s + Math.hypot(sp[0].x - sp[n - 1].x, sp[0].y - sp[n - 1].y);
  }

  get count() {
    return this.pts.length;
  }

  nearest(x: number, y: number, hint = -1, window = 40): NearestResult {
    const P = this.pts;
    const N = P.length;
    let best = Infinity;
    let bi = 0;
    let bt = 0;
    const check = (i: number) => {
      const p = P[i];
      const q = P[(i + 1) % N];
      const dx = q.x - p.x;
      const dy = q.y - p.y;
      const l2 = dx * dx + dy * dy || 1e-9;
      let t = ((x - p.x) * dx + (y - p.y) * dy) / l2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const cx = p.x + dx * t;
      const cy = p.y + dy * t;
      const d2 = (x - cx) * (x - cx) + (y - cy) * (y - cy);
      if (d2 < best) {
        best = d2;
        bi = i;
        bt = t;
      }
    };
    if (hint < 0) for (let i = 0; i < N; i++) check(i);
    else for (let k = -window; k <= window; k++) check((((hint + k) % N) + N) % N);

    const p = P[bi];
    const q = P[(bi + 1) % N];
    const cx = p.x + (q.x - p.x) * bt;
    const cy = p.y + (q.y - p.y) * bt;
    let tx = p.tx + (q.tx - p.tx) * bt;
    let ty = p.ty + (q.ty - p.ty) * bt;
    const l = Math.hypot(tx, ty) || 1;
    tx /= l;
    ty /= l;
    const nx = -ty;
    const ny = tx;
    const offset = (x - cx) * nx + (y - cy) * ny;
    const segLen = Math.hypot(q.x - p.x, q.y - p.y);
    return { i: bi, t: bt, cx, cy, tx, ty, nx, ny, offset, s: p.s + segLen * bt };
  }

  /** Points offset laterally from the centerline (closed loop). */
  edge(offset: number, height = 0): THREE.Vector3[] {
    return this.pts.map((p) => new THREE.Vector3(p.x + p.nx * offset, height, -(p.y + p.ny * offset)));
  }

  /** Signed curvature at index (positive = left turn). */
  curvature(i: number) {
    const N = this.pts.length;
    const a = this.pts[(i - 3 + N) % N];
    const b = this.pts[(i + 3) % N];
    const ang = Math.atan2(a.tx * b.ty - a.ty * b.tx, a.tx * b.tx + a.ty * b.ty);
    return ang / Math.max(1e-3, Math.abs(b.s - a.s) || 0.6);
  }
}

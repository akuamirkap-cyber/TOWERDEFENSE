import { createDriftCar as createClassicCar } from './drift-physics.js';
import { createDriftCar as createRmxCar, CAR_SCALE, RALLY_SCALE } from './rmx-drift-adapter';
import { createDriftScore } from './drift-score.js';
// Drift recognition window matched to 3D Car Drift Simulator (12°–115°, smooth power-over, e-brake & manji scoring)
const DRIFT_SIM_SCORE_RULES = { minAngle: 12 * Math.PI / 180, comboAngle: .175, maxAngle: 115 * Math.PI / 180, spinAngle: 118 * Math.PI / 180, minSlip: -1 };
import { toKmh } from './speed-cues.js';

// ---------------------------------------------------------------------------
// Real-world dimensions (car at real size, body 1.90 m wide):
//  • asphalt track 15 m wide (international permanent circuits: minimum 12 m)
//  • kerbs, then PAVED run-off like modern circuits, gravel strip, barrier
//  • barrier at 1.8 m × RALLY_SCALE ≈ 15.1 m from the centre line = the same
//    car-relative free space as the RMX 2.5 RC arena (1.8 m half-width)
//  • layout ×1.45 → corner radii (10%/25% tightest) ≈ RC arena in car lengths
// ---------------------------------------------------------------------------
export const TRACK_SCALE = 1.45;
export const ROAD_WIDTH = 7.5; // half → 15 m track
export const BARRIER = 1.8 * RALLY_SCALE; // ≈ 15.07 m
export const RUNOFF = BARRIER - 1.6; // paved run-off ends here (≈ 6 m per side)
export const LANE_SCALE = ROAD_WIDTH / 7.65;

export function createTrack(T, opts = {}) {
  const S = opts.scale ?? TRACK_SCALE;
  const layout = [
    [0,-87],[0,-60],[.4,-42],[-4.4,-25],[-17,-9],[-27,-3],[-34,5],[-39,15],[-41,29],[-39,46],[-33,57],[-34,71],[-24,87],[-2,101],
    [23,106],[45,98],[61,80],[68,52],[65,22],[49,-3],[45,-22],[49,-43],[55,-63],[58,-80],[55,-95],[45,-108],[30,-115],[15,-111],[4,-101],
  ];
  const curve = new T.CatmullRomCurve3(layout.map(([x,z]) => new T.Vector3(x*1.23*S,0,z*1.23*S)),true,'centripetal');
  curve.arcLengthDivisions = Math.round(2600*S);
  const {clamp,euclideanModulo,lerp}=T.MathUtils;
  const length=curve.getLength(),segments=Math.round(960*S),start=32.1*S,roadWidth=ROAD_WIDTH,barrier=BARRIER;
  const centers=curve.getSpacedPoints(segments).slice(0,-1),gap=length/segments,diff=new T.Vector3();
  const frames=centers.map((p,i)=>{
    diff.subVectors(centers[(i+1)%segments],centers[(i+segments-1)%segments]).normalize();
    return {x:p.x,z:p.z,tx:diff.x,tz:diff.z};
  });
  function at(distance,target={x:0,z:0,tx:0,tz:1}) {
    const a=euclideanModulo(distance,length)/length*segments,i=Math.floor(a),f=a-i;
    const p=frames[i],q=frames[(i+1)%segments];
    target.x=lerp(p.x,q.x,f);target.z=lerp(p.z,q.z,f);target.tx=lerp(p.tx,q.tx,f);target.tz=lerp(p.tz,q.tz,f);
    return target;
  }
  const minX=Math.min(...centers.map(p=>p.x)),minZ=Math.min(...centers.map(p=>p.z));
  const rangeX=Math.max(...centers.map(p=>p.x))-minX,rangeZ=Math.max(...centers.map(p=>p.z))-minZ;
  const scale=77/Math.max(rangeX,rangeZ),mapOffset=(100-rangeX*scale)/2;
  const toMapX=x=>100-mapOffset-(x-minX)*scale,toMapY=z=>89-(z-minZ)*scale;
  const mapPoint=p=>`${toMapX(p.x).toFixed(2)},${toMapY(p.z).toFixed(2)}`;
  const route=`M${centers.filter((_,i)=>i%9===0).map(mapPoint).join(' ')}Z`;
  const origin=at(start),startMarker={x:toMapX(origin.x),y:toMapY(origin.z)};
  const zones=[],before=at(0),after=at(0);
  let zoneStart=20,runSide=0;
  for(let d=20;d<=length-10;d+=2) {
    at(start+d-7.4*S,before);at(start+d+7.4*S,after);
    const bend=Math.atan2(after.tx*before.tz-after.tz*before.tx,after.tx*before.tx+after.tz*before.tz);
    const side=d>length-13*S||Math.abs(bend)<=.119?0:-Math.sign(bend);
    if(side===runSide)continue;
    if(runSide&&d-zoneStart>=13*S) {
      const p=at(0),points=[];
      for(let i=zoneStart;i<=d+1;i+=2)points.push(mapPoint(at(start+Math.min(i,d),p)));
      zones.push({start:zoneStart,end:d,side:runSide,path:`M${points.join(' ')}`});
    }
    runSide=side;zoneStart=d;
  }

  const pavement={grip:1,roughness:0,height:0},kerb={grip:.86,roughness:.35,height:.039},gravel={grip:.66,roughness:1,height:-.025};
  // RMX: uniform grip like the RC P-tile floor (kerb / gravel stay visual + audio only)
  const kerbRmx={grip:1,roughness:.35,height:.039},gravelRmx={grip:1,roughness:1,height:-.025};
  function closest(x,z,around,look) {
    let bestIndex=around,best=Infinity;
    for(let n=-look;n<=look;n++) {
      const i=(around+n+segments)%segments,p=frames[i],d=(x-p.x)**2+(z-p.z)**2;
      if(d<best) {best=d;bestIndex=i;}
    }
    // Lost lock (e.g. off-track beyond the window): recover with a full scan so lane math never wedges.
    if(best>49) {
      for(let i=0;i<segments;i+=4) {
        const d=(x-frames[i].x)**2+(z-frames[i].z)**2;
        if(d<best) {best=d;bestIndex=i;}
      }
      const lo=Math.max(0,bestIndex-8),hi=Math.min(segments,bestIndex+8);
      for(let i=lo;i<hi;i++) {
        const j=(i+segments)%segments,d=(x-frames[j].x)**2+(z-frames[j].z)**2;
        if(d<best) {best=d;bestIndex=j;}
      }
    }
    return bestIndex;
  }

  // physics: 'rmx' = RMX 2.5 drift system (player), 'classic' = original model (Ghost AI reference lap)
  function createRun(physics='rmx',runOpts={}) {
    const rmx=physics!=='classic';
    // RC-arena wall model inside the RMX simulation: lane offset (world m) of any point, robust after teleports
    let colHint=Math.round(start/gap);
    const laneAt=(x,z)=>{
      colHint=closest(x,z,colHint,14);let q=frames[colHint];
      if((x-q.x)**2+(z-q.z)**2>(barrier*2)**2) {let best=Infinity;for(let i=0;i<segments;i++){const d=(x-frames[i].x)**2+(z-frames[i].z)**2;if(d<best){best=d;colHint=i;}}q=frames[colHint];}
      return {off:(x-q.x)*q.tz-(z-q.z)*q.tx,nx:q.tz,nz:-q.tx};
    };
    const createDriftCar=rmx?(fn)=>createRmxCar(fn,{isolated:physics==='ghost',settings:runOpts.settings,barrier:{halfWidth:barrier,laneAt}}):createClassicCar;
    let nearest=Math.round(start/gap),lineAt=start,trackYaw=Math.atan2(origin.tx,origin.tz),strike=0,lane=0;
    const drive=createDriftCar((x,z)=>{
      const p=frames[closest(x,z,nearest,11)], offset=Math.abs((x-p.x)*p.tz-(z-p.z)*p.tx);
      return offset<roadWidth?pavement:offset<roadWidth+.53?(rmx?kerbRmx:kerb):offset<RUNOFF?pavement:(rmx?gravelRmx:gravel);
    }),state=drive.state,score=createDriftScore(rmx?DRIFT_SIM_SCORE_RULES:undefined);
    const thr=1; // 1:1 real-world m/s matching 3d-car-drift-simulator (2).zip
    let elapsed=0,lap=1,best=null,last=null,started=false,travel=0,highwater=0,mode='attack',finished=false;
    let scoringZone=-1;
    function reset(next=mode) {
      drive.reset(origin.x,origin.z,Math.atan2(origin.tx,origin.tz));
      nearest=colHint=Math.round(start/gap);lineAt=start;trackYaw=state.yaw;strike=lane=0;
      elapsed=travel=highwater=0;lap=1;started=finished=false;mode=next;scoringZone=-1;score.reset();
    }
    function step(dt,input) {
      if(finished)return;
      drive.step(dt,input);
      nearest=closest(state.x,state.z,nearest,12);
      const p=frames[nearest],nx=p.tz,nz=-p.tx,dx=state.x-p.x,dz=state.z-p.z;
      lane=dx*nx+dz*nz;trackYaw=Math.atan2(p.tx,p.tz);
      const cos=Math.cos(state.yaw),sin=Math.sin(state.yaw);
      // A rounded footprint prevents the outermost corner catching the rail on a light sideswipe.
      const sideWidth=cos*nx-sin*nz,frontWidth=sin*nx+cos*nz;
      const chassisWidth=(rmx?CAR_SCALE:1)*(input.response==='smooth'?Math.abs(sideWidth)*1.06+Math.abs(frontWidth)*2.31+.14
        :Math.abs(sideWidth)*1.19+Math.abs(frontWidth)*2.46);
      strike=Math.max(0,strike-dt*9);
      if(rmx) {
        // 3D Car Drift Simulator wall impact threshold: 4.5 m/s normal speed = heavy hit / combo lost
        if(drive.lastImpact>0) strike=Math.max(strike,drive.lastImpact*(1.45/4.5));
      } else if(Math.abs(lane)>barrier-chassisWidth) {
        const side=Math.sign(lane),overlap=Math.abs(lane)-(barrier-chassisWidth);
        state.x-=nx*side*overlap;state.z-=nz*side*overlap;
        const outward=(state.vx*nx+state.vz*nz)*side;
        if(outward>0) {
          // Barrier impulses remove outward velocity without steering the car along the road.
          const grazing=input.response==='smooth'&&outward<2.4&&outward<state.speed*.21;
          const recoil=grazing?1:1.13;
          state.vx-=nx*side*outward*recoil;state.vz-=nz*side*outward*recoil;
          const rub=grazing?Math.exp(-.43*outward*dt):clamp(1-outward*.034,.54,1);
          state.vx*=rub;state.vz*=rub;state.yawRate*=grazing?Math.exp(-.85*outward*dt):clamp(1-outward*.088,.24,1);
          strike=Math.max(strike,outward);
        }
        drive.refresh();
      }
      const next=nearest*gap+dx*p.tx+dz*p.tz,delta=euclideanModulo(next-lineAt+length*.5,length)-length*.5;
      travel+=clamp(delta,-state.speed*dt-.18,state.speed*dt+.18);
      lineAt=next;highwater=Math.max(highwater,travel);
      if(state.speed>.28) started=true;
      if(started) elapsed+=dt;
      const section=euclideanModulo(travel,length),zoneIndex=zones.findIndex(item=>section>=item.start&&section<item.end),outer=zones[zoneIndex];
      const alignment=state.vx*p.tx+state.vz*p.tz;
      const backwards=state.gear==='R'||travel<highwater-8;
      score.step(dt,{speed:state.speed/thr,beta:state.beta,forward:state.forwardSpeed/thr,along:backwards?0:alignment/thr,pointsAlong:backwards?0:alignment,
        slip:state.rearSlip,roughness:state.roughness,impact:strike,linking:state.driftPhase==='link',
        outside:!!outer&&lane*outer.side>3.4*LANE_SCALE&&Math.sign(state.beta)===outer.side&&Math.abs(lane)<6.99*LANE_SCALE});
      scoringZone=score.inBonus?zoneIndex:-1;
      if(highwater>=lap*length) {
        last=elapsed;best=best===null?elapsed:Math.min(last,best);
        if(mode==='attack') {score.finish();finished=true;} else {lap++;elapsed=0;}
      }
    }
    const snapshot=()=>({lap,time:elapsed,best,last,speed:toKmh(state.rcSpeed??state.speed),gear:state.gear,rev:state.rev,shifting:state.shifting,coasting:state.coasting,throttle:state.throttle,
      mapX:toMapX(state.x),mapY:toMapY(state.z),heading:state.yaw,distance:clamp(highwater-(lap-1)*length,0,length),
      driftAngle:Math.round(T.MathUtils.radToDeg(Math.abs(state.beta))),controlPhase:state.driftPhase,drift:score.snapshot(),mode,finished});
    reset();
    const runApi={state,step,reset,snapshot,setFeintMode:(enabled)=>{if(rmx&&typeof drive.setFeintMode==='function')drive.setFeintMode(enabled);},get time(){return elapsed;},get lap(){return lap;},get heading(){return trackYaw;},get impact(){return strike;},get finished(){return finished;},
      get progress(){return travel;},get lane(){return lane;},get scoringZone(){return scoringZone;}};
    if(physics==='rmx'&&typeof window!=='undefined')window.__rallyRun={run:runApi,frames,nearest:()=>nearest};
    return runApi;
  }

  return {length,start,segments,roadWidth,barrier,frames,at,origin,startMarker,zones,route,createRun,scale:S,laneScale:LANE_SCALE,runoff:RUNOFF};
}
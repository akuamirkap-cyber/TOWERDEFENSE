import coreSrc from './core.worklet.js?raw';
import type { DriftState } from '../drift-physics.js';

/** Keadaan simulasi mesin/kendaraan yang dilaporkan oleh inti audio (sama dengan repo BMW). */
export interface SimState {
  rpm: number; v: number; gas: number; gear: number; sh: number; cl: number;
  thr: number; brk: number; steer: number; boost: number; spool: number;
  load: number; cold: number; es: number; lim: number; launch: number;
  tc: number; sr: number; sf: number; beta: number; ax: number; ay: number;
  tq: number; fire: number; m: number[]; deny: number; bump: number; vw: number; burble: number; dist: number;
}

export type BmwEngine = 's55' | 's54' | 's63';
export type BmwTrans = 'dct' | 'mt';
export type BmwCfg = { engine: BmwEngine; trans: BmwTrans };

type Msg = Record<string, unknown>;
interface CoreLike { onMessage(m: Msg): void; render(l: Float32Array, r: Float32Array, n: number): void; post: ((m: SimState) => void) | null }

/** Gema pendek ala pit-wall: beberapa pantulan awal + ekor redup yang makin gelap. */
function makeImpulse(ctx: AudioContext): AudioBuffer {
  const sr = ctx.sampleRate;
  const len = Math.floor(sr * 1.5);
  const buf = ctx.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let lp = 0;
    for (let i = Math.floor(sr * 0.012); i < len; i++) {
      const t = i / sr;
      lp += (Math.random() * 2 - 1 - lp) * (0.45 * Math.exp(-t * 3.5) + 0.06);
      d[i] = lp * Math.exp(-t * 4.4) * 0.6;
    }
    const taps = ch === 0 ? [[0.021, 0.7], [0.043, 0.45], [0.071, 0.3]] : [[0.027, 0.65], [0.049, 0.5], [0.083, 0.28]];
    for (const [t, a] of taps) { const i = Math.floor(t * sr); d[i] += a; d[i + 1] -= a * 0.4; }
  }
  return buf;
}

class SoundEngine {
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  state: SimState = { rpm: 0, v: 0, gas: 0, gear: 0, sh: 0, cl: 0, thr: 0, brk: 0, steer: 0, boost: 0, spool: 0, load: 0, cold: 1, es: 0, lim: 0, launch: 0, tc: 0, sr: 0, sf: 0, beta: 0, ax: 0, ay: 0, tq: 0, fire: 0, m: new Array(15).fill(0), deny: 0, bump: 0, vw: 0, burble: 0, dist: 0 };
  fire = 0;
  backend: 'worklet' | 'script' | 'none' = 'none';
  ready = false;
  private port: MessagePort | null = null;
  private core: CoreLike | null = null;
  private initP: Promise<void> | null = null;
  private cfg: Record<string, unknown> = {};
  private lg: number[] | null = null;
  private vol = 1;
  private wet = 0.14;
  private outGain: GainNode | null = null;
  private wetGain: GainNode | null = null;
  private listeners = new Set<() => void>();

  onReady(fn: () => void) { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }

  /** Harus dipanggil dari gesture pengguna (klik / tombol). */
  init(): Promise<void> {
    if (this.ctx) {
      if (this.ctx.state !== 'running') void this.ctx.resume();
      return this.initP ?? Promise.resolve();
    }
    this.initP = this.build();
    return this.initP;
  }

  private async build() {
    const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC({ latencyHint: 'interactive' });
    this.ctx = ctx;
    void ctx.resume();

    const out = ctx.createGain(); out.gain.value = this.vol;
    const wet = ctx.createGain(); wet.gain.value = this.wet;
    const conv = ctx.createConvolver(); conv.buffer = makeImpulse(ctx);
    const an = ctx.createAnalyser(); an.fftSize = 8192; an.smoothingTimeConstant = 0.55; an.minDecibels = -96; an.maxDecibels = -14;
    conv.connect(wet); wet.connect(out); out.connect(an); an.connect(ctx.destination);
    this.outGain = out; this.wetGain = wet; this.analyser = an;

    let node: AudioNode;
    try {
      if (!ctx.audioWorklet) throw new Error('AudioWorklet tidak tersedia');
      const url = URL.createObjectURL(new Blob([coreSrc], { type: 'application/javascript' }));
      await ctx.audioWorklet.addModule(url);
      const wn = new AudioWorkletNode(ctx, 'bmw-core', { numberOfInputs: 0, numberOfOutputs: 1, outputChannelCount: [2] });
      wn.port.onmessage = (e) => this.onState(e.data as SimState);
      this.port = wn.port; node = wn; this.backend = 'worklet';
    } catch {
      // cadangan: jalankan inti DSP yang sama di main thread
      const Core = new Function(coreSrc + '\nreturn BMWCore;')() as new (sr: number) => CoreLike;
      const core = new Core(ctx.sampleRate);
      core.post = (m) => this.onState(m);
      const sp = ctx.createScriptProcessor(1024, 1, 2);
      sp.onaudioprocess = (e) => { const ob = e.outputBuffer; core.render(ob.getChannelData(0), ob.getChannelData(1), ob.length); };
      this.core = core; node = sp; this.backend = 'script';
    }
    node.connect(out); node.connect(conv);

    this.ready = true;
    this.post({ t: 'master', v: 1.15 });
    if (Object.keys(this.cfg).length) this.post({ t: 'cfg', v: this.cfg });
    if (this.lg) this.post({ t: 'lg', v: this.lg });
    this.listeners.forEach((f) => f());
  }

  private onState(m: SimState) { this.state = m; this.fire |= m.fire; }

  post(msg: Msg) {
    if (this.port) this.port.postMessage(msg);
    else if (this.core) this.core.onMessage(msg);
  }
  cmd(c: string) { void this.init().then(() => this.post({ t: 'cmd', c })); }
  setCfg(c: Record<string, unknown>) { this.cfg = { ...this.cfg, ...c }; this.post({ t: 'cfg', v: c }); }
  setLayerGains(g: number[]) { this.lg = g; this.post({ t: 'lg', v: g }); }
  setVolume(v: number) { this.vol = v; if (this.outGain && this.ctx) this.outGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05); }
  setWet(v: number) { this.wet = v; if (this.wetGain && this.ctx) this.wetGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05); }
  dispose() {
    this.listeners.clear();
    if (this.ctx) void this.ctx.close().catch(() => { });
    this.ctx = null; this.ready = false; this.port = null; this.core = null; this.initP = null;
  }
}

export const sound = new SoundEngine();
// Pegangan debug untuk panel & otomasi: singleton yang sama dengan yang dipakai game.
if (typeof window !== 'undefined') (window as unknown as { __bmwSound?: SoundEngine }).__bmwSound = sound;

/**
 * Pembungkus yang memberi makan inti akustik BMW dari keadaan mobil yang sedang dikemudikan.
 * Menggantikan synthesizer drift lama: mesin (S55/S54/S63), knalpot, turbo, transmisi,
 * dengungan gigi, lengking ban/drift, kerb, dan gebrukan suspensi.
 */
export function createBmwDriveAudio() {
  let enabled = true, started = false, muted = false, view = 0;
  let trans: BmwTrans = 'dct';
  const sent = { throttle: 0, brake: 0, steer: 0, handbrake: 0, kerb: 0, skid: 0 };

  function postInputs(patch: Partial<typeof sent>) {
    Object.assign(sent, patch);
    if (sound.ready) sound.post({ t: 'in', v: { ...sent } });
  }

  function unlock() {
    if (!enabled || typeof AudioContext === 'undefined') return;
    void sound.init().then(() => {
      if (!started) {
        started = true;
        sound.setCfg({ auto: 1, mode: 2, dsc: 1, bumpy: 1, view });
        sound.cmd('start');
      }
      muted = false;
      sound.setVolume(1);
      postInputs({});
    });
  }

  function sample(state: DriftState, kerb: number, interior: boolean) {
    if (!sound.ready || !enabled) return;
    if (muted) { muted = false; sound.setVolume(1); }
    const v = interior ? 1 : 0;
    if (v !== view) { view = v; sound.setCfg({ view: v }); }
    const speed = state.cueSpeed ?? state.speed;
    const next = {
      throttle: Math.round((state.throttle ?? 0) * 100) / 100,
      brake: Math.round((state.serviceBrake ? 1 : 0) * 100) / 100,
      steer: Math.round(Math.max(-1, Math.min(1, state.steer ?? 0)) * 100) / 100,
      handbrake: state.handbrake ? 1 : 0,
      kerb: kerb ? 1 : 0,
      // Slides & drift: nada keracungnya ikut kecepatan selip di dalam inti audio.
      skid: Math.round(Math.min(1, (state.tireNoise ?? 0) * 0.62 * Math.min(1, speed / 11) + (state.handbrake && speed > 2.5 ? 0.3 : 0)) * 100) / 100,
    };
      // M-DCT mode "D": menyalakan gas saat netral langsung mengengkel gigi 1, seperti mobil otomatis.
      if (trans === 'dct' && sound.state.gear === 0 && sound.state.es === 3 && next.throttle > 0.25) sound.cmd('up');
      const diff: Msg = {};
      let any = false;
      (Object.keys(next) as (keyof typeof next)[]).forEach(k => { if (sent[k] !== next[k]) { sent[k] = next[k]; diff[k] = next[k]; any = true; } });
      if (any) postInputs(diff);
    }

  /** Sinkronkan simulasi audio ke grid start (setelah R / ganti lintasan). */
  function grid() { if (sound.ready) sound.cmd('grid'); }

  /** E / Q: naik / turun gigi (Manual 6, atau override M-DCT). */
  function shift(dir: number) { if (enabled && sound.ready) sound.cmd(dir > 0 ? 'up' : 'down'); }

  function setDrivetrain(cfg: BmwCfg) {
    trans = cfg.trans;
    sound.setCfg({ engine: cfg.engine, trans: cfg.trans, auto: cfg.trans === 'dct' ? 1 : 0 });
  }

  function silence() { if (started) { muted = true; sound.setVolume(0); } }
  function wake() { if (started && enabled) { muted = false; sound.setVolume(1); } }

  function setEnabled(value: boolean) {
    enabled = value;
    if (started) sound.setVolume(value ? 1 : 0);
    if (value) unlock();
  }

  /** Lonceng skor (bank / link / lost) — dipertahankan dari HUD lama. */
  function feedback(type: 'link' | 'bank' | 'lost') {
    if (!sound.ctx || !enabled || sound.ctx.state !== 'running') return;
    const ctx = sound.ctx, level = ctx.createGain(), tone = ctx.createOscillator(), t = ctx.currentTime;
    const notes = type === 'bank' ? [489, 734] : type === 'link' ? [371, 557] : [194, 146];
    tone.type = 'triangle';
    tone.frequency.setValueAtTime(notes[0], t);
    tone.frequency.setValueAtTime(notes[1], t + .07);
    level.gain.setValueAtTime(.001, t);
    level.gain.exponentialRampToValueAtTime(type === 'lost' ? .039 : .052, t + .024);
    level.gain.exponentialRampToValueAtTime(.001, t + .194);
    tone.connect(level); level.connect(ctx.destination);
    tone.start(t); tone.stop(t + .206);
    tone.onended = () => level.disconnect();
  }

  return { unlock, sample, grid, shift, setDrivetrain, silence, wake, setEnabled, feedback, dispose: () => sound.dispose() };
}

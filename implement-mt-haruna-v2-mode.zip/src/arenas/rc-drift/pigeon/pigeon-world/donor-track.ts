import * as THREE from 'three';
import { fbm, smoothstep, lerp } from './noise';

// ---------------------------------------------------------------------------
// The touge: a closed mountain loop. Points are (x, y, z) in metres.
// ---------------------------------------------------------------------------
const controlPoints: [number, number, number][] = [
  [0, 0, 0],
  [40, 1.5, -22],
  [78, 4, -30],
  [105, 7, -10],
  [112, 10, 25],
  [100, 13, 55],
  [118, 16, 85],
  [100, 19, 115],
  [60, 21, 125],
  [30, 22, 105],
  [0, 23, 118],
  [-40, 22, 130],
  [-80, 20, 110],
  [-95, 17, 75],
  [-120, 14, 50],
  [-135, 11, 10],
  [-115, 8, -25],
  [-80, 5, -45],
  [-45, 2.5, -40],
  [-20, 1, -15],
];

export const ROAD_WIDTH = 6.4; // asphalt width
export const GUTTER_WIDTH = 0.55;
export const SHOULDER = 1.1;

export const curve = new THREE.CatmullRomCurve3(
  controlPoints.map((p) => new THREE.Vector3(p[0], p[1], p[2])),
  true,
  'centripetal',
  0.5,
);

export const TRACK_LENGTH = curve.getLength();

// Dense samples for distance queries
const SAMPLES = 1400;
export const samplePts: THREE.Vector3[] = curve.getSpacedPoints(SAMPLES).slice(0, SAMPLES); // drop duplicated closing point
export const sampleTan: THREE.Vector3[] = [];
for (let i = 0; i < samplePts.length; i++) {
  const a = samplePts[i];
  const b = samplePts[(i + 1) % samplePts.length];
  sampleTan.push(new THREE.Vector3().subVectors(b, a).setY(0).normalize());
}

export interface RoadQuery {
  dist: number; // unsigned lateral distance to centerline (xz)
  signed: number; // signed lateral (positive = right of travel direction)
  height: number; // road surface height at that point
  index: number;
  t: number; // 0..1 along track
  tangent: THREE.Vector3;
}

const _q: RoadQuery = {
  dist: 0,
  signed: 0,
  height: 0,
  index: 0,
  t: 0,
  tangent: new THREE.Vector3(),
};

// Coarse-to-fine nearest sample search. Returns a shared object (copy if needed).
export function queryRoad(x: number, z: number, out: RoadQuery = _q): RoadQuery {
  let best = Infinity;
  let bi = 0;
  const n = samplePts.length;
  // coarse pass
  for (let i = 0; i < n; i += 6) {
    const p = samplePts[i];
    const dx = p.x - x;
    const dz = p.z - z;
    const d = dx * dx + dz * dz;
    if (d < best) {
      best = d;
      bi = i;
    }
  }
  // fine pass around best
  for (let k = -8; k <= 8; k++) {
    const i = (bi + k + n) % n;
    const p = samplePts[i];
    const dx = p.x - x;
    const dz = p.z - z;
    const d = dx * dx + dz * dz;
    if (d < best) {
      best = d;
      bi = i;
    }
  }
  // project on segment for accuracy
  const p0 = samplePts[bi];
  const p1 = samplePts[(bi + 1) % n];
  const pm = samplePts[(bi - 1 + n) % n];
  // choose neighbour segment closer
  let a = p0;
  let b = p1;
  const dNext = (p1.x - x) ** 2 + (p1.z - z) ** 2;
  const dPrev = (pm.x - x) ** 2 + (pm.z - z) ** 2;
  if (dPrev < dNext) {
    a = pm;
    b = p0;
  }
  const abx = b.x - a.x;
  const abz = b.z - a.z;
  const len2 = abx * abx + abz * abz || 1;
  let s = ((x - a.x) * abx + (z - a.z) * abz) / len2;
  s = Math.max(0, Math.min(1, s));
  const px = a.x + abx * s;
  const pz = a.z + abz * s;
  const py = a.y + (b.y - a.y) * s;
  const dx = x - px;
  const dz = z - pz;
  const dist = Math.sqrt(dx * dx + dz * dz);
  const tx = abx / Math.sqrt(len2);
  const tz = abz / Math.sqrt(len2);
  // right vector of travel direction (tx, tz) is (-tz, tx)... choose sign convention:
  const rightx = -tz;
  const rightz = tx;
  const signed = dx * rightx + dz * rightz;
  out.dist = dist;
  out.signed = signed;
  out.height = py;
  out.index = bi;
  out.t = bi / n;
  out.tangent.set(tx, 0, tz);
  return out;
}

// ---------------------------------------------------------------------------
// Terrain height: embankment on the right (uphill) side, drop-off on the left.
// ---------------------------------------------------------------------------
export function wildHeight(x: number, z: number) {
  const n1 = fbm(x * 0.012 + 10, z * 0.012 + 3, 4) - 0.5;
  const n2 = fbm(x * 0.05, z * 0.05, 3) - 0.5;
  return n1 * 46 + n2 * 6;
}

export const EDGE = ROAD_WIDTH / 2 + GUTTER_WIDTH;
export const CORRIDOR = 14; // the curve-following corridor mesh covers |lateral| <= CORRIDOR

// Cross-section profile relative to the road surface. beyond = distance past the gutter.
export function bankProfile(beyond: number, uphill: boolean, x: number, z: number) {
  if (beyond <= 0) return -0.06;
  const rough = (fbm(x * 0.35, z * 0.35, 2) - 0.5) * 0.7 * smoothstep(0.2, 1.4, beyond);
  if (uphill) {
    // cut bank right behind the gutter: steep for ~3m, then easing uphill
    const r = Math.max(0, beyond - 0.35);
    return Math.min(r, 3.2) * 1.3 + Math.max(0, r - 3.2) * 0.5 + rough;
  }
  // downhill: narrow soft shoulder, then falls away
  const r = Math.max(0, beyond - 0.9);
  return -r * 0.7 - Math.max(0, beyond - 6) * 0.3 + rough;
}

export function terrainHeight(x: number, z: number): number {
  const q = queryRoad(x, z);
  const d = q.dist;
  let h = q.height + bankProfile(d - EDGE, q.signed > 0, x, z);
  // blend to wild terrain far from road
  const w = smoothstep(20, 60, d);
  if (w > 0) {
    const wild = wildHeight(x, z) + q.height + (q.signed > 0 ? 14 : -10);
    h = lerp(h, wild, w);
  }
  return h;
}

// Height used by the big background grid: dips under the corridor mesh so the
// coarse grid never pokes through the road or the embankment.
export function gridHeight(x: number, z: number): number {
  const q = queryRoad(x, z);
  const h = terrainHeight(x, z);
  if (q.dist < CORRIDOR - 1.2) return h - 1.0;
  return h;
}

export const roadFrameAt = (() => {
  const pos = new THREE.Vector3();
  const tan = new THREE.Vector3();
  return (t: number) => {
    curve.getPointAt(((t % 1) + 1) % 1, pos);
    curve.getTangentAt(((t % 1) + 1) % 1, tan);
    return { pos, tan };
  };
})();

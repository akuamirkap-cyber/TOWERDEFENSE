import { Vector3, type Mesh } from 'three';
import type { Ground, GroundKind } from './suspension';

type Triangle = { x: number; z: number; y: number; bx: number; bz: number; by: number; cx: number; cz: number; cy: number; inverseArea: number; kind: GroundKind };
const CELL = 8;
const key = (x: number, z: number) => x * 65536 + z;

export function createRoadContact() {
  const tiles = new Map<number, Triangle[]>();
  const a = new Vector3(), b = new Vector3(), c = new Vector3();

  function add(mesh: Mesh, kind: GroundKind) {
    mesh.updateWorldMatrix(true, false);
    const position = mesh.geometry.getAttribute('position'), index = mesh.geometry.index;
    const count = index?.count ?? position.count;
    for (let i = 0; i < count; i += 3) {
      a.fromBufferAttribute(position, index ? index.getX(i) : i).applyMatrix4(mesh.matrixWorld);
      b.fromBufferAttribute(position, index ? index.getX(i + 1) : i + 1).applyMatrix4(mesh.matrixWorld);
      c.fromBufferAttribute(position, index ? index.getX(i + 2) : i + 2).applyMatrix4(mesh.matrixWorld);
      const bx = b.x - a.x, bz = b.z - a.z, cx = c.x - a.x, cz = c.z - a.z;
      const area = bx * cz - bz * cx;
      if (Math.abs(area) < 1e-10) continue;
      const tri = { x: a.x, z: a.z, y: a.y, bx, bz, by: b.y - a.y, cx, cz, cy: c.y - a.y, inverseArea: 1 / area, kind };
      const x0 = Math.floor(Math.min(a.x, b.x, c.x) / CELL), x1 = Math.floor(Math.max(a.x, b.x, c.x) / CELL);
      const z0 = Math.floor(Math.min(a.z, b.z, c.z) / CELL), z1 = Math.floor(Math.max(a.z, b.z, c.z) / CELL);
      for (let x = x0; x <= x1; x++) for (let z = z0; z <= z1; z++) {
        const k = key(x, z), tile = tiles.get(k);
        if (tile) tile.push(tri); else tiles.set(k, [tri]);
      }
    }
  }

  function sample(x: number, z: number, ground: Ground) {
    const tile = tiles.get(key(Math.floor(x / CELL), Math.floor(z / CELL)));
    if (!tile) return;
    for (const t of tile) {
      const dx = x - t.x, dz = z - t.z;
      const u = (dx * t.cz - dz * t.cx) * t.inverseArea;
      if (u < -0.000001) continue;
      const v = (t.bx * dz - t.bz * dx) * t.inverseArea;
      if (v < -0.000001 || u + v > 1.000001) continue;
      const y = t.y + u * t.by + v * t.cy;
      if (y > ground.y) { ground.y = y; ground.kind = t.kind; }
    }
  }

  return { add, sample };
}

export type RoadContact = ReturnType<typeof createRoadContact>;
import { makeAsphalt, makeBark, makeCedarSpray, makeConcrete, makeCurveSign, makeForestFloor, makeLeafSpray, makeRealisticGrass, makeShaftGradient, makeSmokeSprite, makeUndergrowthCard } from './textures';

export function createPigeonAssets() {
  const asphalt = makeAsphalt();
  const bark = makeBark();
  bark.repeat.set(2, 6);
  const concrete = makeConcrete(), forestFloor = makeForestFloor(), realisticGrass = makeRealisticGrass();
  const sign = makeCurveSign(), shafts = makeShaftGradient(), motes = makeSmokeSprite();
  const leafA = makeLeafSpray(101), leafB = makeLeafSpray(202), cedar = makeCedarSpray(303), bush = makeUndergrowthCard();
  const textures = new Set([...Object.values(asphalt), bark, concrete, forestFloor, realisticGrass, sign, shafts, motes, leafA, leafB, cedar, bush]);
  return { asphalt, bark, concrete, forestFloor, realisticGrass, sign, shafts, motes, leafA, leafB, cedar, bush, textures,
    dispose() { for (const texture of textures) texture.dispose(); } };
}

export type PigeonAssets = ReturnType<typeof createPigeonAssets>;
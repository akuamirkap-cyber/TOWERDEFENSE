import type * as Three from 'three';

/**
 * "Onboard camera" look for the drive view. Every effect behind the individual cinematic switches lives here:
 *  - Kontras & Exposure: over-driven sensor highlights (sky & paint clip) — driver skin sees only 10% of the contrast kick
 *  - Tone Mapping ACES Filmic: the filmic curve that deepens shadows under the car and in the smoke
 *  - Bloom & Glare Halus: thresholded quarter-res blur chain (brake lamps, exhaust pops, sun on the bonnet) at 10% strength
 *  - Motion Blur (shutter ~1/60): radial streaks driven by road speed, kept sharp around the subject
 *  - Chromatic Aberration & Film Grain: edge fringing and fine animated grain
 *  - Depth of Field rendah: shallow far-field focus from the depth buffer
 * With all flags off the result is the untouched linear image, which is the "sebelum" comparison.
 */
export type FilmComposite = {
  /** God rays: angular sun shafts from the sun's screen position (high-noon beam) */
  rays: boolean;
  /** Kontras & Exposure (overexposed sky & paint); driver skin gets 10% of the contrast kick */
  contrastExposure: boolean;
  /** Tone Mapping ACES Filmic (denser, more voluminous shadows) */
  aces: boolean;
  /** Bloom & Glare Halus, hard-capped at 10% of the artistic strength */
  bloom: boolean;
  /** Motion Blur, virtual shutter ~1/60 */
  motionBlur: boolean;
  /** Chromatic Aberration & Film Grain */
  grain: boolean;
  /** Depth of Field rendah */
  dof: boolean;
};

export type CinematicFrame = {
  camera: Three.PerspectiveCamera;
  /** screen-space sun position (0..1) and 0..1 visibility (0 = behind camera / culled) */
  sunUv: { x: number; y: number };
  sunOn: number;
  /** world-space velocity of the viewed car (m/s) */
  vx: number; vz: number; speed: number;
  /** seconds; drives the grain */
  time: number;
  /** base exposure the plain renderer would have used */
  exposure: number;
  view: 'chase' | 'overhead' | 'cockpit' | 'bumper';
  /** 0..1 render budget scale, lower drops tap counts */
  quality: number;
  /** individual on/off flags — see FilmComposite */
  flags: FilmComposite;
};

export const BLOOM_NORMAL = 0.58;
/** Bloom & Glare Halus runs at ~10% of normal strength on request. */
export const BLOOM_STRENGTH = BLOOM_NORMAL * 0.10;
/** The contrast kick lands at 10% strength on driver skin tones. */
export const SKIN_CONTRAST_RATIO = 0.10;

const ACES = /* glsl */`
  vec3 aces(vec3 x) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
  }`;

export function createCinematicPost(T: typeof Three, renderer: Three.WebGLRenderer, multisampling = 4) {
  const webgl2 = renderer.capabilities.isWebGL2;
  const depthTexture = new T.DepthTexture(2, 2);
  depthTexture.type = T.UnsignedIntType;
  const sceneTarget = new T.WebGLRenderTarget(2, 2, {
    type: webgl2 ? T.HalfFloatType : T.UnsignedByteType,
    depthTexture,
    depthBuffer: true,
    samples: webgl2 ? multisampling : 0,
  });
  sceneTarget.texture.minFilter = T.LinearFilter;
  sceneTarget.texture.magFilter = T.LinearFilter;
  const small = (w: number, h: number) => {
    const target = new T.WebGLRenderTarget(w, h, { type: webgl2 ? T.HalfFloatType : T.UnsignedByteType, depthBuffer: false });
    target.texture.minFilter = T.LinearFilter; target.texture.magFilter = T.LinearFilter;
    return target;
  };
  let bright = small(2, 2), blurA = small(2, 2), blurB = small(2, 2);
  let width = 0, height = 0;

  const screen = new T.Scene(), flatCamera = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const quadGeometry = new T.BufferGeometry();
  quadGeometry.setAttribute('position', new T.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  quadGeometry.setAttribute('uv', new T.Float32BufferAttribute([0, 0, 2, 0, 0, 2], 2));
  const quad = new T.Mesh(quadGeometry); quad.frustumCulled = false; screen.add(quad);

  const vertex = /* glsl */`varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

  const brightMaterial = new T.ShaderMaterial({
    uniforms: { image: { value: null as Three.Texture | null }, threshold: { value: 0.86 }, knee: { value: 0.42 }, exposure: { value: 1 } },
    depthTest: false, depthWrite: false, toneMapped: false, blending: T.NoBlending,
    vertexShader: vertex,
    fragmentShader: /* glsl */`
      uniform sampler2D image; uniform float threshold, knee, exposure; varying vec2 vUv;
      void main() {
        vec3 c = texture2D(image, vUv).rgb * exposure;
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float soft = clamp((l - threshold + knee) / (2.0 * knee), 0.0, 1.0);
        soft = soft * soft * knee;
        float w = max(l - threshold, soft) / max(l, 1e-4);
        gl_FragColor = vec4(c * w, 1.0);
      }`,
  });
  const blurMaterial = new T.ShaderMaterial({
    uniforms: { image: { value: null as Three.Texture | null }, direction: { value: new T.Vector2(1, 0) } },
    depthTest: false, depthWrite: false, toneMapped: false, blending: T.NoBlending,
    vertexShader: vertex,
    fragmentShader: /* glsl */`
      uniform sampler2D image; uniform vec2 direction; varying vec2 vUv;
      void main() {
        vec3 sum = texture2D(image, vUv).rgb * 0.2270;
        sum += texture2D(image, vUv + direction * 1.3846).rgb * 0.3162;
        sum += texture2D(image, vUv - direction * 1.3846).rgb * 0.3162;
        sum += texture2D(image, vUv + direction * 3.2308).rgb * 0.0703;
        sum += texture2D(image, vUv - direction * 3.2308).rgb * 0.0703;
        gl_FragColor = vec4(sum, 1.0);
      }`,
  });
  const compositeUniforms = {
    image: { value: null as Three.Texture | null },
    bloom: { value: null as Three.Texture | null },
    depth: { value: null as Three.Texture | null },
    resolution: { value: new T.Vector2(1, 1) },
    cameraNear: { value: .1 }, cameraFar: { value: 1000 },
    exposure: { value: 1.18 }, contrast: { value: 1.12 }, saturation: { value: 1.06 },
    bloomStrength: { value: BLOOM_STRENGTH },
    toneContrast: { value: 1 }, acesOn: { value: 0 },
    vanish: { value: new T.Vector2(.5, .55) }, motion: { value: 0 }, motionInner: { value: .18 },
    aberration: { value: 1 }, grain: { value: .045 },
    focusStart: { value: 40 }, focusRange: { value: 160 }, dofAmount: { value: 1 },
    sunUV: { value: new T.Vector2(.5, .72) }, sunOn: { value: 0 }, rayStrength: { value: .95 },
    time: { value: 0 },
  };
  const compositeMaterial = new T.ShaderMaterial({
    uniforms: compositeUniforms,
    defines: { TAPS: 6, SKIN_CONTRAST: SKIN_CONTRAST_RATIO },
    depthTest: false, depthWrite: false, toneMapped: false, blending: T.NoBlending,
    vertexShader: vertex,
    fragmentShader: /* glsl */`
      uniform sampler2D image, bloom, depth;
      uniform vec2 resolution, vanish;
      uniform float cameraNear, cameraFar, exposure, contrast, saturation, bloomStrength, motion, motionInner;
      uniform float aberration, grain, focusStart, focusRange, dofAmount, time;
      uniform vec2 sunUV; uniform float sunOn, rayStrength;
      uniform float toneContrast, acesOn;
      varying vec2 vUv;
      ${ACES}
      float linearDepth(vec2 uv) {
        float z = texture2D(depth, uv).x * 2.0 - 1.0;
        return (2.0 * cameraNear * cameraFar) / (cameraFar + cameraNear - z * (cameraFar - cameraNear));
      }
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7)) + time * 37.0) * 43758.5453); }
      vec3 rgbToHsv(vec3 c) {
        vec4 k = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
        vec4 p = mix(vec4(c.bg, k.wz), vec4(c.gb, k.xy), step(c.b, c.g));
        vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
        float d = q.x - min(q.w, q.y);
        return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + 1e-5)), d / (q.x + 1e-5), q.x);
      }
      // Warm-hue window that matches glove skin under sunlight (through either skin palette).
      float skinMask(vec3 c) {
        vec3 hsv = rgbToHsv(clamp(c, 0.0, 1.0));
        // .x = hue, .y = saturation, .z = value (GLSL ES has no .h/.s/.v swizzles)
        float hueW = smoothstep(0.015, 0.055, hsv.x) * (1.0 - smoothstep(0.125, 0.185, hsv.x));
        float satW = smoothstep(0.12, 0.28, hsv.y) * (1.0 - smoothstep(0.78, 0.97, hsv.y));
        float valW = smoothstep(0.03, 0.14, hsv.z);
        return clamp(hueW * satW * valW, 0.0, 1.0);
      }
      void main() {
        vec2 uv = vUv;
        vec2 texel = 1.0 / resolution;
        vec2 fromCentre = uv - 0.5;
        float edge = length(fromCentre * vec2(resolution.x / resolution.y, 1.0));
        // Shutter streaks radiate from the vanishing point; the subject / road centre stays crisp.
        vec2 streak = uv - vanish;
        float radial = length(streak);
        float streakMask = smoothstep(motionInner, motionInner + 0.42, radial) * motion;
        vec2 streakStep = streak * (0.085 * streakMask) / float(TAPS);
        // Far-field focus: everything beyond focusStart softens up to a 5px circle of confusion.
        float d = linearDepth(uv);
        float coc = smoothstep(focusStart, focusStart + focusRange, d) * dofAmount * 5.0;
        // Lateral colour fringing grows towards the frame edges.
        vec2 fringe = fromCentre * edge * edge * aberration * 2.6 * texel * 1.6;
        vec3 sum = vec3(0.0); float total = 0.0;
        float ring = hash(uv * resolution) * 6.2831;
        for (int i = 0; i < TAPS; i++) {
          float t = float(i) / float(TAPS - 1) - 0.5;
          float a = ring + float(i) * 1.0472;
          vec2 disc = vec2(cos(a), sin(a)) * coc * texel * (0.35 + 0.65 * float(i) / float(TAPS - 1));
          vec2 p = uv + streakStep * float(i) * 2.0 - streakStep * float(TAPS - 1) + disc;
          float w = 1.0 - abs(t) * 0.5;
          vec3 c;
          c.r = texture2D(image, p + fringe).r;
          c.g = texture2D(image, p).g;
          c.b = texture2D(image, p - fringe).b;
          sum += c * w; total += w;
        }
        vec3 color = sum / total;
        vec3 glow = texture2D(bloom, uv).rgb;
        color = color * exposure + glow * bloomStrength;
        // Tone mapping is its own switch; off = flat sensor look.
        color = mix(color, aces(color), acesOn);
        // Kontras & Exposure switch: saturation + contrast kick, with skin tones (driver gloves / cabin)
        // held to 10% of the contrast effect so their colours stay true to the chosen skin palette.
        if (toneContrast > 0.5) {
          float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
          color = mix(vec3(luma), color, saturation);
          float skin = skinMask(color);
          float kick = mix(contrast, 1.0 + (contrast - 1.0) * float(SKIN_CONTRAST), skin);
          color = (color - 0.42) * kick + 0.42;
        }
        float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
        // High-noon god rays: angular streaks radiating from the sun, falling off with distance and facing.
        if (sunOn > 0.001) {
          vec2 aspectFix = vec2(resolution.x / resolution.y, 1.0);
          vec2 d = (uv - sunUV) * aspectFix;
          float dist = length(d);
          float ang = atan(d.y, d.x);
          float streak = pow(0.5 + 0.5 * sin(ang * 7.0 + 1.35), 2.5)
                       + 0.7 * pow(0.5 + 0.5 * sin(ang * 11.0 + 4.15), 2.0)
                       + 0.5 * pow(0.5 + 0.5 * sin(ang * 4.0 + 2.6), 4.0);
          float rays = streak * exp(-dist * 2.15) * sunOn;
          color += vec3(1.0, 0.88, 0.60) * rays * rayStrength;
        }
        // Fine grain, denser in the shadows (Chromatic Aberration & Film Grain).
        float n = hash(uv * resolution * 0.5) - 0.5;
        color += n * grain * (1.0 - luma * 0.6);
        color = clamp(color, 0.0, 1.0);
        gl_FragColor = vec4(color, 1.0);
        #include <colorspace_fragment>
      }`,
  });

  function resize() {
    const size = renderer.getDrawingBufferSize(new T.Vector2());
    const w = Math.max(2, Math.floor(size.x)), h = Math.max(2, Math.floor(size.y));
    if (w === width && h === height) return;
    width = w; height = h;
    sceneTarget.setSize(w, h);
    const bw = Math.max(2, Math.floor(w / 4)), bh = Math.max(2, Math.floor(h / 4));
    bright.setSize(bw, bh); blurA.setSize(bw, bh); blurB.setSize(bw, bh);
    compositeUniforms.resolution.value.set(w, h);
  }

  const forward = new T.Vector3(), aim = new T.Vector3();
  function render(scene: Three.Scene, frame: CinematicFrame) {
    resize();
    const { camera } = frame;
    const previousTarget = renderer.getRenderTarget();
    const previousToneMapping = renderer.toneMapping;
    const previousExposure = renderer.toneMappingExposure;
    // The HDR target keeps scene-linear values; the composite applies the filmic curve itself.
    renderer.toneMapping = T.NoToneMapping;
    renderer.setRenderTarget(sceneTarget);
    renderer.clear();
    renderer.render(scene, camera);
    renderer.toneMapping = previousToneMapping;
    renderer.toneMappingExposure = previousExposure;

    const { flags } = frame;
    // Kontras & Exposure lifts the sensor curves; off = stock linear passthrough.
    const exposure = flags.contrastExposure ? frame.exposure * 1.18 : frame.exposure;
    // Bloom runs at ~10% of normal strength, only when its switch is on.
    const bloomStrength = flags.bloom ? (frame.view === 'overhead' ? BLOOM_STRENGTH * .66 : BLOOM_STRENGTH) : 0;
    // Bloom: threshold at quarter res, two separable blur passes.
    let bloomSource: Three.Texture | null = null;
    if (flags.bloom) {
      quad.material = brightMaterial;
      brightMaterial.uniforms.image.value = sceneTarget.texture;
      brightMaterial.uniforms.exposure.value = exposure;
      renderer.setRenderTarget(bright); renderer.render(screen, flatCamera);
      quad.material = blurMaterial;
      const bw = bright.width, bh = bright.height;
      let source = bright;
      for (let pass = 0; pass < 2; pass++) {
        blurMaterial.uniforms.image.value = source.texture; blurMaterial.uniforms.direction.value.set((1 + pass * .6) / bw, 0);
        renderer.setRenderTarget(blurA); renderer.render(screen, flatCamera);
        blurMaterial.uniforms.image.value = blurA.texture; blurMaterial.uniforms.direction.value.set(0, (1 + pass * .6) / bh);
        renderer.setRenderTarget(blurB); renderer.render(screen, flatCamera);
        source = blurB;
      }
      bloomSource = source.texture;
    }

    // Vanishing point of the car's travel direction in screen space.
    const speed = Math.hypot(frame.vx, frame.vz);
    let motion = 0;
    if (flags.motionBlur && speed > .5) {
      forward.set(frame.vx / speed, 0, frame.vz / speed);
      aim.copy(camera.position).addScaledVector(forward, 80).project(camera);
      if (aim.z < 1 && Number.isFinite(aim.x) && Number.isFinite(aim.y)) {
        compositeUniforms.vanish.value.set(T.MathUtils.clamp(aim.x * .5 + .5, -.4, 1.4), T.MathUtils.clamp(aim.y * .5 + .5, -.4, 1.4));
        // 1/60 shutter at 60 km/h ramps to a 1/30 look near 140 km/h.
        motion = T.MathUtils.smoothstep(speed, 7, 38) * (frame.view === 'bumper' ? 1.15 : frame.view === 'cockpit' ? .85 : .95);
      }
    }
    const u = compositeUniforms;
    u.image.value = sceneTarget.texture; u.bloom.value = bloomSource ?? sceneTarget.texture; u.depth.value = depthTexture;
    u.cameraNear.value = camera.near; u.cameraFar.value = camera.far;
    u.exposure.value = exposure; u.time.value = frame.time % 1000;
    u.toneContrast.value = flags.contrastExposure ? 1 : 0;
    u.acesOn.value = flags.aces ? 1 : 0;
    u.motion.value = motion;
    u.motionInner.value = frame.view === 'chase' ? .22 : frame.view === 'cockpit' ? .16 : .12;
    u.aberration.value = flags.grain ? (frame.quality < .8 ? .7 : 1) : 0;
    u.grain.value = flags.grain ? .045 : 0;
    u.bloomStrength.value = bloomStrength;
    u.sunUV.value.set(frame.sunUv.x, frame.sunUv.y);
    u.sunOn.value = flags.rays ? frame.sunOn : 0;
    const taps = frame.quality < .7 ? 4 : 6;
    if (compositeMaterial.defines.TAPS !== taps) { compositeMaterial.defines.TAPS = taps; compositeMaterial.needsUpdate = true; }
    // Overhead framing keeps the far ground sharp; the onboard lenses focus a little in front of the bonnet.
    if (frame.view === 'overhead') { u.focusStart.value = 90; u.focusRange.value = 260; u.dofAmount.value = flags.dof ? .55 : 0; }
    else if (frame.view === 'cockpit') { u.focusStart.value = 34; u.focusRange.value = 150; u.dofAmount.value = flags.dof ? 1 : 0; }
    else { u.focusStart.value = 44; u.focusRange.value = 170; u.dofAmount.value = flags.dof ? 1 : 0; }
    quad.material = compositeMaterial;
    renderer.setRenderTarget(previousTarget);
    renderer.render(screen, flatCamera);
  }

  function dispose() {
    sceneTarget.dispose(); depthTexture.dispose(); bright.dispose(); blurA.dispose(); blurB.dispose();
    brightMaterial.dispose(); blurMaterial.dispose(); compositeMaterial.dispose(); quadGeometry.dispose();
  }
  return { render, dispose };
}

import * as THREE from 'three';
import { createRng, randRange, tileableFbm2D } from './noise';

export interface PBRTextureSet {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
}

function configureTexture(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  repeat = false,
  anisotropy = 8
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
  } else {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
  }
  tex.anisotropy = anisotropy;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

function heightToNormalCanvas(
  heightCanvas: HTMLCanvasElement,
  strength: number,
  wrap: boolean
): HTMLCanvasElement {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const srcCtx = heightCanvas.getContext('2d')!;
  const src = srcCtx.getImageData(0, 0, w, h).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = w;
  outCanvas.height = h;
  const outCtx = outCanvas.getContext('2d')!;
  const outImg = outCtx.createImageData(w, h);
  const dst = outImg.data;

  const sample = (x: number, y: number): number => {
    let sx = x;
    let sy = y;
    if (wrap) {
      sx = ((x % w) + w) % w;
      sy = ((y % h) + h) % h;
    } else {
      sx = Math.max(0, Math.min(w - 1, x));
      sy = Math.max(0, Math.min(h - 1, y));
    }
    return src[(sy * w + sx) * 4] / 255;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dx = (tr + 2 * r + br - (tl + 2 * l + bl)) * strength;
      const dy = (bl + 2 * b + br - (tl + 2 * t + tr)) * strength;
      const dz = 1.0;

      const invLen = 1.0 / Math.sqrt(dx * dx + dy * dy + dz * dz);
      const nx = -dx * invLen;
      const ny = -dy * invLen;
      const nz = dz * invLen;

      const idx = (y * w + x) * 4;
      dst[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }

  outCtx.putImageData(outImg, 0, 0);
  return outCanvas;
}

function drawWrapped(
  size: number,
  x: number,
  y: number,
  margin: number,
  drawFn: (ox: number, oy: number) => void
) {
  const oxList = [0];
  const oyList = [0];
  if (x < margin) oxList.push(size);
  if (x > size - margin) oxList.push(-size);
  if (y < margin) oyList.push(size);
  if (y > size - margin) oyList.push(-size);

  for (let i = 0; i < oxList.length; i++) {
    for (let j = 0; j < oyList.length; j++) {
      drawFn(x + oxList[i], y + oyList[j]);
    }
  }
}

function paintBotanicalLeaf(
  aCtx: CanvasRenderingContext2D,
  hCtx: CanvasRenderingContext2D,
  rCtx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  length: number,
  width: number,
  colorBase: string,
  colorTip: string,
  colorVein: string,
  lobed: boolean,
  heightLevel: number
) {
  const drawLeafOutline = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    if (lobed) {
      ctx.bezierCurveTo(length * 0.15, -width * 0.55, length * 0.32, -width * 0.85, length * 0.48, -width * 0.48);
      ctx.bezierCurveTo(length * 0.62, -width * 0.65, length * 0.82, -width * 0.35, length, 0);
      ctx.bezierCurveTo(length * 0.82, width * 0.35, length * 0.62, width * 0.65, length * 0.48, width * 0.48);
      ctx.bezierCurveTo(length * 0.32, width * 0.85, length * 0.15, width * 0.55, 0, 0);
    } else {
      ctx.bezierCurveTo(length * 0.22, -width * 0.68, length * 0.66, -width * 0.58, length, 0);
      ctx.bezierCurveTo(length * 0.66, width * 0.58, length * 0.22, width * 0.68, 0, 0);
    }
    ctx.closePath();
  };

  aCtx.save();
  aCtx.translate(x, y);
  aCtx.rotate(angle);

  const grad = aCtx.createLinearGradient(0, 0, length, 0);
  grad.addColorStop(0, colorBase);
  grad.addColorStop(0.58, colorTip);
  grad.addColorStop(1, colorTip);

  drawLeafOutline(aCtx);
  aCtx.fillStyle = grad;
  aCtx.fill();

  aCtx.save();
  aCtx.clip();
  aCtx.fillStyle = 'rgba(255, 255, 210, 0.11)';
  aCtx.fillRect(0, -width, length, width);
  aCtx.fillStyle = 'rgba(10, 28, 6, 0.12)';
  aCtx.fillRect(0, 0, length, width);
  aCtx.restore();

  aCtx.strokeStyle = colorVein;
  aCtx.lineWidth = Math.max(1.0, width * 0.045);
  aCtx.beginPath();
  aCtx.moveTo(0, 0);
  aCtx.lineTo(length * 0.94, 0);
  aCtx.stroke();

  aCtx.lineWidth = Math.max(0.65, width * 0.024);
  for (let v = 1; v <= 5; v++) {
    const t = v / 6.2;
    const vx = length * t;
    const span = width * (0.48 - Math.abs(t - 0.45) * 0.55);
    aCtx.beginPath();
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, -span);
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, span);
    aCtx.stroke();
  }
  aCtx.restore();

  hCtx.save();
  hCtx.translate(x, y);
  hCtx.rotate(angle);
  const hGrad = hCtx.createLinearGradient(0, -width * 0.7, 0, width * 0.7);
  const hHi = Math.min(255, heightLevel + 35);
  const hLo = Math.max(10, heightLevel - 28);
  hGrad.addColorStop(0, `rgb(${hHi},${hHi},${hHi})`);
  hGrad.addColorStop(0.5, `rgb(${hLo},${hLo},${hLo})`);
  hGrad.addColorStop(1, `rgb(${hHi},${hHi},${hHi})`);
  drawLeafOutline(hCtx);
  hCtx.fillStyle = hGrad;
  hCtx.fill();
  hCtx.restore();

  rCtx.save();
  rCtx.translate(x, y);
  rCtx.rotate(angle);
  drawLeafOutline(rCtx);
  rCtx.fillStyle = 'rgb(122, 122, 122)';
  rCtx.fill();
  rCtx.restore();
}

/**
 * 1. PHOTOREALISTIC FOREST FLOOR MULCH, PINE NEEDLES & DRY FALLEN LEAVES (1024x1024 seamless PBR)
 * From realistic-3d-nature-assets.zip
 */
function createForestFloorPBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(202604);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const macro = tileableFbm2D(u, v, 6, 4, 301);
      const micro = tileableFbm2D(u, v, 24, 3, 719);
      const grit = tileableFbm2D(u, v, 64, 2, 911);

      const val = macro * 0.55 + micro * 0.3 + grit * 0.15;
      const mossMask = Math.max(0, tileableFbm2D(u, v, 5, 3, 444) - 0.62) * 2.2;

      const idx = (y * size + x) * 4;
      let r = 34 + val * 44;
      let g = 25 + val * 32;
      let b = 17 + val * 22;

      if (mossMask > 0) {
        r = r * (1 - mossMask * 0.35) + 46 * (mossMask * 0.35);
        g = g * (1 - mossMask * 0.35) + 60 * (mossMask * 0.35);
        b = b * (1 - mossMask * 0.35) + 25 * (mossMask * 0.35);
      }

      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(35 + val * 70);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      const rVal = Math.round(188 + (1 - val) * 45);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const needlePalettes = [
    '#5c3e24', '#6e4b2c', '#7c5936', '#8c6b43',
    '#49321e', '#9d7e54', '#3d2918', '#a88c63',
  ];

  const drawNeedles = (count: number, minH: number, maxH: number) => {
    for (let i = 0; i < count; i++) {
      const x = rng() * size;
      const y = rng() * size;
      const len = randRange(rng, 18, 52);
      const angle = rng() * Math.PI * 2;
      const bend = randRange(rng, -8, 8);
      const width = randRange(rng, 0.9, 2.2);
      const col = needlePalettes[Math.floor(rng() * needlePalettes.length)];
      const hShade = Math.round(randRange(rng, minH, maxH));
      const rShade = Math.round(randRange(rng, 205, 240));

      drawWrapped(size, x, y, len + 8, (ox, oy) => {
        const ex = ox + Math.cos(angle) * len;
        const ey = oy + Math.sin(angle) * len;
        const cx = (ox + ex) * 0.5 - Math.sin(angle) * bend;
        const cy = (oy + ey) * 0.5 + Math.cos(angle) * bend;

        aCtx.strokeStyle = 'rgba(18, 11, 6, 0.35)';
        aCtx.lineWidth = width + 1.4;
        aCtx.lineCap = 'round';
        aCtx.beginPath();
        aCtx.moveTo(ox + 1.2, oy + 1.6);
        aCtx.quadraticCurveTo(cx + 1.2, cy + 1.6, ex + 1.2, ey + 1.6);
        aCtx.stroke();

        aCtx.strokeStyle = col;
        aCtx.lineWidth = width;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.quadraticCurveTo(cx, cy, ex, ey);
        aCtx.stroke();

        hCtx.strokeStyle = `rgb(${hShade},${hShade},${hShade})`;
        hCtx.lineWidth = width + 0.6;
        hCtx.lineCap = 'round';
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.quadraticCurveTo(cx, cy, ex, ey);
        hCtx.stroke();

        rCtx.strokeStyle = `rgb(${rShade},${rShade},${rShade})`;
        rCtx.lineWidth = width + 0.5;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.quadraticCurveTo(cx, cy, ex, ey);
        rCtx.stroke();
      });
    }
  };

  drawNeedles(2600, 75, 130);

  const leafColors = [
    { base: '#6f4827', edge: '#4d3018', vein: '#855c37' },
    { base: '#8a5d34', edge: '#5f3c1e', vein: '#a37548' },
    { base: '#b6976c', edge: '#896d49', vein: '#ccb088' },
    { base: '#c9b28a', edge: '#967e59', vein: '#dfd0ae' },
    { base: '#573a21', edge: '#372312', vein: '#6c492b' },
    { base: '#9e7446', edge: '#6f4f2c', vein: '#b58b5c' },
    { base: '#4a3523', edge: '#2b1d12', vein: '#5d442e' },
    { base: '#7d633d', edge: '#554126', vein: '#947950' },
  ];

  const drawDryLeafShape = (
    ctx: CanvasRenderingContext2D,
    len: number,
    wid: number,
    curl: number
  ) => {
    ctx.beginPath();
    ctx.moveTo(-len * 0.5, 0);
    ctx.bezierCurveTo(
      -len * 0.25,
      -wid * (0.95 + curl * 0.2),
      len * 0.22,
      -wid * (0.75 - curl * 0.15),
      len * 0.52,
      curl * wid * 0.25
    );
    ctx.bezierCurveTo(
      len * 0.22,
      wid * (0.85 + curl * 0.15),
      -len * 0.25,
      wid * (0.9 - curl * 0.2),
      -len * 0.5,
      0
    );
    ctx.closePath();
  };

  const leafCount = 1550;
  for (let i = 0; i < leafCount; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 16, 44);
    const wid = len * randRange(rng, 0.28, 0.52);
    const angle = rng() * Math.PI * 2;
    const curl = randRange(rng, -0.6, 0.6);
    const pal = leafColors[Math.floor(rng() * leafColors.length)];
    const progress = i / leafCount;
    const hBase = Math.round(95 + progress * 135);
    const rShade = Math.round(randRange(rng, 175, 232));

    drawWrapped(size, x, y, len + 12, (ox, oy) => {
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(angle);

      aCtx.save();
      aCtx.translate(2.0, 2.5);
      drawDryLeafShape(aCtx, len * 1.03, wid * 1.03, curl);
      aCtx.fillStyle = 'rgba(14, 9, 4, 0.42)';
      aCtx.fill();
      aCtx.restore();

      const grad = aCtx.createLinearGradient(0, -wid, 0, wid);
      grad.addColorStop(0, pal.edge);
      grad.addColorStop(0.45, pal.base);
      grad.addColorStop(0.8, pal.vein);
      grad.addColorStop(1, pal.edge);
      drawDryLeafShape(aCtx, len, wid, curl);
      aCtx.fillStyle = grad;
      aCtx.fill();

      aCtx.strokeStyle = pal.edge;
      aCtx.lineWidth = 0.85;
      aCtx.stroke();

      aCtx.strokeStyle = pal.vein;
      aCtx.lineWidth = 0.8;
      aCtx.beginPath();
      aCtx.moveTo(-len * 0.48, 0);
      aCtx.quadraticCurveTo(0, curl * wid * 0.15, len * 0.48, curl * wid * 0.22);
      aCtx.stroke();
      aCtx.restore();

      hCtx.save();
      hCtx.translate(ox, oy);
      hCtx.rotate(angle);
      const hGrad = hCtx.createLinearGradient(0, -wid, 0, wid);
      const hLow = Math.max(20, hBase - 38);
      const hHigh = Math.min(255, hBase + 22);
      hGrad.addColorStop(0, `rgb(${hHigh},${hHigh},${hHigh})`);
      hGrad.addColorStop(0.45, `rgb(${hLow},${hLow},${hLow})`);
      hGrad.addColorStop(0.55, `rgb(${hBase},${hBase},${hBase})`);
      hGrad.addColorStop(1, `rgb(${hHigh},${hHigh},${hHigh})`);
      drawDryLeafShape(hCtx, len, wid, curl);
      hCtx.fillStyle = hGrad;
      hCtx.fill();
      hCtx.restore();

      rCtx.save();
      rCtx.translate(ox, oy);
      rCtx.rotate(angle);
      drawDryLeafShape(rCtx, len, wid, curl);
      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fill();
      rCtx.restore();
    });

    if (i === 950) {
      drawNeedles(1200, 145, 220);
    }
  }

  for (let i = 0; i < 95; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 22, 75);
    const angle = rng() * Math.PI * 2;
    const thick = randRange(rng, 2.0, 4.8);
    const twigCol = rng() > 0.45 ? '#6e5c4a' : '#897a68';

    drawWrapped(size, x, y, len + 10, (ox, oy) => {
      const ex = ox + Math.cos(angle) * len;
      const ey = oy + Math.sin(angle) * len;
      const mx = (ox + ex) * 0.5 + randRange(rng, -5, 5);
      const my = (oy + ey) * 0.5 + randRange(rng, -5, 5);

      aCtx.strokeStyle = 'rgba(12, 8, 5, 0.5)';
      aCtx.lineWidth = thick + 2;
      aCtx.lineCap = 'round';
      aCtx.beginPath();
      aCtx.moveTo(ox + 2, oy + 2.5);
      aCtx.lineTo(mx + 2, my + 2.5);
      aCtx.lineTo(ex + 2, ey + 2.5);
      aCtx.stroke();

      aCtx.strokeStyle = twigCol;
      aCtx.lineWidth = thick;
      aCtx.beginPath();
      aCtx.moveTo(ox, oy);
      aCtx.lineTo(mx, my);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      hCtx.strokeStyle = 'rgb(245,245,245)';
      hCtx.lineWidth = thick + 1;
      hCtx.lineCap = 'round';
      hCtx.beginPath();
      hCtx.moveTo(ox, oy);
      hCtx.lineTo(mx, my);
      hCtx.lineTo(ex, ey);
      hCtx.stroke();
    });
  }

  drawNeedles(650, 195, 248);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.8, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 2. SINGLE DRY FALLEN LEAF ALPHA CARD (256x256) from realistic-3d-nature-assets.zip
 */
function createDryLeafCardPBR(anisotropy: number): PBRTextureSet {
  const size = 256;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(30,30,30)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(210,210,210)';
  rCtx.fillRect(0, 0, size, size);

  paintBotanicalLeaf(
    aCtx,
    hCtx,
    rCtx,
    size * 0.08,
    size * 0.5,
    0,
    size * 0.84,
    size * 0.42,
    '#b8a384',
    '#e3d4b8',
    '#cbb796',
    true,
    170
  );

  aCtx.strokeStyle = '#6e583f';
  aCtx.lineWidth = 4;
  aCtx.beginPath();
  aCtx.moveTo(size * 0.02, size * 0.5);
  aCtx.lineTo(size * 0.14, size * 0.5);
  aCtx.stroke();

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.4, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 3. MOSSY FOREST STONE & WEATHERED ROADSIDE CURB PBR (512x512 seamless)
 */
function createStonePBR(mode: 'rock' | 'curb', anisotropy: number): PBRTextureSet {
  const size = 512;
  const seed = mode === 'rock' ? 610 : 620;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n1 = tileableFbm2D(u, v, 8, 4, seed);
      const n2 = tileableFbm2D(u, v, 24, 3, seed + 55);
      const val = n1 * 0.68 + n2 * 0.32;
      const moss = Math.max(0, tileableFbm2D(u, v, 5, 3, seed + 99) - (mode === 'rock' ? 0.48 : 0.62)) * 2.3;

      let r = mode === 'rock' ? 56 + val * 58 : 112 + val * 62;
      let g = mode === 'rock' ? 55 + val * 56 : 112 + val * 60;
      let b = mode === 'rock' ? 52 + val * 52 : 106 + val * 55;

      if (moss > 0) {
        const m = Math.min(0.75, moss);
        r = r * (1 - m) + 52 * m;
        g = g * (1 - m) + 74 * m;
        b = b * (1 - m) + 29 * m;
      }

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hv = Math.round(val * 255);
      hImg.data[idx] = hv;
      hImg.data[idx + 1] = hv;
      hImg.data[idx + 2] = hv;
      hImg.data[idx + 3] = 255;

      const rv = Math.round(190 + (1 - val) * 58);
      rImg.data[idx] = rv;
      rImg.data[idx + 1] = rv;
      rImg.data[idx + 2] = rv;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 3.0, true);
  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 4. PHOTOREALISTIC WEATHERED JAPANESE MOUNTAIN ASPHALT PBR (1024x1024 seamless)
 * From realistic-3d-nature-assets.zip
 */
function createAsphaltPBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(8686);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;

      const macro = tileableFbm2D(u, v, 4, 4, 811);
      const med = tileableFbm2D(u, v, 18, 3, 823);
      const grain = tileableFbm2D(u, v, 96, 2, 839);
      const micro = tileableFbm2D(u, v, 210, 2, 853);

      const val = macro * 0.34 + med * 0.24 + grain * 0.25 + micro * 0.17;
      const base = 76 + val * 62;

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.min(255, base * 0.985);
      aImg.data[idx + 1] = Math.min(255, base * 1.0);
      aImg.data[idx + 2] = Math.min(255, base * 1.035);
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(70 + grain * 105 + micro * 55);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      const rVal = Math.round(182 + (1 - grain) * 52);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const stoneTones = [
    '#9fa5aa', '#878d92', '#b5babd', '#52565a', '#3e4246', '#797e82', '#8b877e',
  ];

  for (let i = 0; i < 16500; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const rx = randRange(rng, 1.0, 3.2);
    const ry = randRange(rng, 0.9, 2.8);
    const rot = rng() * Math.PI;
    const col = stoneTones[Math.floor(rng() * stoneTones.length)];
    const isBright = col === '#b5babd' || col === '#9fa5aa';
    const isDark = col === '#3e4246' || col === '#52565a';
    const hShade = isDark
      ? Math.round(randRange(rng, 35, 85))
      : Math.round(randRange(rng, 170, 245));
    const rShade = isBright
      ? Math.round(randRange(rng, 138, 175))
      : Math.round(randRange(rng, 196, 240));

    drawWrapped(size, x, y, 6, (ox, oy) => {
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(rot);
      aCtx.fillStyle = col;
      aCtx.fillRect(-rx * 0.5, -ry * 0.5, rx, ry);
      aCtx.restore();

      hCtx.fillStyle = `rgb(${hShade},${hShade},${hShade})`;
      hCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);

      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);
    });
  }

  for (let c = 0; c < 14; c++) {
    let cx = rng() * size;
    let cy = rng() * size;
    let ang = rng() * Math.PI * 2;
    const segs = Math.floor(randRange(rng, 12, 30));

    for (let s = 0; s < segs; s++) {
      const step = randRange(rng, 8, 22);
      ang += randRange(rng, -0.42, 0.42);
      const nx = cx + Math.cos(ang) * step;
      const ny = cy + Math.sin(ang) * step;
      const w = randRange(rng, 0.8, 2.0);

      drawWrapped(size, cx, cy, 30, (ox, oy) => {
        const dx = nx - cx;
        const dy = ny - cy;
        aCtx.strokeStyle = 'rgba(26, 28, 30, 0.52)';
        aCtx.lineWidth = w;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.lineTo(ox + dx, oy + dy);
        aCtx.stroke();

        hCtx.strokeStyle = 'rgb(20, 20, 20)';
        hCtx.lineWidth = w + 0.8;
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.lineTo(ox + dx, oy + dy);
        hCtx.stroke();

        rCtx.strokeStyle = 'rgb(245, 245, 245)';
        rCtx.lineWidth = w + 1.0;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.lineTo(ox + dx, oy + dy);
        rCtx.stroke();
      });

      cx = ((nx % size) + size) % size;
      cy = ((ny % size) + size) % size;
    }
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.35, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

export function createV3SurfaceTextures(maxAniso = 12) {
  const anisotropy = Math.min(maxAniso, 12);
  const forestFloor = createForestFloorPBR(anisotropy);
  const asphalt = createAsphaltPBR(anisotropy);
  const weatheredCurb = createStonePBR('curb', anisotropy);
  const mossyRock = createStonePBR('rock', anisotropy);
  const dryLeafCard = createDryLeafCardPBR(anisotropy);

  const textures = new Set<THREE.Texture>([
    forestFloor.map, forestFloor.normalMap, forestFloor.roughnessMap,
    asphalt.map, asphalt.normalMap, asphalt.roughnessMap,
    weatheredCurb.map, weatheredCurb.normalMap, weatheredCurb.roughnessMap,
    mossyRock.map, mossyRock.normalMap, mossyRock.roughnessMap,
    dryLeafCard.map, dryLeafCard.normalMap, dryLeafCard.roughnessMap,
  ]);

  return {
    forestFloor,
    asphalt,
    weatheredCurb,
    mossyRock,
    dryLeafCard,
    textures,
    dispose() {
      for (const t of textures) t.dispose();
    },
  };
}

export type V3SurfaceTextureSet = ReturnType<typeof createV3SurfaceTextures>;

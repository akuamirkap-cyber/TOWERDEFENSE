import * as THREE from 'three';
import type { PBRTextureSet, V3SurfaceTextureSet } from './textures';

/**
 * Forest floor dead-leaf mulch material (100% from realistic-3d-nature-assets.zip)
 * with seamless world-space macro moisture/dryness breakup so embankments never look tiled.
 */
export function createV3ForestFloorMaterial(
  tex: PBRTextureSet,
  opts?: { farSkyline?: boolean; doubleSide?: boolean }
): THREE.MeshStandardMaterial {
  const farSkyline = Boolean(opts?.farSkyline);
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.75, 1.75),
    roughnessMap: tex.roughnessMap,
    roughness: 0.96,
    metalness: 0.0,
    vertexColors: true,
    envMapIntensity: 0.72,
    side: opts?.doubleSide ? THREE.DoubleSide : THREE.FrontSide,
  });

  mat.customProgramCacheKey = () => `v3-forest-floor-macro-pbr-${farSkyline ? 1 : 0}-${opts?.doubleSide ? 1 : 0}`;
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vFloorWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    let frag = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        float hashFloor(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float vNoiseFloor(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashFloor(i);
          float b = hashFloor(i + vec2(1.0, 0.0));
          float c = hashFloor(i + vec2(0.0, 1.0));
          float d = hashFloor(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float macro1 = vNoiseFloor(vFloorWorldPos.xz * 0.28);
        float macro2 = vNoiseFloor(vFloorWorldPos.xz * 0.85 + vec2(7.3, 4.1));
        float patchVar = macro1 * 0.65 + macro2 * 0.35;
        vec3 dampTint = vec3(0.76, 0.72, 0.68);
        vec3 dryLitTint = vec3(1.16, 1.11, 1.03);
        diffuseColor.rgb *= mix(dampTint, dryLitTint, smoothstep(0.22, 0.78, patchVar));
        `
      );

    if (farSkyline) {
      frag = frag.replace('#include <fog_fragment>', `
        #ifdef USE_FOG
          #ifdef FOG_EXP2
            float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
          #else
            float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
          #endif
          fogFactor = min(fogFactor, 0.84);
          gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
        #endif
      `);
    }

    shader.fragmentShader = frag;
  };

  return mat;
}

/**
 * Photorealistic Japanese Touge Mountain Asphalt PBR material (100% from realistic-3d-nature-assets.zip):
 * Crushed aggregate base + spline-aware rubber drift/tire wear tracks,
 * macro weathering patches, dusty forest-edge shoulders & satin tire-polish roughness!
 */
export function createV3TougeAsphaltMaterial(tex: PBRTextureSet): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: tex.roughnessMap,
    roughness: 0.9,
    metalness: 0.03,
    envMapIntensity: 0.92,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });

  mat.customProgramCacheKey = () => 'v3-touge-asphalt-pbr-v1';
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute vec2 aRoadCoord;
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vRoadCoord = aRoadCoord;
        vAsphaltWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;

        float hashAsph(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noiseAsph(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashAsph(i);
          float b = hashAsph(i + vec2(1.0, 0.0));
          float c = hashAsph(i + vec2(0.0, 1.0));
          float d = hashAsph(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float u = vRoadCoord.x;
        float s = vRoadCoord.y;

        float macroW1 = noiseAsph(vAsphaltWorldPos.xz * 0.22);
        float macroW2 = noiseAsph(vAsphaltWorldPos.xz * 0.72 + vec2(4.7, 9.1));
        float macroWeather = macroW1 * 0.62 + macroW2 * 0.38;
        diffuseColor.rgb *= mix(0.86, 1.15, smoothstep(0.2, 0.82, macroWeather));

        float driftShift = sin(s * 0.14 + 0.6) * 0.065;
        float track1 = exp(-pow((u - (0.30 + driftShift)) / 0.068, 2.0));
        float track2 = exp(-pow((u - (0.48 + driftShift * 0.85)) / 0.072, 2.0));
        float track3 = exp(-pow((u - (0.64 + driftShift * 0.7)) / 0.064, 2.0));
        float track4 = exp(-pow((u - (0.79 + driftShift * 0.5)) / 0.058, 2.0));
        float trackStreakNoise = 0.58 + 0.42 * noiseAsph(vec2(u * 26.0, s * 0.22));
        float tireMask = clamp((track1 * 0.65 + track2 * 0.85 + track3 * 0.9 + track4 * 0.75) * trackStreakNoise, 0.0, 1.0);

        diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.68, 0.69, 0.71), tireMask * 0.56);

        float edgeNoise = noiseAsph(vAsphaltWorldPos.xz * 1.45);
        float outerDust = smoothstep(0.15, 0.0, u + (edgeNoise - 0.5) * 0.055);
        float innerDust = smoothstep(0.86, 1.0, u + (edgeNoise - 0.5) * 0.055);
        float shoulderMask = clamp(outerDust + innerDust, 0.0, 1.0);
        vec3 shoulderGrit = vec3(0.36, 0.33, 0.28);
        diffuseColor.rgb = mix(diffuseColor.rgb, shoulderGrit, shoulderMask * 0.55);

        float sunCrown = smoothstep(0.08, 0.45, u) * smoothstep(0.95, 0.55, u);
        diffuseColor.rgb *= (1.0 + sunCrown * 0.07);
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        `#include <roughnessmap_fragment>
        float rDriftShift = sin(vRoadCoord.y * 0.14 + 0.6) * 0.065;
        float rTrack = exp(-pow((vRoadCoord.x - (0.48 + rDriftShift * 0.85)) / 0.09, 2.0))
                     + exp(-pow((vRoadCoord.x - (0.64 + rDriftShift * 0.7)) / 0.09, 2.0));
        float rShoulder = smoothstep(0.14, 0.0, vRoadCoord.x) + smoothstep(0.87, 1.0, vRoadCoord.x);
        roughnessFactor = clamp(roughnessFactor - rTrack * 0.14 + rShoulder * 0.14, 0.48, 0.98);
        `
      );
  };

  return mat;
}

export function createV3SurfaceMaterials(tex: V3SurfaceTextureSet) {
  const forestFloor = createV3ForestFloorMaterial(tex.forestFloor);
  const forestFloorFar = createV3ForestFloorMaterial(tex.forestFloor, { farSkyline: true });
  const forestFloorShoulder = createV3ForestFloorMaterial(tex.forestFloor, { doubleSide: true });
  const tougeAsphalt = createV3TougeAsphaltMaterial(tex.asphalt);

  const weatheredCurb = new THREE.MeshStandardMaterial({
    map: tex.weatheredCurb.map,
    normalMap: tex.weatheredCurb.normalMap,
    normalScale: new THREE.Vector2(1.35, 1.35),
    roughnessMap: tex.weatheredCurb.roughnessMap,
    roughness: 0.89,
    metalness: 0.02,
    vertexColors: true,
    envMapIntensity: 0.72,
    side: THREE.DoubleSide,
  });

  const dryLeafScatter = new THREE.MeshStandardMaterial({
    map: tex.dryLeafCard.map,
    normalMap: tex.dryLeafCard.normalMap,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughnessMap: tex.dryLeafCard.roughnessMap,
    roughness: 0.86,
    metalness: 0.0,
    alphaTest: 0.44,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.75,
  });

  const pineNeedleThatch = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    roughness: 0.88,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.7,
  });

  const mossyRock = new THREE.MeshStandardMaterial({
    map: tex.mossyRock.map,
    normalMap: tex.mossyRock.normalMap,
    normalScale: new THREE.Vector2(1.5, 1.5),
    roughnessMap: tex.mossyRock.roughnessMap,
    roughness: 0.92,
    metalness: 0.02,
    envMapIntensity: 0.7,
  });

  return {
    forestFloor,
    forestFloorFar,
    forestFloorShoulder,
    tougeAsphalt,
    weatheredCurb,
    dryLeafScatter,
    pineNeedleThatch,
    mossyRock,
  };
}

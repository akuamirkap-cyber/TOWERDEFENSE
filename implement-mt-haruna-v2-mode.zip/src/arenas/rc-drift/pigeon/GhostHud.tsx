import { ArrowLeft, Pause, Play, RotateCcw } from 'lucide-react';
import type { GhostCue, GhostHudData } from './ghost-replay.js';
import { bonusPercent } from './DriveHud';

const coaching:Record<GhostCue,{label:string;detail:string;tone?:'warm'|'bonus'}>={
  brake:{label:'Rem sebelum tikungan',detail:'Kurangi laju sebelum roda mulai berbelok.',tone:'warm'},
  trailBrake:{label:'Rem sambil masuk',detail:'Kurangi tekanan pedal saat sudut drift terbentuk.',tone:'warm'},
  handbrake:{label:'Tekan drift (Spasi)',detail:'Buntut keluar tanpa mengerem, lalu atur gas.',tone:'warm'},
  turnIn:{label:'Bentuk sudut',detail:'Arahkan hidung mobil ke dalam tikungan.'},
  link:{label:'Pindah arah drift',detail:'Balik setir untuk menyambung ke tikungan berikutnya.'},
  counter:{label:'Countersteer',detail:'Roda depan mengarah berlawanan dengan putaran bodi.'},
  hold:{label:'Jaga gas',detail:'Pertahankan tenaga untuk menahan sudut drift.'},
  exit:{label:'Lepas gas dan luruskan',detail:'Biarkan ban kembali mencengkeram sebelum akselerasi.'},
  accelerate:{label:'Tambah gas',detail:'Buka gas saat mobil mulai lurus.'},
  line:{label:'Siapkan garis masuk',detail:'Lihat lintasan Ghost di depan mobil.'},
  bonus:{label:`Zona luar +${bonusPercent}%`,detail:'Jaga sudut dan momentum agar drift terus mendapat bonus.',tone:'bonus'},
  finish:{label:'Putaran selesai',detail:'Kembali ke bagian yang ingin kamu pelajari.'},
};

export function GhostIcon({size=17}:{size?:number}) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M5 12a7 7 0 0 1 14 0v6.2l-2.35-1.46-2.35 1.46L12 16.74 9.65 18.2 7.3 16.74 5 18.2Z"/>
    <path d="M9 11h.01m5.99 0h.01" strokeWidth="2.5"/>
  </svg>;
}

const stamp=(time:number)=>`${String(Math.floor(time/60)).padStart(2,'0')}:${String(Math.floor(time)%60).padStart(2,'0')}`;

function PedalMeter({label,value,kind}:{label:string;value:number;kind:'gas'|'brake'}) {
  const percent=Math.round(value*100);
  return <div className={`ghost-pedal ghost-pedal-${kind}`}>
    <div><span>{label}</span><output>{percent}%</output></div>
    <span role="meter" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} className="ghost-meter"><i style={{transform:`scaleX(${value})`}}/></span>
  </div>;
}

export function GhostCoach({data,onSeek,onRate,onPlay,onReplay,onExit}:{data:GhostHudData;onSeek:(time:number)=>void;onRate:()=>void;onPlay:()=>void;onReplay:()=>void;onExit:()=>void}) {
  const cue=coaching[data.cue], direction=data.steering>.6?'KIRI':data.steering<-.6?'KANAN':'LURUS';
  const offCenter=Math.max(-1,Math.min(1,data.steering/50));
  return <section className={`ghost-coach${cue.tone?` cue-${cue.tone}`:''}`} aria-label="Input pengemudi Ghost AI">
    <div className="ghost-coach-heading">
      <div><span className="ghost-coach-kicker"><i/> INPUT PILOT</span><h2>{cue.label}</h2><p>{cue.detail}</p></div>
      <div className="ghost-angle"><span>SUDUT DRIFT</span><output aria-label="Sudut drift Ghost">{data.telemetry.driftAngle}&deg;</output></div>
    </div>
    <div className="ghost-pedals">
      <PedalMeter label="Gas" value={data.gas} kind="gas"/>
      <PedalMeter label="Rem" value={data.brake} kind="brake"/>
      <div className="ghost-pedal ghost-steer">
        <div><span>Setir</span><output>{direction} {Math.round(Math.abs(data.steering))}&deg;</output></div>
        <span className="ghost-meter"><b/><i style={{left:`${50-offCenter*47}%`}}/></span>
      </div>
      <span className={`ghost-hand${data.handbrake?' hand-active':''}`} aria-label={`Tombol drift ${data.handbrake?'aktif':'tidak aktif'}`}>DRIFT<br/>SPASI</span>
    </div>
    <div className="ghost-playback">
      <button type="button" aria-label={data.playing?'Jeda demo':'Putar demo'} title={data.playing?'Jeda demo (Spasi)':'Putar demo (Spasi)'} onClick={onPlay}>{data.playing?<Pause size={16}/>:<Play size={16}/>}</button>
      <button type="button" aria-label="Ulang demo Ghost" title="Ulang demo (R)" onClick={onReplay}><RotateCcw size={16}/></button>
      <div className="ghost-timeline">
        <div className="ghost-scrub"><input type="range" min="0" max={Math.ceil(data.duration*20)/20} step="0.05" value={data.ended?Math.ceil(data.duration*20)/20:data.time} aria-label="Waktu putar ulang Ghost" onChange={event=>onSeek(Number(event.currentTarget.value))}/>
          <div className="ghost-markers">{data.clips.map(clip=><button type="button" key={clip.zone} style={{left:`${6+88*clip.time/data.duration}%`}} title={`Lihat masuk zona bonus ${clip.zone}`} aria-label={`Loncat ke zona bonus ${clip.zone}`} onClick={()=>onSeek(clip.time)}/>)}</div>
        </div>
        <span>{stamp(data.time)} <i>/</i> {stamp(data.duration)}</span>
      </div>
      <button type="button" className="ghost-rate" aria-label="Kecepatan demo" aria-pressed={data.rate===.5} title="Ganti kecepatan demo" onClick={onRate}>{data.rate===.5?'0,5x':'1x'}</button>
      <button type="button" className="ghost-back" title="Kembali ke mobil sendiri (G)" aria-label="Kembali ke mobil sendiri" onClick={onExit}><ArrowLeft size={16}/><span>Mobil saya</span></button>
    </div>
  </section>;
}
import type { DriverInput } from './drift-physics.js';
import type { RallyTrack, RoadRun } from './rally-road.js';
export function createRmxPilot(track: RallyTrack, tune?: { look?: number; grip?: number; settings?: import('../game/settings').Settings }): (run: RoadRun) => DriverInput;

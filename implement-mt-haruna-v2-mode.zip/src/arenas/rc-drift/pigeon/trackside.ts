import type * as Three from 'three';

/**
 * Trackside dressing for PRODRIFT's Rally Group B Lab:
 *  - stylized low-poly spectator crowd (Japanese drift fans) packed around the start/finish and feature corners —
 *    instanced bodies / heads / arms / flags, deterministic seed so it's identical every lap
 *  - street lamps along the barriers with emissive heads and road light-pools that come alive at night / rain
 * Everything is InstancedMesh — a handful of draw calls per course.
 */
export type TrackSampler = {
  length: number;
  loop: boolean;
  at(s: number): { x: number; y: number; z: number; tx: number; tz: number; curv: number };
};

export type Trackside = {
  group: Three.Group;
  setMood(mood: 'day' | 'rain' | 'night'): void;
  dispose(): void;
};

/** Deterministic PRNG so the crowd looks the same on every visit. */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function createTrackside(
  T: typeof Three,
  opts: { sampler: TrackSampler; barrier: number; lampHeight?: number; seed?: number; lightPools?: boolean },
): Trackside {
  const rand = mulberry32(opts.seed ?? 1337);
  const group = new T.Group();
  group.name = 'Trackside (spectators + lamps)';
  const at = (s: number) => opts.sampler.at(((s % opts.sampler.length) + opts.sampler.length) % opts.sampler.length);

  // ---------------------------------------------------------------- spectators
  type Spot = { x: number; y: number; z: number; yaw: number; scale: number; cheer: boolean; flag: boolean; jacket: number; skin: number };
  const spots: Spot[] = [];
  const jackets = [0xd53b2f, 0xf2f2f2, 0x274b8f, 0xe8a13a, 0x2f9e57, 0x222831, 0xffd23f, 0x18b1a8, 0xc63d8f, 0x8f1d1d, 0x3a6ea5, 0xece5d0];
  const skins = [0xe8b48c, 0xd9a06f, 0xc98a5a, 0xa96f45, 0x8a5632, 0xf0c8a0, 0x6f4526];
  // crowd packed around the start — two rows per side with jitter
  const crowdSpan = Math.min(200, opts.sampler.length * 0.06);
  for (let side = -1; side <= 1; side += 2) {
    for (let row = 0; row < 2; row++) {
      for (let s = 6; s < crowdSpan; s += 1.35 + rand() * 0.5) {
        if (rand() < 0.18) continue;
        const p = at(s), rx = p.tz, rz = -p.tx;
        const lat = side * (opts.barrier + 0.9 + row * 1.15 + rand() * 0.5);
        spots.push({
          x: p.x + rx * lat, y: p.y, z: p.z + rz * lat,
          yaw: Math.atan2(-rx * side, -rz * side) + (rand() - 0.5) * 0.6, // face the track
          scale: 0.88 + rand() * 0.26,
          cheer: rand() < 0.42,
          flag: rand() < 0.16,
          jacket: Math.floor(rand() * jackets.length),
          skin: Math.floor(rand() * skins.length),
        });
      }
    }
  }
  // a few pockets of fans at the biggest corners further along the lap
  let found = 0;
  for (let s = crowdSpan + 40; s < opts.sampler.length - 80 && found < 4; s += 6) {
    const p = at(s);
    if (Math.abs(p.curv) > 0.028) {
      found++;
      for (let k = -4; k <= 4; k++) {
        const q = at(s + k * 1.35), qx = q.tz, qz = -q.tx;
        const side = Math.sign(p.curv) || 1;
        const lat = side * (opts.barrier + 0.8 + (Math.abs(k) % 2) * 1.1 + rand() * 0.4);
        spots.push({
          x: q.x + qx * lat, y: q.y, z: q.z + qz * lat,
          yaw: Math.atan2(-qx * side, -qz * side) + (rand() - 0.5) * 0.7,
          scale: 0.88 + rand() * 0.28,
          cheer: rand() < 0.55,
          flag: rand() < 0.22,
          jacket: Math.floor(rand() * jackets.length),
          skin: Math.floor(rand() * skins.length),
        });
      }
    }
  }

  const dummy = new T.Object3D();
  const bodyGeo = new T.CylinderGeometry(0.15, 0.235, 0.74, 6); bodyGeo.translate(0, 0.4, 0);
  const headGeo = new T.SphereGeometry(0.115, 6, 5); headGeo.translate(0, 0.86, 0);
  const armGeo = new T.CylinderGeometry(0.032, 0.036, 0.4, 5); armGeo.translate(0, 0.2, 0);
  const stickGeo = new T.CylinderGeometry(0.016, 0.016, 0.72, 4); stickGeo.translate(0, 0.36, 0);
  const clothGeo = new T.PlaneGeometry(0.34, 0.22, 1, 1); clothGeo.translate(0.18, 0.62, 0);
  const bodyMat = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.82, flatShading: true });
  const skinMat = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.66, flatShading: true });
  const armMat = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.82, flatShading: true });
  const stickMat = new T.MeshStandardMaterial({ color: 0x8a6a3d, roughness: 0.8 });
  const clothMat = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7, side: T.DoubleSide, flatShading: true });

  const body = new T.InstancedMesh(bodyGeo, bodyMat, spots.length);
  const head = new T.InstancedMesh(headGeo, skinMat, spots.length);
  const armL = new T.InstancedMesh(armGeo, armMat, spots.length);
  const armR = new T.InstancedMesh(armGeo, armMat, spots.length);
  const flaggers = spots.filter(sp => sp.flag);
  const stick = new T.InstancedMesh(stickGeo, stickMat, flaggers.length);
  const cloth = new T.InstancedMesh(clothGeo, clothMat, flaggers.length);
  const color = new T.Color();
  let fi = 0;
  spots.forEach((sp, i) => {
    dummy.position.set(sp.x, sp.y, sp.z);
    dummy.rotation.set(0, sp.yaw, 0);
    dummy.scale.setScalar(sp.scale);
    dummy.updateMatrix();
    body.setMatrixAt(i, dummy.matrix);
    head.setMatrixAt(i, dummy.matrix);
    body.setColorAt(i, color.setHex(jackets[sp.jacket]));
    head.setColorAt(i, color.setHex(skins[sp.skin]));
    armMat && armL.setColorAt(i, color.setHex(jackets[sp.jacket]));
    armR.setColorAt(i, color.setHex(jackets[sp.jacket]));
    // arms: raised in a V when cheering, hanging at the sides otherwise
    const armAngle = sp.cheer ? 1.9 + (i % 7) * 0.055 : 0.28 + (i % 5) * 0.04;
    const side = (sign: 1 | -1) => {
      dummy.position.set(sp.x, sp.y + 0.62 * sp.scale, sp.z);
      dummy.rotation.set(0, sp.yaw, sign * armAngle);
      dummy.scale.setScalar(sp.scale);
      dummy.updateMatrix();
      return dummy.matrix.clone();
    };
    armL.setMatrixAt(i, side(1));
    armR.setMatrixAt(i, side(-1));
    if (sp.flag) {
      dummy.position.set(sp.x + Math.cos(sp.yaw) * 0.22, sp.y, sp.z + Math.sin(sp.yaw) * 0.22);
      dummy.rotation.set(0, sp.yaw, sp.cheer ? -0.5 : 0.12);
      dummy.scale.setScalar(sp.scale);
      dummy.updateMatrix();
      stick.setMatrixAt(fi, dummy.matrix);
      cloth.setMatrixAt(fi, dummy.matrix);
      cloth.setColorAt(fi, color.setHSL((i * 0.6180339887) % 1, 0.85, 0.58));
      fi++;
    }
  });
  for (const mesh of [body, head, armL, armR, stick, cloth]) {
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = false; mesh.receiveShadow = false; mesh.frustumCulled = false;
    group.add(mesh);
  }

  // ---------------------------------------------------------------- street lamps
  const lampEvery = Math.max(18, Math.round(opts.sampler.length / 110));
  const lampHeight = opts.lampHeight ?? 4.4;
  const lampCount = Math.floor(opts.sampler.length / lampEvery);
  const poleGeo = new T.CylinderGeometry(0.055, 0.08, lampHeight, 6); poleGeo.translate(0, lampHeight / 2, 0);
  const poleMat = new T.MeshStandardMaterial({ color: 0x2e3238, roughness: 0.6, metalness: 0.45 });
  const armLampGeo = new T.BoxGeometry(0.06, 0.05, 1.15); armLampGeo.translate(0, lampHeight - 0.05, 0.575);
  const headLampGeo = new T.BoxGeometry(0.34, 0.08, 0.16); headLampGeo.translate(0, lampHeight - 0.06, 1.12);
  const headMat = new T.MeshStandardMaterial({ color: 0x3a3f46, roughness: 0.5, emissive: 0xffc36b, emissiveIntensity: 0 });
  const pole = new T.InstancedMesh(poleGeo, poleMat, lampCount);
  const lampArm = new T.InstancedMesh(armLampGeo, poleMat, lampCount);
  const lampHead = new T.InstancedMesh(headLampGeo, headMat, lampCount);

  // additive light pool on the road under each lamp (opacity by mood)
  const poolCanvas = document.createElement('canvas'); poolCanvas.width = poolCanvas.height = 128;
  const pctx = poolCanvas.getContext('2d')!;
  const grad = pctx.createRadialGradient(64, 64, 2, 64, 64, 64);
  grad.addColorStop(0, 'rgba(255,205,130,0.9)');
  grad.addColorStop(0.45, 'rgba(255,190,110,0.38)');
  grad.addColorStop(1, 'rgba(255,180,100,0)');
  pctx.fillStyle = grad; pctx.fillRect(0, 0, 128, 128);
  const poolTex = new T.CanvasTexture(poolCanvas); poolTex.colorSpace = T.SRGBColorSpace;
  const poolGeo = new T.PlaneGeometry(9.5, 9.5); poolGeo.rotateX(-Math.PI / 2);
  const poolMat = new T.MeshBasicMaterial({ map: poolTex, transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false });
  const pool = new T.InstancedMesh(poolGeo, poolMat, lampCount);

  for (let i = 0; i < lampCount; i++) {
    const s = (i * lampEvery + 9) % opts.sampler.length;
    const p = at(s), rx = p.tz, rz = -p.tx;
    const side = i % 2 === 0 ? 1 : -1;
    const lat = side * (opts.barrier + 1.7);
    dummy.position.set(p.x + rx * lat, p.y, p.z + rz * lat);
    dummy.rotation.set(0, Math.atan2(-rx * side, -rz * side), 0); // face the road
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    pole.setMatrixAt(i, dummy.matrix);
    lampArm.setMatrixAt(i, dummy.matrix);
    lampHead.setMatrixAt(i, dummy.matrix);
    dummy.position.set(p.x + rx * (side * (opts.barrier - 0.6)), p.y + 0.03, p.z + rz * (side * (opts.barrier - 0.6)));
    dummy.rotation.set(0, 0, 0);
    dummy.updateMatrix();
    pool.setMatrixAt(i, dummy.matrix);
  }
  for (const mesh of [pole, lampArm, lampHead, pool]) { mesh.instanceMatrix.needsUpdate = true; mesh.frustumCulled = false; group.add(mesh); }

  // ---------------------------------------------------------------- mood switching
  function setMood(mood: 'day' | 'rain' | 'night') {
    const lampsOn = opts.lightPools !== false && mood !== 'day';
    headMat.emissiveIntensity = lampsOn ? (mood === 'night' ? 2.4 : 1.1) : 0;
    poolMat.opacity = !lampsOn ? 0 : mood === 'night' ? 0.85 : 0.35;
    pool.visible = lampsOn;
  }

  function dispose() {
    group.removeFromParent();
    group.traverse(object => {
      const mesh = object as Three.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry?.dispose();
      const material = mesh.material as Three.Material | Three.Material[] | undefined;
      if (Array.isArray(material)) for (const entry of material) entry.dispose();
      else material?.dispose();
    });
    poolTex.dispose();
  }

  setMood('day');
  return { group, setMood, dispose };
}

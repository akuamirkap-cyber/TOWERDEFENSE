const TAU = 2 * Math.PI;
const mass = 1220, inertia = 2450, gravity = 9.81, centreHeight = .52;
const wheelInertia = 2.55, halfTrack = 1.038, frontZ = 1.665, rearZ = -1.433, wheelbase = frontZ - rearZ;
export const wheelRadius = .479;
export const physicsStep = 1 / 120;
const gears = [0, 3.12, 2.24, 1.7, 1.28, .98];
const upshift = [0, 9.2, 16.8, 25.2, 34.5, Infinity];
const downshift = [0, 0, 6.1, 12.4, 19.6, 27.4];
const pavement = { grip: 1, roughness: 0, height: 0 };

const limit = (x, low, high) => Math.max(low, Math.min(high, x));
const mix = (x, y, t) => x + (y - x) * t;
const damp = (x, y, rate, dt) => mix(x, y, 1 - Math.exp(-rate * dt));
const fade = (x, lo, hi) => { const t = limit((x - lo) / (hi - lo), 0, 1); return t * t * (3 - 2 * t); };
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

export function createDriftCar(surfaceAt = () => pavement) {
  const wheels = Object.fromEntries(['FL', 'FR', 'RL', 'RR'].map(id => [id, {
    front: id[0] === 'F', side: id[1] === 'L' ? 1 : -1,
    x: 0, z: 0, angle: 0, omega: 0, spin: 0, along: 0, across: 0, slip: 0, load: 0, roughness: 0, height: 0,
  }]));
  const wheelList = Object.values(wheels);
  const state = {
    x: 0, z: 0, yaw: 0, vx: 0, vz: 0, yawRate: 0, speed: 0, forwardSpeed: 0, lateralSpeed: 0, beta: 0,
    steer: 0, steerAngle: 0, accelLong: 0, accelLat: 0, throttle: 0, brake: 0, rearLock: 0,
    rev: .16, gear: '1', shifting: false, handbrake: false, serviceBrake: false, rearSlip: 0, tireNoise: 0, roughness: 0, wheels,
    driftBlend: 0, driftPhase: 'grip', driftDirection: 0, coasting: false,
  };
  let driveGear = 1, direction = 1, reverseWait = 0, shiftWait = 0, torqueCut = 0;
  let steering = 0, entry = 0, flickAge = 0, lastTurn = 0, turnTime = 0;
  let slide = 0, oppositeTime = 0, sustain = 0, linkAge = 0, liftTime = 0, brakeEdge = false, handEdge = false;
  let brakeIntent = 0, exitLock = 0, coastBlend = 0, caught = false;
  let pedalReleased = false, liftSpeed = 0;

  function reset(x = 0, z = 0, yaw = 0) {
    Object.assign(state, { x, z, yaw, vx: 0, vz: 0, yawRate: 0, speed: 0, forwardSpeed: 0, lateralSpeed: 0, beta: 0,
      steer: 0, steerAngle: 0, accelLong: 0, accelLat: 0, throttle: 0, brake: 0, rearLock: 0,
      rev: .16, gear: '1', shifting: false, handbrake: false, serviceBrake: false, rearSlip: 0, tireNoise: 0, roughness: 0,
      driftBlend: 0, driftPhase: 'grip', driftDirection: 0, coasting: false });
    for (const wheel of wheelList) Object.assign(wheel, { angle: 0, omega: 0, spin: 0, along: 0, across: 0, slip: 0, load: 0, roughness: 0, height: 0 });
    driveGear = direction = 1;
    reverseWait = shiftWait = torqueCut = 0;
    steering = entry = flickAge = lastTurn = turnTime = slide = oppositeTime = sustain = linkAge = liftTime = 0;
    brakeIntent = exitLock = coastBlend = 0; caught = false;
    pedalReleased = false;liftSpeed = 0;
    brakeEdge = handEdge = false;
    refresh();
  }

  function refresh() {
    const s = Math.sin(state.yaw), c = Math.cos(state.yaw);
    state.speed = Math.hypot(state.vx, state.vz);
    state.forwardSpeed = state.vx * s + state.vz * c;
    state.lateralSpeed = state.vx * c - state.vz * s;
    state.beta = state.speed < .45 || state.forwardSpeed < .1 ? 0 : Math.atan2(state.lateralSpeed, state.forwardSpeed);
    for (const wheel of wheelList) {
      const x = wheel.side * halfTrack, z = wheel.front ? frontZ : rearZ;
      wheel.x = state.x + x * c + z * s;
      wheel.z = state.z - x * s + z * c;
    }
  }

  function step(dt, input) {
    const c = Math.cos(state.yaw), s = Math.sin(state.yaw);
    const forward = state.forwardSpeed, lateral = state.lateralSpeed, velocity = state.speed, beta = state.beta;
    const command = limit(input.steer, -1, 1), assist = input.assist !== false;
    const smooth = input.response === 'smooth', flow = smooth || input.response === 'responsive', easy = smooth && assist;
    const gas = limit(Number(input.gas), 0, 1), pedal = limit(Number(input.brake), 0, 1);
    const wantsReverse = pedal > .07 && gas < .07;
    const wantsForward = gas > .07 && pedal < .07;
    const wantsChange = direction > 0 ? wantsReverse : wantsForward;
    reverseWait = wantsChange && velocity < .72 && !input.handbrake ? reverseWait + dt : 0;
    if (reverseWait > (direction > 0 ? .30 : .12)) {
      direction *= -1; driveGear = 1; reverseWait = 0; torqueCut = .10; shiftWait = .42;
    }
    const accelerating = direction > 0 ? gas > .07 && pedal < .60 : wantsReverse;
    const braking = (gas > .07 && pedal > .07) || (direction > 0 ? wantsReverse : wantsForward);
    const freeRolling = smooth&&direction>0&&gas<.04&&pedal<.04&&!input.handbrake;
    if(freeRolling&&!pedalReleased)liftSpeed=velocity;
    pedalReleased=freeRolling;
    const powerPedal = direction > 0 ? gas * (1 - pedal) : pedal;
    const brakePedal = direction > 0 || pedal > .07 ? pedal : gas;
    const requested = powerPedal * Number(accelerating && !input.handbrake);
    const throttleGoal = smooth && direction > 0 ? requested * (.72 + .28 * requested) : requested;
    const gasRate = smooth ? (braking || input.handbrake ? 28 : throttleGoal > state.throttle ? 8.9 : 5.8)
      : accelerating ? (flow ? 17 : 9.8) : (flow ? 19 : 10.6);
    const brakeRate = braking ? (flow ? 23 : 15) : (flow ? 25 : 21);
    const lockRate = input.handbrake ? (smooth ? 34 : flow ? 39 : 29) : (smooth ? 22 : flow ? 16 : 8.5);
    state.throttle = damp(state.throttle, throttleGoal, gasRate, dt);
    if (smooth && state.throttle < .003) state.throttle=0;
    state.brake = damp(state.brake, braking ? brakePedal : 0, brakeRate, dt);
    state.rearLock = damp(state.rearLock, Number(input.handbrake), lockRate, dt);
    state.handbrake = input.handbrake;
    state.serviceBrake = braking;
    // After lift-off, the automatic unloads engine drag; rolling and air drag still apply.
    coastBlend = damp(coastBlend,Number(freeRolling),freeRolling?8.3:17,dt);
    state.coasting = freeRolling && state.throttle<.16 && state.brake<.035 && velocity>2;

    steering = damp(steering, command, easy ? command ? 19 : 22 : flow ? command ? 23 : 25 : command ? 16 : 18, dt);
    const turn = Math.abs(command) > .18 ? Math.sign(command) : 0;
    const speedGate = direction > 0 && forward > .8 ? easy ? fade(velocity,5.35,9.55) : fade(velocity,6.7,11) : 0;
    const grounded = 1 - fade(state.roughness, .24, .95);
    const angleWeight = fade(Math.abs(beta), .10, .64) * speedGate;
    entry = Math.max(0, entry - dt); flickAge = Math.max(0, flickAge-dt); linkAge = Math.max(0, linkAge-dt);
    turnTime = turn && turn === lastTurn ? turnTime + dt : 0;
    if(turn) {
      if(lastTurn!==turn && flickAge>0 && Math.abs(steering)>.29 && Math.sign(state.yawRate)===-turn && Math.abs(state.yawRate)>.18 && Math.abs(beta)<.21) {
        entry = Math.max(entry, .44 * speedGate * grounded);
      }
      lastTurn = turn; flickAge = .43;
    }
    const handKick = input.handbrake && !handEdge;
    const trailKick = pedal > .26 && !brakeEdge && gas > .28;
    handEdge = input.handbrake; brakeEdge = pedal > .26;
    if(flow) {
      // The brake and steering keys need not land in exactly the same physics tick.
      brakeIntent = handKick ? (easy?.32:.23) : Math.max(0, brakeIntent - dt);
      exitLock = Math.max(0, exitLock - dt);
      if(speedGate && turn && (brakeIntent > 0 || trailKick)) {
        entry = (brakeIntent > 0 ? (easy?.56:.46) : easy?.37:.32) * grounded;
        brakeIntent = exitLock = 0;
      }
    } else if(speedGate && turn && (handKick || trailKick)) entry = (handKick ? .57 : .43) * grounded;

    liftTime = gas < .12 ? liftTime + dt : 0;
    const powerEntry = flow
      ? gas > .89 && turnTime > .42 && velocity > 13 && -beta*turn > .18 && state.rearSlip > .42
      : gas > .68 && turnTime > .30 && Math.abs(command)>.68 && velocity > 11.4 && state.yawRate*turn>.27 && -beta*turn > .050;
    const naturalSlide = liftTime<.34&&Math.abs(beta)>(flow?.29:.21)&&state.rearSlip>(flow?.35:.24);
    if(!slide && exitLock===0 && speedGate>.20 && (entry>.095 || powerEntry || naturalSlide)) {
      slide = entry>.095&&turn ? -turn : Math.sign(beta) || -turn;
      sustain = oppositeTime = 0; caught = false;
    }
    if(slide && turn===slide && gas>(easy?.16:.30) && !input.handbrake) oppositeTime+=dt; else oppositeTime=Math.max(0,oppositeTime-dt*2.5);
    if(flow&&oppositeTime>.067)caught=true;
    if(slide && oppositeTime>(easy?.31:flow?.34:.40) && speedGate>.30 && beta*slide<(easy?.19:flow?.16:.18) && sustain>.36 && grounded>.35) {
      slide=-slide; linkAge=.58; entry=Math.max(entry,.38); oppositeTime=sustain=0;
      caught=false;
    }
    if(slide) sustain+=dt;
    const straighten=flow&&slide&&caught&&!turn&&sustain>.42&&Math.abs(beta)<(easy?.193:.177);
    if(!speedGate || straighten || (liftTime>(flow?.22:.38) && Math.abs(beta)<.105) || (gas<.12 && liftTime>(easy?1.13:flow?.80:1.18)) || (sustain>.84 && Math.abs(beta)<.083 && !turn && liftTime>.1)) {
      slide=0;oppositeTime=0;sustain=0;
      if(straighten) {exitLock=.35;entry=0;caught=false;}
    }

    const load = slide ? speedGate * grounded * (gas>.16 || input.handbrake ? 1 : easy?.69:.38) : 0;
    state.driftBlend = damp(state.driftBlend,load,load>state.driftBlend?6.6:4.8,dt);
    state.driftDirection = slide;
    state.driftPhase = !slide ? 'grip' : linkAge>0 ? 'link' : liftTime>.16 ? 'exit' : Math.abs(beta)>.19 ? 'slide' : 'entry';
    const normalLock = mix(.60, flow?.264:.229, fade(velocity, 3, 25));
    const sideLock = mix(normalLock, .70, angleWeight);
    const inside = limit(-steering*slide, 0, 1);
    const counter = limit(steering*slide, 0, 1);
    const exitPull = easy ? fade(liftTime,.07,.55) : fade(liftTime,.04,.31);
    const carried = state.driftBlend * (1-exitPull*.59);
    const frontFlow = Math.atan2(lateral + state.yawRate * frontZ, Math.max(3.8,forward));
    const unwind=flow&&caught&&!turn;
    if(unwind&&slide&&linkAge===0)state.driftPhase='exit';
    const frontBias = slide * (unwind ? .086 : easy ? mix(-.085-inside*.098+counter*.245,counter*.18,exitPull) : flow ? mix(-.09 - inside*.107 + counter*.211,counter*.18,exitPull)
      : mix(-.13 - inside*.095 + counter*.243, counter*.18, exitPull));
    const steerWeight = assist ? carried * fade(Math.abs(beta),easy?.062:.08,easy?.25:.30) * (input.handbrake ? .55 : flow ? mix(.86,.62,Math.abs(steering)) : .91) : 0;
    const manualSteer = flow&&slide ? steering*(steering*slide<0?Math.min(sideLock,.48):sideLock) : steering*sideLock;
    const targetSteer = mix(manualSteer, frontFlow + frontBias, steerWeight);
    state.steerAngle = damp(state.steerAngle, limit(targetSteer, -.73, .73), flow ? 21 : 14, dt);
    if (Math.abs(state.steerAngle) < .00035) state.steerAngle = 0;
    state.steer = state.steerAngle / .73;

    shiftWait = Math.max(0, shiftWait - dt);
    torqueCut = Math.max(0, torqueCut - dt);
    const previousGear = driveGear;
    if (direction > 0 && shiftWait === 0 && state.rearLock < .25) {
      const shiftSpeed = Math.max(0, forward) * .62 + velocity * .38;
      const holdGear = Math.max(angleWeight, state.driftBlend*.72);
      if ((!smooth||!freeRolling) && driveGear < 5 && shiftSpeed >= upshift[driveGear] * (1 + holdGear * (flow?.17:.25))) driveGear++;
      else if (driveGear > 1 && shiftSpeed < downshift[driveGear] * (flow&&gas>.58?1+.09*holdGear:1-holdGear*.20)) driveGear--;
    }
    if (previousGear !== driveGear) { shiftWait = flow?.38:.46; torqueCut = smooth?.09:flow?.106:.18; }
    state.gear = direction < 0 ? 'R' : String(driveGear);
    state.shifting = torqueCut > .004;
    const ratio = direction < 0 ? 2.62 : gears[driveGear];
    const nominalRev = direction < 0 ? 8.1 : upshift[Math.min(driveGear, 4)] * (driveGear === 5 ? 1.34 : 1);
    const rearSpeed = (Math.abs(wheels.RL.omega) + Math.abs(wheels.RR.omega)) * wheelRadius * .5;
    const engineSpeed = mix(Math.abs(forward), Math.min(rearSpeed, Math.abs(forward) + 14), .45);
    const revTarget = limit(.16 + engineSpeed / nominalRev * .65 + state.throttle * .13 - (state.shifting ? .18 : 0), .13, .995);
    state.rev = damp(state.rev, revTarget, state.shifting ? 14 : 7, dt);
    const power = (flow&&direction>0?smooth?728:676:555) * (.72 + .28 * Math.sin(limit(state.rev, 0, 1) * Math.PI));
    const launch = mix(flow?.74:.66, 1, fade(velocity, 1.2, 6.2));
    const reverseLimiter = direction > 0 ? 1 : 1 - fade(velocity, 6.5, 10.6);
    const redline = 1 - fade(engineSpeed, nominalRev * 1.13, nominalRev * 1.48) * .84;
    const onBoost = state.driftBlend * fade(Math.abs(beta),.12,.48) * (smooth?.23:flow?.20:.13);
    const liftCoupling=freeRolling?(1-.8*coastBlend)*(1-.91*fade(velocity-liftSpeed,0,.5)):1;
    const driveLoad = state.throttle*liftCoupling;
    const torque = direction * power * ratio * 4.38 * .90 * .5 * driveLoad * launch * reverseLimiter * redline * (1+onBoost)
      * (1 - state.rearLock) * (smooth ? (1-.23*fade(torqueCut,0,.09))*(input.handbrake?0:1-state.brake*.65) : state.shifting ? flow?.68:.39 : 1);

    const axleTransfer = limit(mass * state.accelLong * centreHeight / wheelbase, -2000, 2000);
    const steerTangent = Math.tan(state.steerAngle);
    const leftRearOmega=wheels.RL.omega,rightRearOmega=wheels.RR.omega;
    const rollingDrag=23 + velocity * .47 - (smooth?coastBlend*9:0);
    let forceX = -state.vx * rollingDrag, forceZ = -state.vz * rollingDrag, yawTorque = 0;
    let rearSlip = 0, tireNoise = 0, roughness = 0;
    for (const wheel of wheelList) {
      const x = wheel.side * halfTrack, z = wheel.front ? frontZ : rearZ;
      const tyre = surfaceAt(wheel.x, wheel.z);
      wheel.roughness = tyre.roughness; wheel.height = tyre.height;
      roughness += tyre.roughness * .25;
      const axleShare = wheel.front ? -rearZ / wheelbase : frontZ / wheelbase;
      const transfer = axleShare * mass * state.accelLat * centreHeight / (2 * halfTrack);
      const normal = Math.max(450, (mass * gravity * axleShare + (wheel.front ? -axleTransfer : axleTransfer)) * .5 - transfer * wheel.side);
      wheel.load = normal;
      wheel.angle = wheel.front ? Math.atan2(wheelbase * steerTangent, wheelbase - x * steerTangent) : 0;
      const sa = Math.sin(wheel.angle), ca = Math.cos(wheel.angle);
      const localForward = forward - state.yawRate * x, localSide = lateral + state.yawRate * z;
      const along = localForward * ca + localSide * sa, across = localSide * ca - localForward * sa;
      wheel.along = along; wheel.across = across;
      const referenceSpeed = Math.max(2.9, Math.abs(along), velocity * .52);
      const slipAngle = Math.atan2(across, referenceSpeed);
      const locked = !wheel.front && state.rearLock > .68;
      const otherRearOmega = wheel.side > 0 ? rightRearOmega : leftRearOmega;
      const differential = !wheel.front && !locked ? limit((otherRearOmega - wheel.omega) * (12 + state.throttle*13), -520, 520) : 0;
      const engineDrag = !wheel.front ? wheel.omega * ((smooth?mix(2.3,.74,coastBlend):2.3) * (1 - state.throttle)) : 0;
      const driveLimit = 1 - .55 * fade(Math.abs(wheel.omega * wheelRadius - along), 3.1 + velocity * .07, 11 + velocity * .16);
      const freeSpin = wheel.omega + (wheel.front ? 0 : torque * driveLimit + differential - engineDrag) * dt / wheelInertia;
      const brakeTorque = state.brake * normal * wheelRadius * (wheel.front ? 1.03 : .85) + (wheel.front ? 0 : state.rearLock * 2650);
      // A small ABS floor on the foot brake avoids four locked wheels; the handbrake intentionally bypasses it.
      const stoppedSpin = Math.sign(freeSpin) * Math.max(0, Math.abs(freeSpin) - dt * brakeTorque / wheelInertia);
      const predicted = locked ? 0 : Math.abs(along) > 2 && state.rearLock < .28 && braking
        ? Math.sign(along) * Math.max(Math.abs(stoppedSpin), .56 * Math.abs(along) / wheelRadius) : stoppedSpin;
      const ratioSlip = (predicted * wheelRadius - along) / referenceSpeed;
      const rearMix = wheel.front ? 0 : state.rearLock;
      const mu = tyre.grip * (wheel.front ? 1.16 : flow?1.143:1.047) * (1 - rearMix * .46);
      const peak = mu * normal;
      let fx = normal * 9.8 * ratioSlip / (1 + normal * 9.8 * wheelRadius ** 2 * dt / (wheelInertia * referenceSpeed));
      if (locked) fx = -peak * (smooth?.48:flow?.60:.88) * Math.tanh(along / 1.5);
      const excess = fade(Math.abs(slipAngle), .16, .80);
      const entryLoss = wheel.front ? 0 : fade(entry,0,.44)*(easy?.34:assist?.26:.19);
      const powerLoss = wheel.front ? 0 : state.throttle * fade(Math.abs(slipAngle), .095, .44) * (.185+carried*.08);
      let fy = -peak * Math.tanh(slipAngle * (wheel.front ? 6.5 : 7.0)) * (1 - excess * (wheel.front ? .14 : .27) - powerLoss);
      fy*=1-entryLoss;
      // Both force components draw from the same patch of rubber, not two independent grip budgets.
      const ellipse = Math.max(1, Math.hypot(fx / peak, fy / (peak * (1 - rearMix * .27))));
      fx /= ellipse; fy /= ellipse;
      const drag = tyre.roughness * normal * .077 * Math.tanh(along / 2);
      const localX = (fx - drag) * sa + fy * ca, localZ = (fx - drag) * ca - fy * sa;
      forceX += localX * c + localZ * s; forceZ += localZ * c - localX * s;
      yawTorque += z * localX - x * localZ;
      wheel.omega = locked ? 0 : limit(predicted - fx * wheelRadius * dt / wheelInertia, -138, 138);
      wheel.spin = (wheel.spin + wheel.omega * dt) % TAU;
      const scrub = Math.abs(across) + .82 * Math.abs(wheel.omega * wheelRadius - along);
      wheel.slip = fade(scrub, .95, 6.9) * (locked ? 1 : fade(velocity + Math.abs(wheel.omega) * .08, 2.2, 8.3));
      if (!wheel.front) rearSlip = Math.max(rearSlip, wheel.slip);
      tireNoise = Math.max(tireNoise, wheel.slip);
    }

    const accelX = forceX / mass, accelZ = forceZ / mass;
    state.accelLong = damp(state.accelLong, accelX * s + accelZ * c, 12, dt);
    state.accelLat = damp(state.accelLat, accelX * c - accelZ * s, 12, dt);
    state.vx += accelX * dt; state.vz += accelZ * dt;
    const longitudinal = accelX * s + accelZ * c, side = accelX*c-accelZ*s;
    const pathYawRate = (side*forward-longitudinal*lateral)/Math.max(35,velocity*velocity);
    const carriedGas = easy ? Math.max(gas,state.throttle*.95) : gas;
    const wantedSlide = slide * mix(unwind ? .047 : easy ? .282+Math.sqrt(carriedGas)*.152+inside*.148-counter*.342
      : flow ? .27+Math.sqrt(gas)*.144+inside*.173-counter*.328 : .31+Math.sqrt(gas)*.127+inside*.155-counter*.325,.01,exitPull);
    const desiredYawRate = limit(pathYawRate + (beta-wantedSlide)*(flow?3.63:3.25),-1.65,1.65);
    // Assist acts as bounded yaw torque. It can't turn the velocity vector or point the car down the course.
    const attitude = assist&&slide ? state.driftBlend * fade(Math.abs(beta)+entry*.23,.045,.25) * (input.handbrake?.68:1) : 0;
    const yawHelp = limit((desiredYawRate-state.yawRate)*6.4,-5.9,5.9)*attitude;
    const yawDamping = .41 + (assist ? attitude*.46 : .09*angleWeight) + (easy?.46*fade(Math.abs(beta),.64,1.06):0);
    state.yawRate = limit((state.yawRate + (yawTorque/inertia*(1-attitude*.50)+yawHelp)*dt)*Math.exp(-yawDamping*dt),-3.35,3.35);
    if (!accelerating && (Math.hypot(state.vx, state.vz) < .065 || (braking && velocity < .17))) {
      state.vx = state.vz = state.yawRate = 0;
      for (const wheel of wheelList) wheel.omega = 0;
    }
    state.x += state.vx * dt; state.z += state.vz * dt;
    state.yaw = wrap(state.yaw + state.yawRate * dt);
    state.rearSlip = rearSlip; state.tireNoise = tireNoise; state.roughness = roughness;
    refresh();
  }

  reset();
  return { state, step, reset, refresh };
}
export const COURSES = {
  pigeon: { name: 'Pigeon Touge', type: 'Loop pegunungan', detail: 'Jalan hutan dengan tanjakan dan lereng terbuka.', number: '01' },
  haruna: { name: 'Mt. Haruna', type: 'Turunan pegunungan', detail: 'Kontur, start, dan kendali asli ProDrift dengan hutan PIGEON.', number: '02' },
  'haruna-v2': { name: 'Mt. Haruna V2', type: 'Turunan pegunungan V2', detail: 'Kontur, gunung, pagar & papan jalan Haruna dengan cahaya, shadow, pohon, tanah, rumput & aspal 100% desain V2.', number: '03' },
  'haruna-v3': { name: 'Mt. Haruna V3', type: 'Turunan pegunungan V3', detail: 'Basis Mt. Haruna V2 dengan tekstur tanah daun mati, 3D daun gugur, kerb & bentuk/tekstur aspal realistic-3d-nature.', number: '04' },
  pinus: { name: 'Sirkuit Pinus', type: 'Sirkuit klasik', detail: 'Lintasan ProDrift asli dengan mode Ghost AI.', number: '05' },
} as const;

export type CourseId = keyof typeof COURSES;
export const COURSE_IDS: readonly CourseId[] = ['pigeon', 'haruna', 'haruna-v2', 'haruna-v3', 'pinus'];
export const DEFAULT_COURSE: CourseId = 'pigeon';
const key = 'prodrift.selected-course';
let current: CourseId = DEFAULT_COURSE;

export function readSelectedCourse(): CourseId {
  try {
    const saved = localStorage.getItem(key);
    return COURSE_IDS.find(id => id === saved) ?? current;
  } catch { return current; }
}

export function saveSelectedCourse(id: CourseId) {
  current = id;
  try { localStorage.setItem(key, id); } catch { /* Storage is optional. */ }
}

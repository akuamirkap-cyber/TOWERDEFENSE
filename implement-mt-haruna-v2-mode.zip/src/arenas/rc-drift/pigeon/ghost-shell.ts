import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { DriftState, WheelId } from './drift-physics.js';
import type { RallyModel } from './rally-model.js';

const ids=['FL','FR','RL','RR'] as const;

export function createGhostShell(model:RallyModel) {
  model.updateMatrixWorld(true);
  const body=model.getObjectByName('bodyPivot')!, root=new T.Group();
  root.name='Ghost exterior (batched)';
  const low=new T.Color('#1d4d58'), high=new T.Color('#b5fbeb'), shade=new T.Color();
  const normal=new T.Vector3(), light=new T.Vector3(-.41,.76,-.47).normalize();
  const inverse=new T.Matrix4(), matrix=new T.Matrix4();
  const ink=new T.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.67,toneMapped:false});

  function bake(origin:T.Object3D, pieces:T.Object3D[]) {
    inverse.copy(origin.matrixWorld).invert();
    const buffers:T.BufferGeometry[]=[];
    const visit=(object:T.Object3D)=>{
      const mesh=object as T.Mesh<T.BufferGeometry,T.MeshStandardMaterial>;
      if(!object.visible||object.name==='cockpit'||object.name.startsWith('s1MudflapPivot')||object.name==='rollingSpokeSweep')return;
      if(mesh.isMesh&&!Array.isArray(mesh.material)&&mesh.material.isMeshStandardMaterial&&mesh.geometry.attributes.normal) {
        const material=mesh.material, part=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();
        part.applyMatrix4(matrix.multiplyMatrices(inverse,mesh.matrixWorld));
        const position=part.attributes.position, normals=part.attributes.normal, color=new Float32Array(position.count*3);
        const base=material.color, luma=.21*base.r+.72*base.g+.07*base.b;
        for(let i=0;i<position.count;i++) {
          normal.fromBufferAttribute(normals,i);
          const sun=Math.max(-.25,normal.dot(light));
          shade.copy(low).lerp(high,Math.min(1,.10+Math.sqrt(luma)*.74+sun*.22));
          shade.toArray(color,i*3);
        }
        for(const name of Object.keys(part.attributes))if(name!=='position')part.deleteAttribute(name);
        part.setAttribute('color',new T.BufferAttribute(color,3));buffers.push(part);
      }
      for(const child of object.children)visit(child);
    };
    for(const piece of pieces)visit(piece);
    const mesh=new T.Mesh(mergeGeometries(buffers)??new T.BufferGeometry(),ink);
    mesh.renderOrder=3;
    for(const buffer of buffers)buffer.dispose();
    return mesh;
  }

  // Collapse the shell and each rotating axle to one draw call, without bringing along interior or lamp shaders.
  const chassis=bake(body,body.children.filter(node=>node.name!=='livery'));
  root.add(chassis);
  const axles=new Map<WheelId,{pivot:T.Group;wheel:T.Mesh}>();
  for(const id of ids) {
    const original=model.getObjectByName(`wheel${id}`)!, axle=original.getObjectByName('axle')!;
    const pivot=new T.Group(), wheel=bake(axle,[axle]);
    pivot.position.copy(original.position);pivot.add(wheel);root.add(pivot);
    axles.set(id,{pivot,wheel});
  }

  return {root,setTranslucent(yes:boolean) {
    if(ink.transparent===yes)return;
    ink.transparent=yes;ink.opacity=yes?.67:1;ink.needsUpdate=true;
  },paint(state:DriftState) {
    root.position.set(state.x,0,state.z);root.rotation.y=state.yaw;
    chassis.rotation.set(T.MathUtils.clamp(-state.accelLong*.0074,-.072,.090),0,T.MathUtils.clamp(state.accelLat*.0104,-.117,.117));
    for(const id of ids) {
      const {pivot,wheel}=axles.get(id)!, tyre=state.wheels[id];
      pivot.rotation.y=tyre.angle;pivot.position.y=.481+tyre.height;wheel.rotation.x=tyre.spin;
    }
  }};
}
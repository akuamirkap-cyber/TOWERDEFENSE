import { useEffect, useState } from 'react'
import { useGame } from '../state'

const DIRS: [number, string][] = [
  [0, 'N'], [45, 'NE'], [90, 'E'], [135, 'SE'], [180, 'S'], [225, 'SW'], [270, 'W'], [315, 'NW'],
]

function Compass({ heading }: { heading: number }) {
  // heading: 0 = north, clockwise
  const ticks: { x: number; label?: string; major: boolean }[] = []
  for (let d = -90; d <= 90; d += 5) {
    const deg = (((heading + d) % 360) + 360) % 360
    const label = DIRS.find(([a]) => a === Math.round(deg / 5) * 5 % 360)?.[1]
    ticks.push({ x: d, label: deg % 45 === 0 ? label : undefined, major: deg % 15 === 0 })
  }
  return (
    <div className="absolute top-5 left-1/2 h-10 w-[440px] -translate-x-1/2 overflow-hidden" style={{ maskImage: 'linear-gradient(90deg, transparent, black 18%, black 82%, transparent)' }}>
      <div className="absolute inset-x-0 top-3 h-px bg-white/25" />
      {ticks.map((t, i) => (
        <div key={i} className="absolute top-0 flex flex-col items-center" style={{ left: `${50 + (t.x / 180) * 100}%`, transform: 'translateX(-50%)' }}>
          <div className={`w-px ${t.label ? 'h-3 bg-white' : t.major ? 'h-2 bg-white/60' : 'h-1 bg-white/30'}`} />
          {t.label && <div className={`mt-0.5 text-[11px] font-bold ${t.label === 'N' ? 'text-amber-300' : 'text-white/90'}`}>{t.label}</div>}
        </div>
      ))}
      <div className="absolute top-0 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[5px] border-t-[6px] border-x-transparent border-t-amber-300" />
      <div className="absolute right-0 bottom-0 left-0 text-center text-[10px] text-white/70">{heading.toString().padStart(3, '0')}</div>
    </div>
  )
}

function Minimap({ px, pz, heading, bx, bz }: { px: number; pz: number; heading: number; bx: number; bz: number }) {
  // world bounds of the compound x -60..36, z -28..40
  const S = 150
  const sx = (x: number) => ((x + 60) / 96) * S
  const sz = (z: number) => ((z + 28) / 68) * S * (68 / 96)
  const H = S * (68 / 96)
  return (
    <div className="absolute top-6 left-6 border border-white/20 bg-black/45 p-1.5 shadow-[0_0_20px_rgba(0,0,0,0.6)] backdrop-blur-[2px]">
      <svg width={S} height={H} className="block">
        <rect x={0} y={0} width={S} height={H} fill="rgba(60,64,58,0.55)" />
        <rect x={sx(-60)} y={sz(12.3)} width={sx(36) - sx(-60)} height={sz(40) - sz(12.3)} fill="rgba(40,40,40,0.6)" />
        <rect x={sx(-20)} y={sz(-12)} width={sx(20) - sx(-20)} height={sz(12) - sz(-12)} fill="rgba(170,165,150,0.85)" stroke="rgba(255,255,255,0.5)" strokeWidth={0.8} />
        <rect x={sx(-42)} y={sz(-11)} width={sx(-20.2) - sx(-42)} height={sz(3) - sz(-11)} fill="rgba(150,135,115,0.85)" stroke="rgba(255,255,255,0.5)" strokeWidth={0.8} />
        <rect x={0.5} y={0.5} width={S - 1} height={H - 1} fill="none" stroke="rgba(255,255,255,0.35)" strokeDasharray="3 2" />
        <circle cx={sx(bx)} cy={sz(bz)} r={2.6} fill="#6fe3e8" stroke="#05201f" strokeWidth={0.8} />
        <g transform={`translate(${sx(px)} ${sz(pz)}) rotate(${heading})`}>
          <path d="M0,-7 L5,5 L0,2.5 L-5,5 Z" fill="#fcd34d" stroke="black" strokeWidth={0.6} />
          <path d="M0,0 L-14,-26 A30,30 0 0 1 14,-26 Z" fill="rgba(252,211,77,0.14)" />
        </g>
      </svg>
      <div className="mt-1 flex justify-between text-[9px] tracking-[0.2em] text-white/60">
        <span>SITE 14</span>
        <span>
          {px.toFixed(0)}, {(-pz).toFixed(0)}
        </span>
      </div>
    </div>
  )
}

export function HUD() {
  const locked = useGame((s) => s.locked)
  const flashlight = useGame((s) => s.flashlight)
  const crouch = useGame((s) => s.crouch)
  const floor = useGame((s) => s.floor)
  const px = useGame((s) => s.px)
  const pz = useGame((s) => s.pz)
  const heading = useGame((s) => s.heading)
  const ammo = useGame((s) => s.ammo)
  const reserve = useGame((s) => s.reserve)
  const reloading = useGame((s) => s.reloading)
  const ads = useGame((s) => s.ads)
  const hits = useGame((s) => s.hits)
  const botMode = useGame((s) => s.botMode)
  const botX = useGame((s) => s.botX)
  const botZ = useGame((s) => s.botZ)
  const barkText = useGame((s) => s.barkText)
  const barkId = useGame((s) => s.barkId)
  const [bark, setBark] = useState('')

  useEffect(() => {
    if (!barkId || !barkText) return
    setBark(barkText)
    const t = setTimeout(() => setBark(''), 6500)
    return () => clearTimeout(t)
  }, [barkId, barkText])
  const [showHelp, setShowHelp] = useState(true)

  useEffect(() => {
    if (!locked) return
    setShowHelp(true)
    const t = setTimeout(() => setShowHelp(false), 10000)
    return () => clearTimeout(t)
  }, [locked])

  const low = ammo <= 8
  return (
    <div className="pointer-events-none absolute inset-0 font-mono text-[11px] tracking-[0.15em] text-white/90 uppercase select-none">
      {/* crosshair: CSS var --gap driven per frame by the weapon */}
      <div id="xhair" className="absolute top-1/2 left-1/2" style={{ ['--gap' as string]: '10px' }}>
        <div className="absolute h-[2px] w-[9px] -translate-y-1/2 bg-white shadow-[0_0_2px_black]" style={{ left: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[2px] w-[9px] -translate-y-1/2 bg-white shadow-[0_0_2px_black]" style={{ right: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[9px] w-[2px] -translate-x-1/2 bg-white shadow-[0_0_2px_black]" style={{ top: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[9px] w-[2px] -translate-x-1/2 bg-white shadow-[0_0_2px_black]" style={{ bottom: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[2px] w-[2px] -translate-x-1/2 -translate-y-1/2 bg-white/80" />
      </div>

      {/* hit marker (opacity driven by the weapon) */}
      <div id="hitmark" className="absolute top-1/2 left-1/2 h-0 w-0" style={{ opacity: 0 }}>
        {[45, 135, 225, 315].map((a) => (
          <div key={a} className="absolute h-[2px] w-[10px] bg-white shadow-[0_0_3px_black]" style={{ transform: `rotate(${a}deg) translateX(9px)`, transformOrigin: '0 50%' }} />
        ))}
      </div>
      <div className="absolute top-20 right-8 text-right text-[10px] tracking-[0.3em] text-white/70 drop-shadow-[0_0_4px_black]">
        TARGETS DOWN <span className="text-[16px] font-black text-amber-300">{hits}</span>
      </div>
      <div className="absolute top-[7.2rem] right-8 flex items-center gap-2 border-r-2 border-cyan-300/80 bg-black/30 py-1 pr-2 pl-3 text-[10px] tracking-[0.25em] text-white/80 drop-shadow-[0_0_4px_black]">
        <span className="inline-block h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_8px_rgba(103,227,232,0.9)]" />
        GHOST-2 <span className={botMode === 'follow' ? 'font-bold text-cyan-300' : 'font-bold text-amber-300'}>{botMode === 'follow' ? 'FOLLOW' : 'HOLD'}</span>
        <span className="text-white/40">[G]</span>
      </div>

      <Compass heading={heading} />
      <Minimap px={px} pz={pz} heading={heading} bx={botX} bz={botZ} />

      {/* bottom-left: operator status */}
      <div className="absolute bottom-8 left-8 flex flex-col gap-1.5 drop-shadow-[0_0_4px_rgba(0,0,0,0.9)]">
        <div className="flex items-center gap-3">
          <div className="text-[13px] font-bold text-white">OPERATOR · R. MENDEZ</div>
          <div className="text-white/50">LVL {floor}</div>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-[6px] w-56 skew-x-[-20deg] bg-white/15">
            <div className="h-full w-full bg-gradient-to-r from-white/80 to-white" />
          </div>
          <span className="text-[12px] font-bold">100</span>
        </div>
        <div className="flex gap-3 text-[10px] text-white/55">
          <span>{crouch ? '▼ CROUCH' : '▲ STAND'}</span>
          {flashlight && <span className="text-amber-200">◉ LIGHT</span>}
          {ads && <span className="text-amber-200">⊕ ADS</span>}
        </div>
      </div>

      {/* bottom-right: weapon & ammo */}
      <div className="absolute right-8 bottom-8 flex flex-col items-end drop-shadow-[0_0_6px_rgba(0,0,0,0.9)]">
        <div className="text-[10px] tracking-[0.3em] text-white/60">M4A1 · RED DOT · AUTO</div>
        <div className="mt-1 flex items-end gap-2">
          <span className={`text-[44px] leading-none font-black tracking-tight ${low ? 'text-red-400' : 'text-white'}`}>{ammo.toString().padStart(2, '0')}</span>
          <span className="mb-1 text-[18px] font-bold text-white/55">/ {reserve}</span>
        </div>
        <div className="mt-1 flex gap-[2px]">
          {Array.from({ length: 30 }).map((_, i) => (
            <span key={i} className={`h-3 w-[3px] ${i < ammo ? (low ? 'bg-red-400' : 'bg-white/90') : 'bg-white/15'}`} />
          ))}
        </div>
      </div>

      {/* companion bark */}
      {bark && locked && (
        <div key={barkId} className="absolute bottom-[6.4rem] left-1/2 flex max-w-lg -translate-x-1/2 items-start gap-2 border border-cyan-300/30 bg-black/60 px-3 py-2 backdrop-blur-[2px]">
          <div className="mt-[2px] flex h-6 w-6 shrink-0 items-center justify-center border border-cyan-300/60 text-[9px] font-black text-cyan-200">G2</div>
          <div className="text-left">
            <div className="text-[9px] tracking-[0.3em] text-cyan-300/90">GHOST-2 · RADIO</div>
            <div className="text-[11px] normal-case tracking-normal text-white/90">{bark}</div>
          </div>
        </div>
      )}

      {/* reload / low ammo prompts */}
      {locked && (reloading || ammo === 0 || low) && (
        <div className="absolute top-[58%] left-1/2 -translate-x-1/2 text-center drop-shadow-[0_0_4px_rgba(0,0,0,1)]">
          {reloading ? (
            <span className="text-[13px] font-bold text-white/90">RELOADING…</span>
          ) : ammo === 0 && reserve === 0 ? (
            <span className="text-[13px] font-bold text-red-400">NO AMMO</span>
          ) : (
            <span className="text-[12px] font-bold text-amber-300">
              [R] RELOAD
            </span>
          )}
        </div>
      )}

      {/* controls hint */}
      {locked && (
        <div
          className={`absolute bottom-28 left-1/2 -translate-x-1/2 border border-white/15 bg-black/45 px-4 py-2 text-center text-[10px] text-white/75 transition-opacity duration-1000 ${
            showHelp ? 'opacity-100' : 'opacity-0'
          }`}
        >
          WASD gerak · SHIFT sprint · SPASI loncat · C jongkok · KLIK KIRI tembak · KLIK KANAN aim · R reload · F senter · ESC pause
        </div>
      )}
    </div>
  )
}

import { useGame } from '../state'

const KEYS: [string, string][] = [
  ['WASD', 'Bergerak'],
  ['MOUSE', 'Melihat / membidik'],
  ['KLIK KIRI', 'Tembak (full-auto)'],
  ['KLIK KANAN', 'Aim down sights'],
  ['R', 'Reload'],
  ['SHIFT', 'Sprint'],
  ['SPASI', 'Loncat'],
  ['C / CTRL', 'Jongkok'],
  ['F', 'Senter taktis'],
  ['G', 'Bot: ikuti / berhenti'],
  ['ESC', 'Pause'],
]

export function StartScreen({ progress, ready }: { progress: number; ready: boolean }) {
  const locked = useGame((s) => s.locked)
  const everStarted = useGame((s) => s.everStarted)
  if (locked) return null
  const pct = Math.round(progress * 100)
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center overflow-y-auto bg-gradient-to-r from-black/90 via-black/60 to-black/10 font-mono text-white">
      <div className="mx-6 w-full max-w-xl py-6 sm:ml-[6vw]">
        <div className="flex items-center gap-3 text-[10px] tracking-[0.45em] text-amber-300/90 uppercase">
          <span className="h-px w-10 bg-amber-300/80" />
          {everStarted ? 'Operasi dijeda' : 'Briefing operasi'}
        </div>
        <h1 className="mt-3 text-4xl leading-[0.95] font-black tracking-tight uppercase sm:text-5xl">
          Operation
          <br />
          <span className="text-amber-300">Dead Zone</span>
        </h1>
        <p className="mt-4 hidden max-w-md text-[12px] leading-relaxed text-white/65 [@media(min-height:560px)]:block">
          Kompleks industri terbengkalai <span className="text-white">Site 14</span>: hall pabrik 40×24 m dengan mezzanine &amp; catwalk,
          rumah manajer dua lantai + teras atap, menara jaga, kontainer dan tembok perimeter. Kamu didampingi <span className="text-cyan-300">GHOST-2</span>,
          bot pendukung yang mengikuti dan memberi info rute. Sisir area dan kuasai titik tinggi.
        </p>

        {!ready ? (
          <div className="mt-8 max-w-md">
            <div className="flex justify-between text-[10px] tracking-[0.3em] text-white/55 uppercase">
              <span>Memuat map &amp; material</span>
              <span>{pct}%</span>
            </div>
            <div className="mt-2 h-[3px] w-full bg-white/10">
              <div className="h-full bg-amber-300 transition-all duration-200" style={{ width: `${pct}%` }} />
            </div>
          </div>
        ) : (
          <div className="mt-8">
            <div className="inline-flex animate-pulse items-center gap-3 border border-amber-300/60 bg-amber-300/10 px-5 py-3 text-sm font-bold tracking-[0.3em] text-amber-200 uppercase">
              ▶ {everStarted ? 'Klik untuk lanjut' : 'Klik layar untuk deploy'}
            </div>
            <div className="mt-6 grid max-w-md grid-cols-2 gap-x-6 gap-y-1.5 text-[11px] text-white/60">
              {KEYS.map(([k, v]) => (
                <div key={k} className="flex items-center gap-2">
                  <span className="min-w-[78px] border border-white/20 bg-white/5 px-1.5 py-0.5 text-center text-[10px] font-bold text-white">{k}</span>
                  <span>{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 text-[10px] tracking-[0.25em] text-white/35 uppercase">
              Tip: tangga besi di sisi barat rumah menuju teras atap (LVL 3) · tekan G untuk mengatur GHOST-2
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

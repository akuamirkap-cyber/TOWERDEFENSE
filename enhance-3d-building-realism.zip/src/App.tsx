import * as THREE from 'three'
import { useEffect, useRef, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { loadWorldTextures, type WorldTextures } from './world/textures'
import { MaterialsProvider } from './world/materials'
import { Warehouse } from './world/Warehouse'
import { House } from './world/House'
import { HouseProps } from './world/HouseProps'
import { Openings } from './world/Openings'
import { Props } from './world/Props'
import { Debris } from './world/Debris'
import { Decals } from './world/Decals'
import { Lighting } from './world/Lighting'
import { Exterior } from './world/Exterior'
import { Architecture } from './world/Architecture'
import { Targets } from './world/Targets'
import { Rooftop } from './world/Rooftop'
import { Atmosphere } from './world/Atmosphere'
import { Bot } from './world/Bot'
import { Player } from './player/Player'
import { Weapon } from './player/Weapon'
import { PostFX } from './fx/PostFX'
import { HUD } from './ui/HUD'
import { StartScreen } from './ui/StartScreen'

export default function App() {
  const [textures, setTextures] = useState<WorldTextures | null>(null)
  const [progress, setProgress] = useState(0)
  const started = useRef(false)

  useEffect(() => {
    if (started.current) return
    started.current = true
    loadWorldTextures(setProgress).then(setTextures)
  }, [])

  return (
    <div className="fixed inset-0 overflow-hidden bg-black select-none">
      {textures && (
        <Canvas
          shadows="soft"
          dpr={[1, 1.25]}
          gl={{
            antialias: false,
            powerPreference: 'high-performance',
            toneMapping: THREE.NoToneMapping,
            toneMappingExposure: 1.0,
            stencil: false,
            depth: true,
          }}
          camera={{ fov: 78, near: 0.05, far: 700, position: [-22, 1.6, 28] }}
          onCreated={({ gl }) => {
            gl.setClearColor('#000000')
          }}
        >
          <fog attach="fog" args={['#b9c3cb', 40, 340]} />
          <MaterialsProvider textures={textures}>
            <Warehouse />
            <House />
            <Architecture />
            <Openings />
            <Props />
            <HouseProps />
            <Debris />
            <Decals />
            <Lighting />
            <Exterior />
            <Targets />
            <Rooftop />
            <Atmosphere />
            <Bot />
            <Player />
            <Weapon />
          </MaterialsProvider>
          <PostFX dirt={textures.lensDirt} />
        </Canvas>
      )}
      <HUD />
      <StartScreen progress={progress} ready={!!textures} />
    </div>
  )
}

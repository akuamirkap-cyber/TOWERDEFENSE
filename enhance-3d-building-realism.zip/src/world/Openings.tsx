import * as THREE from 'three'
import { useMemo } from 'react'
import { WALLS, type Opening } from './layout'
import { useMaterials } from './materials'

type V3 = [number, number, number]

function hash(n: number) {
  const x = Math.sin(n * 12.9898) * 43758.5453
  return x - Math.floor(x)
}

// ---------------------------------------------------------------------------
// industrial
function SteelWindow({ w, h, seed }: { w: number; h: number; seed: number }) {
  const m = useMaterials()
  const fw = 0.07
  const cols = w > 2 ? 3 : 2
  const rows = 2
  const pw = w / cols
  const ph = h / rows
  const shard = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(0, 0)
    s.lineTo(pw * 0.5, 0)
    s.lineTo(pw * 0.32, ph * 0.3)
    s.lineTo(pw * 0.1, ph * 0.42)
    s.lineTo(0, ph * 0.25)
    s.closePath()
    return new THREE.ShapeGeometry(s)
  }, [pw, ph])
  const panes: React.ReactNode[] = []
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cx = -w / 2 + (c + 0.5) * pw
      const cy = (r + 0.5) * ph
      const k = hash(seed * 13 + r * 7 + c * 3)
      if (k < 0.5) {
        panes.push(
          <mesh key={`g${r}${c}`} position={[cx, cy, 0]} material={m.glass}>
            <planeGeometry args={[pw - fw, ph - fw]} />
          </mesh>,
        )
      } else if (k < 0.8) {
        panes.push(<mesh key={`s${r}${c}`} geometry={shard} position={[cx - pw / 2 + fw / 2, cy - ph / 2 + fw / 2, 0]} material={m.glass} />)
      }
    }
  }
  return (
    <group>
      <mesh position={[-w / 2 + fw / 2, h / 2, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[fw, h, 0.1]} />
      </mesh>
      <mesh position={[w / 2 - fw / 2, h / 2, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[fw, h, 0.1]} />
      </mesh>
      <mesh position={[0, h - fw / 2, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[w, fw, 0.1]} />
      </mesh>
      <mesh position={[0, fw / 2, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[w, fw, 0.1]} />
      </mesh>
      {Array.from({ length: cols - 1 }).map((_, i) => (
        <mesh key={`v${i}`} position={[-w / 2 + (i + 1) * pw, h / 2, 0]} material={m.steelDark} castShadow>
          <boxGeometry args={[0.05, h, 0.08]} />
        </mesh>
      ))}
      <mesh position={[0, h / 2, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[w, 0.05, 0.08]} />
      </mesh>
      {panes}
    </group>
  )
}

function RollupDoor({ w, h, state, inward }: { w: number; h: number; state: 'open' | 'half' | 'closed'; inward: number }) {
  const m = useMaterials()
  const z = inward * 0.12
  const openH = state === 'closed' ? 0 : state === 'half' ? 2.0 : h - 0.15
  return (
    <group>
      <mesh position={[-w / 2 - 0.08, h / 2, z]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.16, h, 0.16]} />
      </mesh>
      <mesh position={[w / 2 + 0.08, h / 2, z]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.16, h, 0.16]} />
      </mesh>
      <mesh position={[0, h + 0.28, z]} material={m.steel} castShadow receiveShadow>
        <boxGeometry args={[w + 0.5, 0.56, 0.56]} />
      </mesh>
      {h - openH > 0.05 && (
        <mesh position={[0, openH + (h - openH) / 2, z]} material={m.shutter} castShadow receiveShadow>
          <boxGeometry args={[w, h - openH, 0.06]} />
        </mesh>
      )}
      <mesh position={[0, openH + 0.04, z]} material={m.steelDark} castShadow>
        <boxGeometry args={[w + 0.1, 0.08, 0.1]} />
      </mesh>
    </group>
  )
}

function SteelDoorFrame({ o, t }: { o: Opening; t: number }) {
  const m = useMaterials()
  const ow = o.w
  const oh = o.t - o.b
  const jd = t + 0.04
  const swing = o.swing ?? 1.5
  const hingeX = o.hinge === 'right' ? ow / 2 - 0.02 : -ow / 2 + 0.02
  const dir = o.flip ? -1 : 1
  const rotY = (o.hinge === 'right' ? -swing : swing) * dir
  const leafW = ow - 0.05
  const leafH = oh - 0.03
  const leafOffset = o.hinge === 'right' ? -leafW / 2 : leafW / 2
  return (
    <group position={[0, o.b, 0]}>
      <mesh position={[-ow / 2 - 0.04, oh / 2, 0]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, oh + 0.08, jd]} />
      </mesh>
      <mesh position={[ow / 2 + 0.04, oh / 2, 0]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, oh + 0.08, jd]} />
      </mesh>
      <mesh position={[0, oh + 0.04, 0]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[ow + 0.16, 0.08, jd]} />
      </mesh>
      {o.leaf && o.leaf !== 'none' && (
        <group position={[hingeX, 0, 0]} rotation={[0, o.leaf === 'closed' ? 0 : rotY, 0]}>
          <group position={[leafOffset, leafH / 2 + 0.01, 0]}>
            <mesh castShadow receiveShadow material={m.paintCream}>
              <boxGeometry args={[leafW, leafH, 0.05]} />
            </mesh>
            <mesh position={[leafOffset > 0 ? leafW / 2 - 0.1 : -leafW / 2 + 0.1, -0.05, 0.05]} material={m.metal}>
              <boxGeometry args={[0.12, 0.03, 0.03]} />
            </mesh>
          </group>
        </group>
      )}
    </group>
  )
}

// ---------------------------------------------------------------------------
// house
function DoorLeaf({ w, h, offset, mat }: { w: number; h: number; offset: number; mat: THREE.Material }) {
  const m = useMaterials()
  const knobX = offset > 0 ? w / 2 - 0.08 : -w / 2 + 0.08
  return (
    <group position={[offset, h / 2 + 0.01, 0]}>
      <mesh castShadow receiveShadow material={mat}>
        <boxGeometry args={[w, h, 0.045]} />
      </mesh>
      {[0.026, -0.026].map((z) => (
        <group key={z}>
          <mesh position={[0, h * 0.25, z]} material={mat}>
            <boxGeometry args={[w * 0.7, h * 0.36, 0.012]} />
          </mesh>
          <mesh position={[0, -h * 0.26, z]} material={mat}>
            <boxGeometry args={[w * 0.7, h * 0.36, 0.012]} />
          </mesh>
        </group>
      ))}
      <mesh position={[knobX, -0.05, 0.05]} material={m.metal}>
        <sphereGeometry args={[0.03, 12, 10]} />
      </mesh>
      <mesh position={[knobX, -0.05, -0.05]} material={m.metal}>
        <sphereGeometry args={[0.03, 12, 10]} />
      </mesh>
    </group>
  )
}

export function HouseDoorFrame({ o, t, leafMat }: { o: Opening; t: number; leafMat: THREE.Material }) {
  const m = useMaterials()
  const ow = o.w
  const oh = o.t - o.b
  const jd = t + 0.06
  const swing = o.swing ?? 1.5
  const hingeX = o.hinge === 'right' ? ow / 2 - 0.02 : -ow / 2 + 0.02
  const dir = o.flip ? -1 : 1
  const rotY = (o.hinge === 'right' ? -swing : swing) * dir
  const leafW = ow - 0.05
  const leafH = oh - 0.03
  const leafOffset = o.hinge === 'right' ? -leafW / 2 : leafW / 2
  return (
    <group position={[0, o.b, 0]}>
      <mesh position={[-ow / 2 - 0.05, oh / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.1, oh + 0.1, jd]} />
      </mesh>
      <mesh position={[ow / 2 + 0.05, oh / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.1, oh + 0.1, jd]} />
      </mesh>
      <mesh position={[0, oh + 0.05, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[ow + 0.2, 0.1, jd]} />
      </mesh>
      {o.leaf && o.leaf !== 'none' && o.leaf !== 'fallen' && (
        <group position={[hingeX, 0, 0]} rotation={[0, o.leaf === 'closed' ? 0 : rotY, 0]}>
          <DoorLeaf w={leafW} h={leafH} offset={leafOffset} mat={leafMat} />
        </group>
      )}
      {o.leaf === 'fallen' && (
        <group position={[0.15, 0.025, -0.9 * dir]} rotation={[-Math.PI / 2, 0, 0.35]}>
          <DoorLeaf w={leafW} h={leafH} offset={0} mat={leafMat} />
        </group>
      )}
    </group>
  )
}

function HouseWindow({ o, t, inward }: { o: Opening; t: number; inward: number }) {
  const m = useMaterials()
  const ow = o.w
  const oh = o.t - o.b
  const fd = 0.08
  const fw = 0.06
  const shardGeo = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(0, 0)
    s.lineTo(ow * 0.42, 0)
    s.lineTo(ow * 0.3, oh * 0.18)
    s.lineTo(ow * 0.12, oh * 0.3)
    s.lineTo(0, oh * 0.2)
    s.closePath()
    const s2 = new THREE.Shape()
    s2.moveTo(0, 0)
    s2.lineTo(-ow * 0.3, 0)
    s2.lineTo(-ow * 0.22, -oh * 0.25)
    s2.lineTo(-ow * 0.05, -oh * 0.4)
    s2.lineTo(0, -oh * 0.1)
    s2.closePath()
    return [new THREE.ShapeGeometry(s), new THREE.ShapeGeometry(s2)]
  }, [ow, oh])
  return (
    <group>
      <mesh position={[-ow / 2 + fw / 2, oh / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[fw, oh, fd]} />
      </mesh>
      <mesh position={[ow / 2 - fw / 2, oh / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[fw, oh, fd]} />
      </mesh>
      <mesh position={[0, oh - fw / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[ow, fw, fd]} />
      </mesh>
      <mesh position={[0, fw / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[ow, fw, fd]} />
      </mesh>
      <mesh position={[0, oh / 2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.045, oh, fd * 0.8]} />
      </mesh>
      <mesh position={[0, oh * 0.6, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[ow, 0.045, fd * 0.8]} />
      </mesh>
      {/* sill inside */}
      <mesh position={[0, -0.03, inward * (t / 2 + 0.06)]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[ow + 0.22, 0.05, 0.2]} />
      </mesh>
      {/* broken glass remains */}
      <mesh geometry={shardGeo[0]} position={[-ow / 2 + fw, oh * 0.6 + 0.03, 0]} material={m.glass} />
      <mesh geometry={shardGeo[1]} position={[ow / 2 - fw, oh - fw, 0]} material={m.glass} />
      <mesh geometry={shardGeo[0]} position={[0.03, fw, 0]} scale={[0.6, 0.7, 1]} material={m.glass} />
    </group>
  )
}

// ---------------------------------------------------------------------------
export function Openings() {
  const m = useMaterials()
  const items: React.ReactNode[] = []
  let seed = 1
  for (const w of WALLS) {
    const house = w.style === 'house'
    for (let i = 0; i < w.openings.length; i++) {
      const o = w.openings[i]
      let pos: V3
      let rotY = 0
      let inward = 1
      if (w.axis === 'x') {
        pos = [w.x + o.at, w.y + (o.kind === 'window' ? o.b : 0), w.z]
        inward = w.z > 0 ? -1 : 1
      } else {
        pos = [w.x, w.y + (o.kind === 'window' ? o.b : 0), w.z + o.at]
        rotY = Math.PI / 2
        inward = w.x > 0 ? -1 : 1
      }
      const key = `${w.id}-${i}`
      seed++
      if (o.kind === 'window') {
        items.push(
          <group key={key} position={pos} rotation={[0, rotY, 0]}>
            {house ? <HouseWindow o={o} t={w.t} inward={inward} /> : <SteelWindow w={o.w} h={o.t - o.b} seed={seed} />}
          </group>,
        )
      } else if (o.kind === 'door') {
        items.push(
          <group key={key} position={pos} rotation={[0, rotY, 0]}>
            {house ? <HouseDoorFrame o={o} t={w.t} leafMat={w.exterior ? m.woodDark : m.paintCream} /> : <SteelDoorFrame o={o} t={w.t} />}
          </group>,
        )
      } else if (o.kind === 'rollup') {
        items.push(
          <group key={key} position={pos} rotation={[0, rotY, 0]}>
            <RollupDoor w={o.w} h={o.t} state={o.rollup ?? 'open'} inward={inward} />
          </group>,
        )
      }
    }
  }
  return <>{items}</>
}

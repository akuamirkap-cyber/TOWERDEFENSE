import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials } from './materials'
import { F2, H_CEIL1, H_CEIL2, boxCollider, type AABB } from './layout'
import { B, Cyl, Crate, Cabinet, Shelving, Drum, Mattress, Mound, Cable, Lockers, Bench, Sofa, Toilet, BedFrame, Extinguisher, Desk } from './Props'

type V3 = [number, number, number]
const Y = F2

// ---------------------------------------------------------------------------
export const HOUSE_COLLIDERS: AABB[] = [
  // ground – living
  boxCollider(-32.4, -3.22, 1.5, 0.5, 0, 1.3), // fireplace
  boxCollider(-32.6, -0.9, 1.95, 0.9, 0, 0.9), // sofa
  boxCollider(-32.6, -2.0, 1.0, 0.55, 0, 0.46), // coffee table
  boxCollider(-35.5, 1.5, 0.95, 1.95, 0, 0.4), // fallen bookcase (step over)
  boxCollider(-36.35, 1.8, 0.5, 0.9, 0, 0.6), // tv cabinet
  // library
  boxCollider(-41.2, -3.25, 1.2, 0.4, 0, 2.2),
  boxCollider(-38.1, -3.25, 1.2, 0.4, 0, 2.2),
  boxCollider(-38.5, 1.8, 1.65, 0.85, 0, 0.8), // desk
  boxCollider(-40.8, 0.3, 0.6, 0.6, 0, 0.6), // side table
  // kitchen
  boxCollider(-34.5, -10.55, 3.8, 0.62, 0, 0.95),
  boxCollider(-32.1, -10.55, 0.62, 0.62, 0, 0.95), // stove
  boxCollider(-31.85, -5.0, 0.72, 0.72, 0, 1.85), // fridge
  boxCollider(-34.2, -7.2, 1.25, 0.85, 0, 0.8), // table
  // pantry / laundry
  boxCollider(-41.6, -6.3, 0.52, 0.82, 0, 2.0),
  boxCollider(-41.6, -4.0, 0.52, 0.82, 0, 2.0),
  boxCollider(-40.3, -6.3, 0.85, 0.85, 0, 0.8),
  boxCollider(-41.05, -10.55, 1.45, 0.65, 0, 0.9), // washers
  boxCollider(-37.5, -10.55, 0.7, 0.55, 0, 0.9), // sink
  boxCollider(-41.5, -7.6, 0.65, 0.65, 0, 1.3), // boiler
  // dining
  boxCollider(-23.6, 0.2, 2.05, 1.05, 0, 0.8),
  boxCollider(-23.4, -2.15, 1.65, 0.55, 0, 0.95), // sideboard
  boxCollider(-26.25, -1.5, 0.55, 1.15, 0, 2.0), // china cabinet
  // wc / storage / back room
  boxCollider(-26.0, -2.85, 0.5, 0.75, 0, 0.8),
  boxCollider(-24.0, -2.85, 0.55, 0.45, 0, 0.85),
  boxCollider(-22.3, -2.85, 2.05, 0.6, 0, 2.0),
  boxCollider(-20.8, -4.0, 0.85, 0.85, 0, 0.8),
  boxCollider(-23.2, -10.72, 1.9, 0.52, 0, 1.95), // lockers
  boxCollider(-26.3, -10.0, 0.4, 1.85, 0, 0.5), // bench
  boxCollider(-20.7, -5.9, 0.65, 0.65, 0, 0.9), // drum
  // hall
  boxCollider(-31.1, -3.5, 0.45, 1.25, 0, 0.8), // console table
  // upper
  boxCollider(-32.3, -2.4, 1.65, 2.1, Y, Y + 0.6), // bed1
  boxCollider(-36.3, -2.3, 0.65, 1.25, Y, Y + 2.1),
  boxCollider(-31.75, 2.3, 0.55, 1.25, Y, Y + 0.9),
  boxCollider(-41.0, -2.4, 1.65, 2.1, Y, Y + 0.6), // bed2
  boxCollider(-37.1, -2.3, 0.65, 1.25, Y, Y + 2.1),
  boxCollider(-32.4, -5.5, 1.0, 2.0, Y, Y + 0.7), // bed4 frame
  boxCollider(-32.2, -10.6, 0.95, 0.5, Y, Y + 0.8),
  boxCollider(-41.3, -4.3, 1.25, 0.75, Y, Y + 0.9), // crib
  boxCollider(-41.5, -6.5, 0.55, 0.85, Y, Y + 0.9),
  boxCollider(-41.4, -9.0, 0.85, 0.85, Y, Y + 1.25), // box room crates
  boxCollider(-40.5, -10.4, 0.8, 0.5, Y, Y + 0.5),
  boxCollider(-38.5, -10.2, 2.1, 1.2, Y, Y + 0.6),
  boxCollider(-21.2, -1.4, 1.25, 2.15, Y, Y + 0.6), // bed5 fallen wardrobe
  boxCollider(-22.5, -2.95, 1.75, 0.75, Y, Y + 0.7), // bathtub
  boxCollider(-25.8, -2.95, 0.5, 0.75, Y, Y + 0.8),
  boxCollider(-21.0, -5.65, 0.55, 0.45, Y, Y + 0.85),
  boxCollider(-23.4, -10.3, 2.0, 1.0, Y, Y + 0.7), // bed6
  boxCollider(-25.5, -7.1, 1.0, 2.0, Y, Y + 0.7),
  boxCollider(-21.0, -6.4, 1.25, 0.65, Y, Y + 2.1),
  boxCollider(-29.0, -10.5, 0.55, 0.45, Y, Y + 0.7), // landing table
]

// ---------------------------------------------------------------------------
function WoodChair({ p, rot, fallen = false }: { p: V3; rot: number; fallen?: boolean }) {
  const m = useMaterials()
  return (
    <group position={fallen ? [p[0], p[1] + 0.21, p[2]] : p} rotation={fallen ? [Math.PI / 2, rot, 0] : [0, rot, 0]}>
      <B p={[0, 0.45, 0]} s={[0.42, 0.04, 0.42]} m={m.woodDark} />
      <B p={[0, 0.72, -0.19]} s={[0.42, 0.5, 0.04]} m={m.woodDark} />
      {[-0.18, 0.18].map((x) =>
        [-0.18, 0.18].map((z) => <B key={`${x}${z}`} p={[x, 0.22, z]} s={[0.04, 0.44, 0.04]} m={m.woodDark} />),
      )}
    </group>
  )
}

function WoodTable({ p, rot, w, d, h = 0.75 }: { p: V3; rot: number; w: number; d: number; h?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, h - 0.025, 0]} s={[w, 0.05, d]} m={m.woodDark} />
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => <B key={`${sx}${sz}`} p={[sx * (w / 2 - 0.06), (h - 0.05) / 2, sz * (d / 2 - 0.06)]} s={[0.07, h - 0.05, 0.07]} m={m.woodDark} />),
      )}
    </group>
  )
}

function Fireplace({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.6, -0.5]} s={[0.4, 1.2, 0.4]} m={m.brickWhite} />
      <B p={[0, 0.6, 0.5]} s={[0.4, 1.2, 0.4]} m={m.brickWhite} />
      <B p={[0, 1.15, 0]} s={[0.4, 0.3, 1.4]} m={m.brickWhite} />
      <B p={[0.05, 1.33, 0]} s={[0.55, 0.07, 1.6]} m={m.woodDark} />
      <B p={[-0.12, 0.45, 0]} s={[0.1, 0.9, 0.6]} m={m.black} />
      <B p={[0.08, 0.02, 0]} s={[0.5, 0.04, 1.0]} m={m.black} />
      <B p={[0.2, 1.75, 0]} s={[0.04, 0.6, 0.9]} m={m.metal} />
    </group>
  )
}

function Radiator({ p, rot, w = 1.0 }: { p: V3; rot: number; w?: number }) {
  const m = useMaterials()
  const n = Math.round(w / 0.1)
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {Array.from({ length: n }).map((_, i) => (
        <B key={i} p={[-w / 2 + (i + 0.5) * (w / n), 0.4, 0]} s={[0.055, 0.6, 0.14]} m={m.paintCream} />
      ))}
      <B p={[0, 0.72, 0]} s={[w, 0.04, 0.16]} m={m.paintCream} />
      <B p={[0, 0.1, 0]} s={[w, 0.04, 0.16]} m={m.paintCream} />
    </group>
  )
}

function Sconce({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0, 0.03]} s={[0.12, 0.2, 0.05]} m={m.metal} />
      <Cyl p={[0, 0.1, 0.16]} r={0.012} h={0.25} m={m.metal} rot={[Math.PI / 2, 0, 0]} />
      <mesh position={[0, 0.22, 0.2]} material={m.paintCream} castShadow receiveShadow>
        <cylinderGeometry args={[0.1, 0.06, 0.16, 16, 1, true]} />
      </mesh>
      <mesh position={[0, 0.2, 0.2]} material={m.paintCream}>
        <sphereGeometry args={[0.03, 10, 8]} />
      </mesh>
    </group>
  )
}

function Pendant({ p, len, tilt = 0 }: { p: V3; len: number; tilt?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[tilt, 0, tilt * 0.6]}>
      <Cyl p={[0, -len / 2, 0]} r={0.006} h={len} m={m.black} seg={6} />
      <mesh position={[0, -len - 0.06, 0]} material={m.metalDark} castShadow>
        <cylinderGeometry args={[0.03, 0.16, 0.14, 20, 1, true]} />
      </mesh>
      <mesh position={[0, -len - 0.1, 0]} material={m.paintCream}>
        <sphereGeometry args={[0.035, 10, 8]} />
      </mesh>
    </group>
  )
}

function Chandelier({ p, len }: { p: V3; len: number }) {
  const m = useMaterials()
  return (
    <group position={p}>
      <Cyl p={[0, -len / 2, 0]} r={0.01} h={len} m={m.metalDark} seg={6} />
      <mesh position={[0, -len - 0.05, 0]} material={m.metalDark} castShadow>
        <torusGeometry args={[0.38, 0.02, 8, 28]} />
      </mesh>
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2
        return (
          <group key={i} position={[Math.cos(a) * 0.38, -len - 0.05, Math.sin(a) * 0.38]}>
            <Cyl p={[0, 0.08, 0]} r={0.015} h={0.16} m={m.metalDark} seg={8} />
            {i !== 2 && (
              <mesh position={[0, 0.2, 0]} material={m.paintCream}>
                <sphereGeometry args={[0.04, 10, 8]} />
              </mesh>
            )}
          </group>
        )
      })}
    </group>
  )
}

function Bed({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.25, 0]} s={[1.6, 0.12, 2.0]} m={m.woodDark} />
      <B p={[0, 0.42, 0]} s={[1.5, 0.22, 1.9]} m={m.mattress} />
      <B p={[0, 0.6, -1.02]} s={[1.6, 0.9, 0.06]} m={m.woodDark} />
      {[-0.75, 0.75].map((x) =>
        [-0.95, 0.95].map((z) => <B key={`${x}${z}`} p={[x, 0.12, z]} s={[0.08, 0.25, 0.08]} m={m.woodDark} />),
      )}
      <B p={[0.3, 0.58, 0.3]} s={[0.9, 0.1, 1.2]} m={m.fabricDark} />
    </group>
  )
}

function Wardrobe({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 1.05, 0]} s={[1.2, 2.1, 0.6]} m={m.woodDark} />
      <group position={[-0.6, 0.05, 0.3]} rotation={[0, 0.9, 0]}>
        <B p={[0.29, 1.0, 0.0]} s={[0.58, 2.0, 0.03]} m={m.wood} />
      </group>
      <B p={[0.3, 1.05, 0.3]} s={[0.58, 2.0, 0.03]} m={m.wood} />
    </group>
  )
}

function LyingWardrobe({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.3, 0]} s={[2.1, 0.6, 1.2]} m={m.woodDark} />
      <B p={[0, 0.61, -0.3]} s={[2.0, 0.02, 0.56]} m={m.wood} />
      <B p={[0.3, 0.75, 0.5]} s={[1.6, 0.03, 0.56]} r={[0.25, 0, 0]} m={m.wood} />
    </group>
  )
}

function Bathtub({ p }: { p: V3 }) {
  const m = useMaterials()
  return (
    <group position={p}>
      <B p={[0, 0.3, 0]} s={[1.7, 0.6, 0.7]} m={m.paintWhite} />
      <B p={[0, 0.62, 0]} s={[1.78, 0.06, 0.78]} m={m.paintWhite} />
      <B p={[0, 0.55, 0]} s={[1.5, 0.1, 0.5]} m={m.fabricDark} />
      <Cyl p={[-0.7, 0.75, -0.3]} r={0.015} h={0.3} m={m.metal} />
      <Cyl p={[-0.7, 0.9, -0.3]} r={0.04} h={0.06} m={m.metal} />
    </group>
  )
}

function Bookcase({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 1.1, -0.16]} s={[1.2, 2.2, 0.03]} m={m.woodDark} />
      <B p={[-0.585, 1.1, 0]} s={[0.03, 2.2, 0.35]} m={m.woodDark} />
      <B p={[0.585, 1.1, 0]} s={[0.03, 2.2, 0.35]} m={m.woodDark} />
      {[0.03, 0.55, 1.07, 1.59, 2.18].map((y) => (
        <B key={y} p={[0, y, 0]} s={[1.2, 0.03, 0.35]} m={m.woodDark} />
      ))}
      {[0.3, 0.82, 1.34].map((y, i) => (
        <B key={y} p={[-0.15 + i * 0.1, y, 0.02]} s={[0.7 - i * 0.15, 0.5, 0.25]} m={i % 2 ? m.paper : m.fabricDark} />
      ))}
    </group>
  )
}

function KitchenRun() {
  const m = useMaterials()
  return (
    <group>
      <B p={[-34.5, 0.45, -10.55]} s={[3.8, 0.9, 0.6]} m={m.paintCream} />
      <B p={[-34.5, 0.92, -10.55]} s={[3.9, 0.04, 0.64]} m={m.woodDark} />
      <B p={[-34.0, 0.9, -10.55]} s={[0.7, 0.12, 0.45]} m={m.metal} />
      <Cyl p={[-34.0, 1.1, -10.75]} r={0.012} h={0.3} m={m.metal} />
      <B p={[-35.65, 1.95, -10.68]} s={[1.5, 0.7, 0.35]} m={m.paintCream} />
      <B p={[-32.9, 1.95, -10.68]} s={[0.6, 0.7, 0.35]} m={m.paintCream} />
      <group position={[-36.4, 1.95, -10.5]} rotation={[0, -1.1, 0]}>
        <B p={[0.37, 0, 0]} s={[0.74, 0.66, 0.02]} m={m.paintCream} />
      </group>
      {[-36.0, -35.3, -33.6].map((x) => (
        <group key={x} position={[x, 0.45, -10.25]}>
          <B p={[0, 0, 0]} s={[0.66, 0.86, 0.02]} m={m.paintCream} />
          <B p={[0.22, 0, 0.03]} s={[0.1, 0.02, 0.04]} m={m.metal} />
        </group>
      ))}
      <B p={[-32.1, 0.45, -10.55]} s={[0.6, 0.9, 0.6]} m={m.metal} />
      <B p={[-32.1, 0.91, -10.55]} s={[0.56, 0.02, 0.56]} m={m.black} />
      {/* fridge with open door */}
      <B p={[-31.85, 0.9, -5.0]} s={[0.7, 1.8, 0.7]} m={m.paintWhite} />
      <group position={[-32.2, 0.9, -4.65]} rotation={[0, 1.9, 0]}>
        <B p={[0.35, 0, 0]} s={[0.7, 1.78, 0.04]} m={m.paintWhite} />
      </group>
      <B p={[-31.85, 0.9, -4.66]} s={[0.6, 1.6, 0.02]} m={m.black} />
    </group>
  )
}

function Washer({ p }: { p: V3 }) {
  const m = useMaterials()
  return (
    <group position={p}>
      <B p={[0, 0.425, 0]} s={[0.6, 0.85, 0.6]} m={m.paintWhite} />
      <mesh position={[0, 0.45, 0.31]} material={m.metalDark}>
        <torusGeometry args={[0.18, 0.025, 8, 24]} />
      </mesh>
      <mesh position={[0, 0.45, 0.3]} material={m.black}>
        <circleGeometry args={[0.17, 20]} />
      </mesh>
    </group>
  )
}

function Crib({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.45, 0]} s={[1.2, 0.04, 0.7]} m={m.paintWhite} />
      <B p={[0, 0.5, 0]} s={[1.1, 0.08, 0.6]} m={m.mattress} />
      {[-0.58, 0.58].map((x) =>
        [-0.33, 0.33].map((z) => <B key={`${x}${z}`} p={[x, 0.45, z]} s={[0.04, 0.9, 0.04]} m={m.paintWhite} />),
      )}
      {Array.from({ length: 9 }).map((_, i) => (
        <B key={i} p={[-0.5 + i * 0.125, 0.65, 0.33]} s={[0.02, 0.5, 0.02]} m={m.paintWhite} />
      ))}
      {Array.from({ length: 9 }).map((_, i) => (
        <B key={`b${i}`} p={[-0.5 + i * 0.125, 0.65, -0.33]} s={[0.02, 0.5, 0.02]} m={m.paintWhite} />
      ))}
      <B p={[0, 0.88, 0.33]} s={[1.2, 0.04, 0.04]} m={m.paintWhite} />
      <B p={[0, 0.88, -0.33]} s={[1.2, 0.04, 0.04]} m={m.paintWhite} />
    </group>
  )
}

function Dresser({ p, rot, s = [0.5, 0.9, 1.2] as V3 }: { p: V3; rot: number; s?: V3 }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, s[1] / 2, 0]} s={s} m={m.woodDark} />
      {[0.3, 0.6].map((f) => (
        <B key={f} p={[s[0] / 2 + 0.005, s[1] * f, 0]} s={[0.01, s[1] * 0.22, s[2] * 0.85]} m={m.wood} />
      ))}
      <B p={[s[0] / 2 + 0.03, s[1] * 0.45, 0.35]} s={[0.03, 0.03, 0.12]} m={m.metal} />
    </group>
  )
}

function HangingPanel({ p, rot, s }: { p: V3; rot: V3; s?: V3 }) {
  const m = useMaterials()
  return <B p={p} r={rot} s={s ?? [0.6, 0.02, 1.2]} m={m.ceiling} />
}

function FallenDoor({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.025, 0]} s={[0.9, 0.045, 2.0]} m={m.paintCream} />
      <B p={[0, 0.055, -0.5]} s={[0.62, 0.012, 0.7]} m={m.paintCream} />
      <B p={[0, 0.055, 0.5]} s={[0.62, 0.012, 0.7]} m={m.paintCream} />
    </group>
  )
}

function Rug({ p, w, d, rot = 0, color = '#4a3f36' }: { p: V3; w: number; d: number; rot?: number; color?: string }) {
  const mat = useMemo(() => new THREE.MeshStandardMaterial({ color, roughness: 1 }), [color])
  return (
    <mesh position={p} rotation={[-Math.PI / 2, 0, rot]} material={mat} receiveShadow>
      <planeGeometry args={[w, d]} />
    </mesh>
  )
}

function Poster({ p, rot, w, h }: { p: V3; rot: V3; w: number; h: number }) {
  const m = useMaterials()
  return (
    <mesh position={p} rotation={rot} material={m.paper} receiveShadow>
      <planeGeometry args={[w, h]} />
    </mesh>
  )
}

function ClothPile({ p, s }: { p: V3; s: number }) {
  const m = useMaterials()
  return (
    <mesh position={p} scale={[s, s * 0.45, s * 0.8]} material={m.fabricDark} castShadow receiveShadow>
      <sphereGeometry args={[0.5, 12, 8]} />
    </mesh>
  )
}

// ---------------------------------------------------------------------------
export function HouseProps() {
  const m = useMaterials()
  const mirror = useMemo(() => new THREE.MeshStandardMaterial({ color: '#b9c4c6', roughness: 0.15, metalness: 0.9 }), [])
  return (
    <group>
      {/* ================= HALL ================= */}
      <B p={[-31.1, 0.4, -3.5]} s={[0.4, 0.8, 1.2]} m={m.woodDark} />
      <B p={[-31.1, 0.86, -3.3]} s={[0.3, 0.12, 0.3]} m={m.paintCream} />
      <WoodChair p={[-30.3, 0, -6.0]} rot={0.6} fallen />
      <FallenDoor p={[-29.8, 0, -5.6]} rot={0.3} />
      <Sconce p={[-31.32, 1.9, -1.5]} rot={Math.PI / 2} />
      <Sconce p={[-31.32, 1.9, -6.0]} rot={Math.PI / 2} />
      <Pendant p={[-29.6, H_CEIL1, 1.0]} len={0.6} tilt={0.2} />
      <Pendant p={[-29.6, H_CEIL1, -7.5]} len={0.55} />
      <Chandelier p={[-27.2, H_CEIL2, -3.0]} len={1.7} />
      <Cyl p={[-30.9, 0.9, 2.3]} r={0.02} h={1.8} m={m.woodDark} seg={8} />
      <Cyl p={[-30.9, 1.75, 2.3]} r={0.14} h={0.03} m={m.woodDark} seg={10} />
      <Extinguisher p={[-26.68, 1.0, -9.5]} rot={-Math.PI / 2} />

      {/* ================= LIVING ROOM ================= */}
      <Fireplace p={[-32.4, 0, -3.22]} rot={-Math.PI / 2} />
      <Sofa p={[-32.6, 0, -0.9]} rot={Math.PI} />
      <WoodTable p={[-32.6, 0, -2.0]} rot={0} w={1.0} d={0.5} h={0.45} />
      <WoodChair p={[-34.6, 0, -2.0]} rot={-0.9} />
      <Rug p={[-33.2, 0.006, -1.3]} w={2.6} d={1.9} rot={0.05} />
      <group position={[-35.5, 0, 1.5]} rotation={[Math.PI / 2, 0, 0.1]}>
        <B p={[0, 0.95, -0.17]} s={[0.9, 1.9, 0.32]} m={m.woodDark} />
      </group>
      <B p={[-36.35, 0.3, 1.8]} s={[0.5, 0.6, 0.9]} m={m.woodDark} />
      <B p={[-36.1, 0.78, 1.8]} s={[0.1, 0.36, 0.5]} m={m.black} />
      <group position={[-35.8, 0.95, -3.15]} rotation={[-0.18, 0, 0]}>
        <B p={[0, 0, 0]} s={[1.0, 1.95, 0.22]} m={m.mattress} />
      </group>
      <Radiator p={[-35.1, 0, 2.77]} rot={0} />
      <Radiator p={[-33.0, 0, 2.77]} rot={0} />
      <Sconce p={[-31.48, 1.9, -1.8]} rot={-Math.PI / 2} />
      <Sconce p={[-31.48, 1.9, 2.4]} rot={-Math.PI / 2} />
      <Pendant p={[-34, H_CEIL1, 0]} len={0.5} />
      {[0, 1, 2, 3].map((i) => (
        <B key={i} p={[-34.6 + (i % 2) * 0.3, 0.02, 0.9 + i * 0.2]} s={[0.22, 0.04, 0.16]} r={[0, i * 0.7, 0]} m={i % 2 ? m.paper : m.plasticBlue} />
      ))}

      {/* ================= LIBRARY ================= */}
      <Bookcase p={[-41.2, 0, -3.25]} rot={0} />
      <Bookcase p={[-38.1, 0, -3.25]} rot={0} />
      <Desk p={[-38.5, 0, 1.8]} rot={Math.PI} />
      <WoodChair p={[-38.5, 0, 1.0]} rot={0.1} />
      <WoodChair p={[-40.8, 0, 1.2]} rot={Math.PI / 2 + 0.2} />
      <WoodTable p={[-40.8, 0, 0.3]} rot={0} w={0.55} d={0.55} h={0.6} />
      <Rug p={[-39.5, 0.006, -0.6]} w={2.4} d={2.0} rot={-0.08} color="#52483c" />
      <Pendant p={[-39.35, H_CEIL1, -0.25]} len={0.45} />
      <Radiator p={[-39.4, 0, 2.77]} rot={0} />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <B key={i} p={[-40.6 + (i % 3) * 0.35, 0.02 + (i % 2) * 0.03, -2.6 + i * 0.12]} s={[0.22, 0.04, 0.16]} r={[0, i * 0.9, 0]} m={i % 2 ? m.paper : m.fabricDark} />
      ))}

      {/* ================= KITCHEN ================= */}
      <KitchenRun />
      <WoodTable p={[-34.2, 0, -7.2]} rot={0.1} w={1.2} d={0.8} />
      <WoodChair p={[-34.7, 0, -6.5]} rot={0.3} />
      <WoodChair p={[-33.5, 0, -7.9]} rot={2.6} fallen />
      <HangingPanel p={[-33.0, H_CEIL1 - 0.45, -8.4]} rot={[0.9, 0.2, 0]} />
      <HangingPanel p={[-35.6, H_CEIL1 - 0.3, -6.0]} rot={[-0.6, 0.1, 0.1]} s={[1.2, 0.02, 0.6]} />
      <Cable pts={[[-33.0, H_CEIL1, -9.0], [-32.95, H_CEIL1 - 0.5, -8.9], [-33.1, H_CEIL1 - 1.1, -8.95]]} r={0.01} />
      <Pendant p={[-34, H_CEIL1, -7.2]} len={0.6} tilt={0.15} />

      {/* ================= PANTRY / LAUNDRY ================= */}
      <Cabinet p={[-41.6, 0, -6.3]} rot={Math.PI / 2} />
      <Cabinet p={[-41.6, 0, -4.0]} rot={Math.PI / 2} open />
      <Crate p={[-40.3, 0, -6.3]} s={[0.8, 0.7, 0.8]} rot={0.3} />
      <Mound p={[-38.4, 0, -4.2]} s={[0.5, 0.3, 0.45]} />
      <Mound p={[-37.9, 0, -6.2]} s={[0.4, 0.25, 0.4]} />
      <Washer p={[-41.4, 0, -10.55]} />
      <Washer p={[-40.7, 0, -10.55]} />
      <B p={[-37.5, 0.45, -10.55]} s={[0.7, 0.9, 0.55]} m={m.paintWhite} />
      <B p={[-37.5, 0.9, -10.55]} s={[0.6, 0.1, 0.45]} m={m.metal} />
      <Cyl p={[-41.5, 0.65, -7.6]} r={0.3} h={1.3} m={m.steelLight} seg={20} />
      <Cyl p={[-41.5, 2.2, -7.6]} r={0.04} h={1.8} m={m.rust} seg={8} />
      <Cyl p={[-39.0, 0.14, -8.3]} r={0.16} h={0.28} m={m.plasticBlue} seg={14} />
      <Cable pts={[[-41.5, 2.9, -7.6], [-41.0, 3.1, -8.5], [-40.0, 3.2, -9.5], [-39.0, 3.25, -10.6]]} r={0.02} mat={m.steelLight} />

      {/* ================= DINING ================= */}
      <WoodTable p={[-23.6, 0, 0.2]} rot={0.05} w={2.0} d={1.0} />
      <WoodChair p={[-24.4, 0, -0.6]} rot={0.2} />
      <WoodChair p={[-22.9, 0, -0.6]} rot={-0.3} />
      <WoodChair p={[-24.3, 0, 1.1]} rot={3.0} fallen />
      <WoodChair p={[-22.7, 0, 1.0]} rot={3.4} />
      <B p={[-23.4, 0.45, -2.15]} s={[1.6, 0.9, 0.5]} m={m.woodDark} />
      <B p={[-23.4, 0.92, -2.15]} s={[1.7, 0.04, 0.55]} m={m.woodDark} />
      <B p={[-26.25, 1.0, -1.5]} s={[0.5, 2.0, 1.1]} m={m.woodDark} />
      <B p={[-25.98, 1.3, -1.5]} s={[0.02, 1.0, 0.9]} m={m.glass} />
      <Radiator p={[-25, 0, 2.77]} rot={0} />
      <Radiator p={[-22, 0, 2.77]} rot={0} />
      <Mattress p={[-21.2, 0, -1.2]} rot={0} />
      <Pendant p={[-23.6, H_CEIL1, 0.2]} len={0.6} />

      {/* ================= WC / STORAGE / BACK ROOM ================= */}
      <Toilet p={[-26.0, 0, -2.95]} rot={Math.PI} />
      <B p={[-24.0, 0.8, -2.85]} s={[0.5, 0.12, 0.4]} m={m.paintWhite} />
      <B p={[-24.0, 0.4, -2.85]} s={[0.15, 0.8, 0.15]} m={m.paintWhite} />
      <mesh position={[-24.0, 1.5, -2.58]} material={mirror} receiveShadow>
        <planeGeometry args={[0.45, 0.6]} />
      </mesh>
      <Shelving p={[-22.3, 0, -2.85]} />
      <Crate p={[-20.8, 0, -4.0]} s={[0.8, 0.7, 0.8]} rot={0.2} />
      <Lockers p={[-23.2, 0, -10.72]} rot={0} n={3} />
      <Bench p={[-26.3, 0, -10.0]} rot={Math.PI / 2} />
      <Drum p={[-20.7, 0, -5.9]} />
      <B p={[-26.4, 1.5, -6.6]} s={[0.25, 0.4, 0.3]} m={m.steel} />
      <Cable pts={[[-26.4, 1.7, -6.6], [-26.0, 2.6, -6.8], [-24.0, 3.3, -8.0], [-21.0, 3.4, -9.0], [-20.3, 3.0, -9.5]]} r={0.02} />
      <Cable pts={[[-20.3, 2.7, -9.0], [-21.5, 2.8, -8.2], [-23.0, 3.1, -7.4], [-25.5, 3.2, -6.6]]} r={0.015} mat={m.steelDark} />
      {[0, 1, 2, 3].map((i) => (
        <B key={i} p={[-25.9, 1.7, -9.8 + i * 0.35]} s={[0.08, 0.02, 0.02]} m={m.metal} />
      ))}

      {/* ================= LANDING ================= */}
      <Radiator p={[-29, Y, 2.77]} rot={0} />
      <Radiator p={[-29, Y, -10.77]} rot={0} />
      <FallenDoor p={[-30.0, Y, -1.0]} rot={-0.4} />
      <B p={[-29.0, Y + 0.35, -10.5]} s={[0.5, 0.7, 0.4]} m={m.woodDark} />
      <Cyl p={[-29.0, Y + 0.95, -10.5]} r={0.12} h={0.3} m={m.paintCream} seg={12} />
      <Sconce p={[-31.32, Y + 1.9, -4.5]} rot={Math.PI / 2} />
      <Sconce p={[-31.32, Y + 1.9, 0.0]} rot={Math.PI / 2} />
      <Pendant p={[-29, H_CEIL2, -7.5]} len={0.5} tilt={0.1} />

      {/* ================= BED 1 ================= */}
      <Bed p={[-32.3, Y, -2.4]} rot={0} />
      <Wardrobe p={[-36.3, Y, -2.3]} rot={Math.PI / 2} />
      <Dresser p={[-31.75, Y, 2.3]} rot={Math.PI} />
      <WoodChair p={[-35.5, Y, 1.8]} rot={1.0} />
      <Rug p={[-33.8, Y + 0.006, 0.3]} w={2.4} d={1.8} rot={-0.15} />
      <Radiator p={[-35.1, Y, 2.77]} rot={0} />
      <Radiator p={[-33.0, Y, 2.77]} rot={0} />
      <Pendant p={[-34, H_CEIL2, -0.3]} len={0.45} />
      <Poster p={[-31.485, Y + 1.6, -0.5]} rot={[0, -Math.PI / 2, 0.05]} w={0.6} h={0.85} />

      {/* ================= BED 2 ================= */}
      <Bed p={[-41.0, Y, -2.4]} rot={0} />
      <Wardrobe p={[-37.1, Y, -2.3]} rot={-Math.PI / 2} />
      <Mattress p={[-38.5, Y, 1.6]} rot={0.3} />
      <WoodChair p={[-40.9, Y, 1.5]} rot={2.0} fallen />
      <Radiator p={[-39.4, Y, 2.77]} rot={0} />
      <Pendant p={[-39.35, H_CEIL2, -0.3]} len={0.45} />
      <Poster p={[-41.835, Y + 1.7, 1.6]} rot={[0, Math.PI / 2, -0.08]} w={0.6} h={0.85} />
      <Poster p={[-41.835, Y + 1.5, -1.3]} rot={[0, Math.PI / 2, 0.1]} w={0.5} h={0.7} />

      {/* ================= BED 4 (collapsed roof) ================= */}
      <BedFrame p={[-32.4, Y, -5.5]} rot={Math.PI / 2} mattress={false} />
      <Dresser p={[-32.2, Y, -10.6]} rot={-Math.PI / 2} s={[0.5, 0.8, 0.9]} />
      <WoodChair p={[-35.8, Y, -10.3]} rot={1.6} />
      <Mound p={[-34.2, Y, -7.3]} s={[1.4, 0.45, 1.2]} rot={0.4} />
      <Mound p={[-33.0, Y, -6.4]} s={[0.8, 0.3, 0.7]} />
      <B p={[-34.8, Y + 0.1, -8.2]} s={[1.6, 0.2, 0.12]} r={[0, 0.7, 0]} m={m.woodDark} />
      <B p={[-33.4, Y + 0.06, -7.8]} s={[1.2, 0.12, 0.1]} r={[0, -0.4, 0.05]} m={m.woodDark} />
      <B p={[-35.3, Y + 0.25, -6.6]} s={[0.9, 0.5, 0.7]} r={[0.2, 0.5, 0.1]} m={m.ceiling} />
      <Radiator p={[-34, Y, -10.77]} rot={0} w={1.2} />

      {/* ================= NURSERY / BOX ROOM ================= */}
      <Crib p={[-41.3, Y, -4.3]} rot={0} />
      <WoodChair p={[-37.9, Y, -6.5]} rot={2.4} />
      <Dresser p={[-41.5, Y, -6.5]} rot={0} s={[0.5, 0.9, 0.8]} />
      <Rug p={[-39.5, Y + 0.006, -5.2]} w={1.8} d={1.6} color="#5a5248" />
      {[0, 1, 2].map((i) => (
        <B key={i} p={[-39.8 + i * 0.25, Y + 0.08, -4.4 + (i % 2) * 0.2]} s={[0.16, 0.16, 0.16]} r={[0, i, 0]} m={i === 1 ? m.plasticBlue : m.paintCream} />
      ))}
      <Pendant p={[-39.35, H_CEIL2, -5.2]} len={0.4} />
      <Crate p={[-41.4, Y, -9.0]} s={[0.8, 0.7, 0.8]} />
      <Crate p={[-41.3, Y + 0.7, -9.0]} s={[0.6, 0.5, 0.6]} rot={0.3} />
      <B p={[-40.5, Y + 0.12, -10.4]} s={[0.75, 0.24, 0.45]} m={m.fabricDark} />
      <B p={[-40.5, Y + 0.36, -10.4]} s={[0.65, 0.22, 0.4]} r={[0, 0.15, 0]} m={m.woodDark} />
      <LyingWardrobe p={[-38.5, Y, -10.2]} rot={0} />
      <ClothPile p={[-39.8, Y, -8.3]} s={0.8} />

      {/* ================= BED 5 ================= */}
      <Mattress p={[-23.4, Y, 0.0]} rot={0} />
      <B p={[-23.3, Y + 0.3, 0.1]} s={[0.7, 0.2, 1.6]} m={m.fabricDark} />
      <LyingWardrobe p={[-21.2, Y, -1.4]} rot={Math.PI / 2} />
      <ClothPile p={[-25.5, Y, 1.8]} s={0.9} />
      <ClothPile p={[-24.9, Y, 2.3]} s={0.6} />
      <Radiator p={[-25, Y, 2.77]} rot={0} />
      <Radiator p={[-22, Y, 2.77]} rot={0} />
      <Poster p={[-20.21, Y + 1.7, 1.2]} rot={[0, -Math.PI / 2, 0.05]} w={0.6} h={0.85} />
      <Poster p={[-20.21, Y + 1.5, 0.2]} rot={[0, -Math.PI / 2, -0.12]} w={0.5} h={0.7} />
      <Pendant p={[-23.4, H_CEIL2, 0.2]} len={0.55} tilt={-0.2} />

      {/* ================= BATHROOM ================= */}
      <Bathtub p={[-22.5, Y, -2.95]} />
      <Toilet p={[-25.8, Y, -2.95]} rot={Math.PI} />
      <B p={[-21.0, Y + 0.8, -5.65]} s={[0.5, 0.12, 0.4]} m={m.paintWhite} />
      <B p={[-21.0, Y + 0.4, -5.65]} s={[0.15, 0.8, 0.15]} m={m.paintWhite} />
      <mesh position={[-21.0, Y + 1.6, -5.92]} material={mirror} receiveShadow>
        <planeGeometry args={[0.5, 0.7]} />
      </mesh>
      <Cyl p={[-20.3, Y + 1.5, -3.6]} r={0.03} h={3.0} m={m.rust} seg={8} />
      <Cyl p={[-26.5, Y + 1.0, -4.0]} r={0.02} h={2.0} m={m.steelLight} seg={8} />

      {/* ================= BED 6 ================= */}
      <BedFrame p={[-23.4, Y, -10.3]} rot={0} />
      <BedFrame p={[-25.5, Y, -7.1]} rot={Math.PI / 2} mattress={false} />
      <Wardrobe p={[-21.0, Y, -6.4]} rot={Math.PI} />
      <ClothPile p={[-22.0, Y, -9.0]} s={0.7} />
      <Pendant p={[-23.4, H_CEIL2, -8.5]} len={0.5} />
      <Poster p={[-26.515, Y + 1.6, -10.0]} rot={[0, Math.PI / 2, 0.06]} w={0.55} h={0.75} />
    </group>
  )
}

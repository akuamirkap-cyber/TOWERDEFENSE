import * as THREE from 'three'
import { useMemo } from 'react'
import { HOUSE, H_ROOF, ROOF, ROOF_STAIR, F2 } from './layout'
import { useMaterials } from './materials'
import { GeoBuilder, Merged } from './Architecture'

const RISERS = 21

/** level 3: steel access stair on the west facade + rooftop terrace dressing */
export function Rooftop() {
  const m = useMaterials()
  const mats = useMemo(() => {
    const galv = m.steel.clone()
    galv.color.set('#8b9096')
    galv.metalness = 0.82
    galv.roughness = 0.38
    const grate = m.steelDark.clone()
    grate.color.set('#4a4e52')
    const paint = new THREE.MeshStandardMaterial({ color: '#c8c2b4', roughness: 0.7 })
    const sand = new THREE.MeshStandardMaterial({ color: '#8a7a5c', roughness: 1, map: m.tex.ground.map, normalMap: m.tex.ground.normal })
    const woodCrate = m.woodDark.clone()
    woodCrate.color.set('#7b6040')
    return { galv, grate, paint, sand, woodCrate }
  }, [m])

  const geos = useMemo(() => {
    const steel = new GeoBuilder()
    const grate = new GeoBuilder()
    const rail = new GeoBuilder()
    const sand = new GeoBuilder()
    const crates = new GeoBuilder()

    const flight = (x: number, z0: number, z1: number, y0: number, y1: number, width: number) => {
      const n = RISERS
      const dz = (z1 - z0) / n
      const dy = (y1 - y0) / n
      for (let i = 0; i < n; i++) {
        const z = z0 + dz * (i + 0.5)
        const y = y0 + dy * (i + 1)
        grate.box(x, y - 0.03, z, width, 0.05, Math.abs(dz) + 0.02)
        // riser
        grate.box(x, y - dy / 2, z + dz / 2, width, dy, 0.02)
      }
      // stringers
      const len = Math.hypot(z1 - z0, y1 - y0)
      const tilt = Math.atan2(y1 - y0, z1 - z0)
      for (const sx of [-1, 1]) steel.box(x + sx * (width / 2 + 0.04), (y0 + y1) / 2 - 0.12, (z0 + z1) / 2, 0.06, 0.26, len, 0, tilt)
      // handrails
      for (const sx of [-1, 1]) {
        rail.box(x + sx * (width / 2 - 0.02), (y0 + y1) / 2 + 1.0, (z0 + z1) / 2, 0.045, 0.045, len, 0, tilt)
        rail.box(x + sx * (width / 2 - 0.02), (y0 + y1) / 2 + 0.55, (z0 + z1) / 2, 0.03, 0.03, len, 0, tilt)
        for (let i = 0; i <= 6; i++) {
          const t = i / 6
          const zz = z0 + (z1 - z0) * t
          const yy = y0 + (y1 - y0) * t
          rail.box(x + sx * (width / 2 - 0.02), yy + 0.5, zz, 0.035, 1.0, 0.035)
        }
      }
    }
    const x = (ROOF_STAIR.x0 + ROOF_STAIR.x1) / 2
    const w = ROOF_STAIR.x1 - ROOF_STAIR.x0
    // lower flight up (south -> north), landing, upper flight
    flight(x, ROOF_STAIR.zBottom + 0.35, ROOF_STAIR.zMid, 0, ROOF_STAIR.hMid, w)
    flight(x, ROOF_STAIR.zMid2, ROOF_STAIR.zTop, ROOF_STAIR.hMid, H_ROOF, w)
    // support posts
    for (const zz of [2.4, 0.2, -1.6, -2.7, -4.7, -6.7]) {
      for (const sx of [-1, 1]) steel.box(x + sx * (w / 2 + 0.04), Math.min(3.65, (zz < -2.5 ? 6 : 2)) / 1, zz, 0.07, zz < -2.5 ? H_ROOF : ROOF_STAIR.hMid, 0.07)
    }
    // mid landing
    grate.box(x, ROOF_STAIR.hMid - 0.05, (ROOF_STAIR.zMid + ROOF_STAIR.zMid2) / 2, w + 0.5, 0.1, Math.abs(ROOF_STAIR.zMid2 - ROOF_STAIR.zMid) + 0.3)
    steel.box(x, ROOF_STAIR.hMid - 0.16, (ROOF_STAIR.zMid + ROOF_STAIR.zMid2) / 2, w, 0.2, 0.25)
    // top landing spanning from the stair to the roof edge
    grate.box(-43.45, H_ROOF - 0.05, -7.3, 3.2, 0.1, 1.15)
    for (let i = 0; i < 6; i++) rail.box(-43.45, H_ROOF + 0.55, -7.88 + 0, 3.2, 0.03, 0.03)
    // top landing rails
    rail.box(-44.95, H_ROOF + 1.05, -7.3, 0.05, 0.05, 1.2)
    rail.box(-41.9, H_ROOF + 1.05, -7.3, 0.05, 0.05, 1.2)
    for (const rx of [-44.95, -41.9]) {
      for (const zz of [-7.85, -7.3, -6.75]) rail.box(rx, H_ROOF + 0.55, zz, 0.035, 1.05, 0.035)
    }
    // warning paint on the stair stringers
    steel.box(x, 0.55, ROOF_STAIR.zBottom + 0.5, 0.3, 0.1, 0.5)

    // rooftop terrace: railing around the perimeter
    const railLine = (x0: number, z0: number, x1: number, z1: number) => {
      const len = Math.hypot(x1 - x0, z1 - z0)
      const cx = (x0 + x1) / 2
      const cz = (z0 + z1) / 2
      const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0)
      const ry = alongX ? 0 : Math.PI / 2
      rail.box(cx, H_ROOF + 1.05, cz, len, 0.05, 0.05, ry)
      rail.box(cx, H_ROOF + 0.6, cz, len, 0.03, 0.03, ry)
      const n = Math.max(2, Math.round(len / 1.5))
      for (let i = 0; i <= n; i++) {
        const t = i / n
        rail.box(x0 + (x1 - x0) * t, H_ROOF + 0.55, z0 + (z1 - z0) * t, 0.04, 1.05, 0.04)
      }
    }
    railLine(ROOF.xMin + 0.1, ROOF.zMax - 0.1, ROOF.xMax - 0.1, ROOF.zMax - 0.1)
    railLine(ROOF.xMin + 0.1, ROOF.zMin + 0.1, ROOF.xMax - 0.1, ROOF.zMin + 0.1)
    railLine(ROOF.xMax - 0.1, ROOF.zMin + 0.1, ROOF.xMax - 0.1, ROOF.zMax - 0.1)
    railLine(ROOF.xMin + 0.1, ROOF.zMax - 0.1, ROOF.xMin + 0.1, -7.95)
    railLine(ROOF.xMin + 0.1, -6.65, ROOF.xMin + 0.1, ROOF.zMin + 0.1)
    // roof access sign / hazard stripes on the landing
    for (let i = 0; i < 6; i++) rail.box(-43.6 + i * 0.42, H_ROOF + 0.02, -6.68, 0.2, 0.02, 0.55, 0, 0, 0.6)
    // sandbag overwatch nest at the SE corner of the roof
    const nx = -22.6
    const nz = 1.0
    for (let row = 0; row < 6; row++) {
      for (let i = 0; i < 8; i++) {
        const t = i / 7 - 0.5
        sand.box(nx + t * 2.6, H_ROOF + 0.12 + row * 0.2, nz + 0.06 * Math.sin(i + row), 0.34, 0.2, 0.5, t * 0.6)
      }
      for (let i = 0; i < 4; i++) sand.box(nx - 1.5, H_ROOF + 0.12 + row * 0.2, nz - 0.2 - i * 0.48, 0.5, 0.2, 0.34)
    }
    // crates & a broken chair-ish stack
    crates.box(-26.6, H_ROOF + 0.4, -9.6, 1.1, 0.8, 0.8, 0.2)
    crates.box(-26.5, H_ROOF + 1.05, -9.55, 0.85, 0.5, 0.7, 0.5)
    crates.box(-24.9, H_ROOF + 0.32, -9.2, 0.9, 0.64, 0.7, -0.3)
    crates.box(-33.4, H_ROOF + 0.3, -9.7, 1.0, 0.6, 0.8, 0.1)
    // a couple of uprights supporting a defunct radio antenna
    steel.box(-30.2, H_ROOF + 1.6, 1.3, 0.06, 3.2, 0.06)
    for (let i = 0; i < 4; i++) steel.box(-30.2, H_ROOF + 2.0 + i * 0.4, 1.3, 1.4 - i * 0.25, 0.03, 0.03)
    // roof edge gravel strips
    for (let i = 0; i < 24; i++) sand.box(ROOF.xMin + 0.7 + i * 1.0, H_ROOF + 0.015, ROOF.zMax - 0.5, 0.8, 0.03, 0.5)
    // fixed ladder rungs on the parapet (visual detail)
    for (let i = 0; i < 5; i++) steel.box(-34.5, H_ROOF + 0.15 + i * 0.18, HOUSE.zMax + 0.1, 0.5, 0.03, 0.03)

    return { steel: steel.geometry(), grate: grate.geometry(), rail: rail.geometry(), sand: sand.geometry(), crates: crates.geometry() }
  }, [])

  return (
    <group>
      <Merged geo={geos.steel} mat={mats.galv} />
      <Merged geo={geos.grate} mat={mats.grate} />
      <Merged geo={geos.rail} mat={mats.galv} />
      <Merged geo={geos.sand} mat={mats.sand} />
      <Merged geo={geos.crates} mat={mats.woodCrate} />
      {/* access notice board + lamp */}
      <mesh position={[HOUSE.xMin - 0.35, 2.3, 1.7]} rotation={[0, -Math.PI / 2, 0]} material={mats.paint}>
        <boxGeometry args={[0.9, 0.5, 0.04]} />
      </mesh>
      <mesh position={[HOUSE.xMin - 0.3, F2 + 2.5, -7.3]} material={m.metalDark}>
        <boxGeometry args={[0.25, 0.1, 0.25]} />
      </mesh>
    </group>
  )
}

import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials } from './materials'
import { WALLS, MEZZ_Y, COLUMNS, H_CEIL1 } from './layout'

type Facing = 'n' | 's' | 'e' | 'w'
const ROT: Record<Facing, number> = { s: 0, n: Math.PI, e: Math.PI / 2, w: -Math.PI / 2 }

// crops in the tag sheet (u0, v0, u1, v1) with v measured from the bottom
const TAGS: Record<string, [number, number, number, number, number]> = {
  // name: u0, v0, u1, v1, aspect(w/h)
  skr: [0.02, 0.76, 0.34, 0.98, 1.6],
  anarchy: [0.38, 0.72, 0.57, 0.98, 0.9],
  rats: [0.68, 0.78, 0.99, 0.97, 1.8],
  crown: [0.55, 0.7, 0.67, 0.86, 0.8],
  dsk: [0.02, 0.49, 0.28, 0.7, 1.4],
  smiley: [0.25, 0.57, 0.38, 0.75, 0.8],
  thirteen: [0.64, 0.49, 0.79, 0.7, 0.8],
  star: [0.82, 0.57, 0.96, 0.78, 0.8],
  bz: [0.78, 0.4, 0.99, 0.57, 1.4],
  trz: [0.02, 0.2, 0.28, 0.42, 1.4],
  vex: [0.38, 0.19, 0.64, 0.43, 1.3],
  ko: [0.64, 0.21, 0.79, 0.4, 0.9],
  arrow: [0.8, 0.22, 0.99, 0.38, 1.6],
  nine4: [0.45, 0.02, 0.62, 0.2, 1.1],
  hex: [0.72, 0.02, 0.93, 0.2, 1.5],
  sad: [0.27, 0.35, 0.38, 0.5, 0.9],
  scribble: [0.38, 0.5, 0.57, 0.68, 1.3],
}

interface GraffitiDef {
  tag: string | 'HARD'
  x: number
  y: number
  z: number
  f: Facing
  w: number
  color?: string
  rot?: number
}

const Y = MEZZ_Y
const GRAFFITI: GraffitiDef[] = [
  // stairwell – the big piece from the reference
  { tag: 'HARD', x: 14.11, y: 2.3, z: 7.6, f: 'e', w: 3.8 },
  { tag: 'anarchy', x: 19.79, y: 1.9, z: 6.3, f: 'w', w: 0.7, color: '#8a1212' },
  { tag: 'skr', x: 16.5, y: 5.6, z: 11.79, f: 'n', w: 1.4 },
  // hall walls
  { tag: 'rats', x: 5.0, y: 1.8, z: 11.79, f: 'n', w: 1.8, color: '#8a1212' },
  { tag: 'dsk', x: -17.0, y: 1.9, z: 11.79, f: 'n', w: 1.4, color: '#1b2a6b' },
  { tag: 'vex', x: 19.79, y: 1.7, z: 4.0, f: 'w', w: 1.5, color: '#3a3a3a' },
  { tag: 'hex', x: 19.79, y: 2.2, z: -8.0, f: 'w', w: 1.3 },
  { tag: 'HARD', x: -19.79, y: 2.4, z: 8.3, f: 'e', w: 3.2 },
  { tag: 'bz', x: -19.79, y: 1.6, z: -3.5, f: 'e', w: 1.4, color: '#14532d' },
  { tag: 'thirteen', x: -2.4, y: 1.7, z: -11.79, f: 's', w: 0.8, color: '#8a1212' },
  { tag: 'crown', x: 6.0, y: 2.6, z: -11.79, f: 's', w: 0.7, color: '#b8860b' },
  { tag: 'trz', x: 18.3, y: 1.6, z: -11.79, f: 's', w: 1.3 },
  // offices front & mezzanine wall
  { tag: 'ko', x: -13.2, y: 1.6, z: -6.89, f: 's', w: 0.9 },
  { tag: 'arrow', x: -5.5, y: 2.4, z: -6.89, f: 's', w: 1.0, color: '#c0392b' },
  { tag: 'nine4', x: -8.0, y: Y + 1.6, z: -11.79, f: 's', w: 1.0 },
  { tag: 'smiley', x: 10.5, y: Y + 1.9, z: -11.79, f: 's', w: 0.8 },
  { tag: 'star', x: 19.79, y: Y + 1.8, z: -2.0, f: 'w', w: 0.7, color: '#c0392b' },
  // house – hall (the staircase piece from the reference)
  { tag: 'HARD', x: -31.315, y: 1.9, z: -2.6, f: 'e', w: 2.6 },
  { tag: 'rats', x: -26.685, y: 1.7, z: -6.6, f: 'w', w: 1.3, color: '#8a1212' },
  { tag: 'crown', x: -31.315, y: 2.4, z: -9.6, f: 'e', w: 0.6, color: '#b8860b' },
  { tag: 'skr', x: -31.315, y: Y + 1.6, z: -6.5, f: 'e', w: 1.3 },
  { tag: 'thirteen', x: -26.685, y: Y + 1.9, z: -0.2, f: 'w', w: 0.7, color: '#8a1212' },
  { tag: 'arrow', x: -29, y: Y + 1.4, z: -10.84, f: 's', w: 0.9, color: '#c0392b' },
  // house – rooms
  { tag: 'anarchy', x: -31.485, y: 2.0, z: 0.9, f: 'w', w: 0.7, color: '#8a1212' },
  { tag: 'vex', x: -36.615, y: 1.7, z: -1.4, f: 'e', w: 1.2, color: '#3a3a3a' },
  { tag: 'dsk', x: -23.4, y: 1.8, z: 2.84, f: 'n', w: 1.3, color: '#1b2a6b' },
  { tag: 'ko', x: -31.485, y: 1.6, z: -8.0, f: 'w', w: 0.8 },
  { tag: 'bz', x: -23.4, y: 1.5, z: -10.84, f: 's', w: 1.2, color: '#14532d' },
  { tag: 'hex', x: -34, y: Y + 1.8, z: 2.84, f: 'n', w: 1.1 },
  { tag: 'vex', x: -23.4, y: Y + 1.7, z: -2.415, f: 's', w: 1.3, color: '#1b2a6b' },
  { tag: 'smiley', x: -36.615, y: Y + 1.9, z: -8.0, f: 'e', w: 0.6 },
  { tag: 'star', x: -20.21, y: Y + 2.0, z: -8.0, f: 'w', w: 0.7, color: '#c0392b' },
  { tag: 'scribble', x: -41.835, y: 1.5, z: -9.0, f: 'e', w: 0.9 },
  // columns
  { tag: 'sad', x: COLUMNS[6][0] - 0.23, y: 1.7, z: COLUMNS[6][1], f: 'w', w: 0.36 },
  { tag: 'scribble', x: COLUMNS[1][0] + 0.23, y: 1.5, z: COLUMNS[1][1], f: 'e', w: 0.38 },
  { tag: 'ko', x: COLUMNS[4][0], y: 1.6, z: COLUMNS[4][1] + 0.23, f: 's', w: 0.36, color: '#1b2a6b' },
]

function Graffiti() {
  const m = useMaterials()
  const items = useMemo(() => {
    return GRAFFITI.map((g, i) => {
      let tex: THREE.Texture
      let aspect: number
      if (g.tag === 'HARD') {
        tex = m.tex.graffitiBubble
        const img = tex.image as { width?: number; height?: number }
        aspect = img && img.width && img.height ? img.width / img.height : 16 / 9
      } else {
        const c = TAGS[g.tag]
        tex = m.tex.graffitiTags.clone()
        tex.offset.set(c[0], c[1])
        tex.repeat.set(c[2] - c[0], c[3] - c[1])
        tex.needsUpdate = true
        const img = m.tex.graffitiTags.image as { width?: number; height?: number }
        const imgAspect = img && img.width && img.height ? img.width / img.height : 1.5
        aspect = ((c[2] - c[0]) / (c[3] - c[1])) * imgAspect
      }
      const mat = new THREE.MeshStandardMaterial({
        map: tex,
        color: g.color ?? '#ffffff',
        transparent: true,
        roughness: 0.85,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3,
        alphaTest: 0.03,
        opacity: g.tag === 'HARD' ? 0.95 : 0.9,
      })
      return { key: i, mat, w: g.w, h: g.w / aspect, pos: [g.x, g.y, g.z] as [number, number, number], rot: ROT[g.f], tilt: g.rot ?? (i % 3 - 1) * 0.04 }
    })
  }, [m])
  return (
    <group>
      {items.map((it) => (
        <mesh key={it.key} position={it.pos} rotation={[0, it.rot, it.tilt]} material={it.mat} receiveShadow renderOrder={2}>
          <planeGeometry args={[it.w, it.h]} />
        </mesh>
      ))}
    </group>
  )
}

// ---------------------------------------------------------------------------
interface StainDef {
  x: number
  y: number
  z: number
  f: Facing | 'up' | 'down'
  w: number
  h: number
  color: string
  opacity: number
  kind: 'stain' | 'streak'
}

function Stains() {
  const m = useMaterials()
  const defs = useMemo(() => {
    const list: StainDef[] = []
    // light water streaks under the high windows (inside face)
    for (const w of WALLS) {
      if (!w.exterior) continue
      for (const o of w.openings) {
        if (o.kind !== 'window') continue
        const cy = w.y + o.b - 0.9
        if (w.axis === 'x') {
          const inside = w.z > 0 ? -1 : 1
          list.push({ x: w.x + o.at, y: cy, z: w.z + inside * (w.t / 2 + 0.012), f: inside > 0 ? 's' : 'n', w: o.w + 0.4, h: 1.8, color: '#4a4238', opacity: 0.32, kind: 'streak' })
        } else {
          const inside = w.x > 0 ? -1 : 1
          list.push({ x: w.x + inside * (w.t / 2 + 0.012), y: cy, z: w.z + o.at, f: inside > 0 ? 'e' : 'w', w: o.w + 0.4, h: 1.8, color: '#4a4238', opacity: 0.32, kind: 'streak' })
        }
      }
    }
    const floor = (x: number, z: number, y: number, s: number, color = '#2a2622', op = 0.5) =>
      list.push({ x, y: y + 0.006, z, f: 'up', w: s, h: s * 0.85, color, opacity: op, kind: 'stain' })
    floor(-11, -2.5, 0, 3.0, '#1d1a17', 0.55) // oil under the forklift
    floor(4, 0.5, 0, 2.2, '#2a2622', 0.4)
    floor(-6, 5.5, 0, 2.0, '#2a2622', 0.35)
    floor(13, -4, 0, 1.6, '#2a2622', 0.4)
    floor(-14, 8.5, 0, 2.4, '#3a2f22', 0.3)
    floor(17, 8.5, 0, 1.8, '#2a2622', 0.4)
    floor(10, -8.0, 0, 2.0, '#1d1a17', 0.45)
    floor(0, -9.5, Y, 1.8, '#2a2622', 0.35)
    floor(-34, -7.2, Y, 2.6, '#2a2622', 0.45)
    floor(-32.6, -1.3, 0, 1.6, '#2a2622', 0.3)
    floor(-23.4, -4.2, Y, 1.4, '#1c2a2e', 0.5)
    list.push({ x: -29, y: H_CEIL1 - 0.012, z: -1, f: 'down', w: 2.2, h: 1.8, color: '#4a3a22', opacity: 0.55, kind: 'stain' })
    list.push({ x: -23.4, y: H_CEIL1 - 0.012, z: -4.2, f: 'down', w: 1.8, h: 1.5, color: '#4a3a22', opacity: 0.5, kind: 'stain' })
    const base = (x: number, z: number, y: number, f: Facing, w: number) =>
      list.push({ x, y: y + 0.4, z, f, w, h: 0.9, color: '#3a342c', opacity: 0.3, kind: 'stain' })
    base(-8, 11.79, 0, 'n', 3)
    base(19.79, -7.5, 0, 'w', 3)
    base(-19.79, -9, 0, 'e', 3)
    base(10, -11.79, 0, 's', 4)
    base(14.11, 9.5, 0, 'e', 2.5)
    return list
  }, [])

  const mats = useMemo(() => {
    const cache = new Map<string, THREE.MeshStandardMaterial>()
    return (d: StainDef) => {
      const key = `${d.kind}-${d.color}-${d.opacity}`
      let mat = cache.get(key)
      if (!mat) {
        mat = new THREE.MeshStandardMaterial({
          map: d.kind === 'stain' ? m.tex.stain : m.tex.streak,
          color: d.color,
          transparent: true,
          opacity: d.opacity,
          roughness: 1,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -2,
          polygonOffsetUnits: -2,
        })
        cache.set(key, mat)
      }
      return mat
    }
  }, [m])

  return (
    <group>
      {defs.map((d, i) => {
        let rot: [number, number, number]
        if (d.f === 'up') rot = [-Math.PI / 2, 0, (i % 5) * 0.6]
        else if (d.f === 'down') rot = [Math.PI / 2, 0, (i % 5) * 0.6]
        else rot = [0, ROT[d.f], 0]
        return (
          <mesh key={i} position={[d.x, d.y, d.z]} rotation={rot} material={mats(d)} receiveShadow renderOrder={1}>
            <planeGeometry args={[d.w, d.h]} />
          </mesh>
        )
      })}
    </group>
  )
}

export function Decals() {
  return (
    <group>
      <Stains />
      <Graffiti />
    </group>
  )
}

import * as THREE from 'three'
import { useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { MEZZ_Y } from './layout'
import { useMaterials } from './materials'

// steel silhouette "popper" targets that fall when hit and reset after a few seconds
interface TargetDef {
  x: number
  y: number
  z: number
  r: number
}
const DEFS: TargetDef[] = [
  { x: -12, y: 0, z: 34.5, r: Math.PI },
  { x: 6, y: 0, z: 37.5, r: Math.PI + 0.3 },
  { x: -40, y: 0, z: 21, r: 2.6 },
  { x: 28.5, y: 0, z: 9, r: -2.2 },
  { x: 31, y: 0, z: -25, r: -0.6 },
  { x: -54, y: 0, z: -14, r: 1.3 },
  { x: 2, y: 0, z: 2.5, r: 0.4 },
  { x: -15, y: 0, z: 9, r: 2.4 },
  { x: 9, y: MEZZ_Y, z: -10.6, r: 0.2 },
  { x: 18.8, y: MEZZ_Y, z: -1.5, r: -1.57 },
  { x: -29.5, y: 0, z: -9.6, r: 0 },
  { x: -39.5, y: 4.0, z: 1.5, r: 2.4 },
]

interface TState {
  def: TargetDef
  plate: THREE.Group | null
  down: boolean
  angle: number
  timer: number
}
const STATES: TState[] = DEFS.map((def) => ({ def, plate: null, down: false, angle: 0, timer: 0 }))

/** returns true if the object belongs to a standing target (and knocks it down) */
export function hitTarget(obj: THREE.Object3D): boolean {
  let o: THREE.Object3D | null = obj
  while (o) {
    if (o.userData.targetIndex !== undefined) {
      const s = STATES[o.userData.targetIndex as number]
      if (s.down) return false
      s.down = true
      s.timer = 3.5
      return true
    }
    o = o.parent
  }
  return false
}

export function Targets() {
  const m = useMaterials()
  const mats = useMemo(() => {
    const plate = new THREE.MeshStandardMaterial({ color: '#d9d4c7', roughness: 0.55, metalness: 0.4 })
    const ring = new THREE.MeshStandardMaterial({ color: '#b3261e', roughness: 0.6, metalness: 0.2 })
    return { plate, ring }
  }, [])
  const geos = useMemo(() => {
    const s = new THREE.Shape()
    // IPSC-like silhouette
    ;[[-0.23, 0], [0.23, 0], [0.23, 0.42], [0.15, 0.55], [0.08, 0.55], [0.08, 0.6], [0.09, 0.78], [-0.09, 0.78], [-0.08, 0.6], [-0.08, 0.55], [-0.15, 0.55], [-0.23, 0.42]].forEach(([x, y], i) =>
      i ? s.lineTo(x, y) : s.moveTo(x, y),
    )
    s.closePath()
    const body = new THREE.ExtrudeGeometry(s, { depth: 0.012, bevelEnabled: false })
    body.translate(0, 0, -0.006)
    return { body }
  }, [])

  useFrame((_, rawDt) => {
    const dt = Math.min(0.05, rawDt)
    for (const s of STATES) {
      if (!s.plate) continue
      if (s.down) {
        s.timer -= dt
        if (s.timer <= 0) s.down = false
      }
      const target = s.down ? -Math.PI / 2 + 0.08 : 0
      const speed = s.down ? 16 : 5
      s.angle += (target - s.angle) * (1 - Math.exp(-dt * speed))
      s.plate.rotation.x = s.angle
    }
  })

  return (
    <group>
      {STATES.map((s, i) => (
        <group key={i} position={[s.def.x, s.def.y, s.def.z]} rotation={[0, s.def.r, 0]}>
          {/* stand */}
          <mesh position={[0, 0.03, 0]} material={m.steelDark} castShadow receiveShadow>
            <boxGeometry args={[0.7, 0.06, 0.5]} />
          </mesh>
          <mesh position={[0, 0.36, -0.05]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.06, 0.66, 0.06]} />
          </mesh>
          <group
            position={[0, 0.66, -0.05]}
            ref={(g) => {
              s.plate = g
            }}
          >
            <group userData={{ targetIndex: i }}>
              <mesh geometry={geos.body} material={mats.plate} position={[0, 0.0, 0.04]} castShadow receiveShadow />
              <mesh position={[0, 0.3, 0.05]} material={mats.ring}>
                <boxGeometry args={[0.16, 0.2, 0.004]} />
              </mesh>
              <mesh position={[0, 0.69, 0.05]} material={mats.ring}>
                <boxGeometry args={[0.08, 0.08, 0.004]} />
              </mesh>
            </group>
          </group>
        </group>
      ))}
    </group>
  )
}

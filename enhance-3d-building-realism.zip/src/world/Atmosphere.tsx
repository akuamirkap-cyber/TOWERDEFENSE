import * as THREE from 'three'
import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { MeshReflectorMaterial } from '@react-three/drei'
import { useMaterials } from './materials'
import { GeoBuilder, Merged } from './Architecture'
import { HZ, HOUSE } from './layout'

function puddleShape(rx: number, rz: number, seed = 3) {
  const s = new THREE.Shape()
  let a = seed
  const rnd = () => {
    a = (a * 16807) % 2147483647
    return a / 2147483647
  }
  const n = 22
  for (let i = 0; i < n; i++) {
    const t = (i / n) * Math.PI * 2
    const r = 0.78 + rnd() * 0.32
    const x = Math.cos(t) * rx * r
    const y = Math.sin(t) * rz * r
    if (i === 0) s.moveTo(x, y)
    else s.lineTo(x, y)
  }
  s.closePath()
  return new THREE.ShapeGeometry(s)
}

/** reflective wet patches + practical emergency lights */
export function Atmosphere() {
  const m = useMaterials()
  const geos = useMemo(
    () => ({
      mirror: puddleShape(1.55, 1.05, 7),
      wet: [puddleShape(1.1, 0.7, 11), puddleShape(0.9, 0.55, 23), puddleShape(1.4, 0.8, 31), puddleShape(0.8, 0.5, 47)],
    }),
    [],
  )
  const wetMat = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: '#1b2226',
        roughness: 0.04,
        metalness: 0.15,
        clearcoat: 1,
        clearcoatRoughness: 0.02,
        envMapIntensity: 2.2,
        transparent: true,
        opacity: 0.88,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      }),
    [],
  )
  const lampMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#fff3dd', emissive: new THREE.Color('#ffdfa8'), emissiveIntensity: 1.4 }), [])
  const redMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#4a0d0a', emissive: new THREE.Color('#ff2a14'), emissiveIntensity: 1.1 }), [])
  const boxes = useMemo(() => {
    const b = new GeoBuilder()
    // emergency exit signs / wall lamps
    b.box(12.4, 2.85, -7.05, 0.5, 0.22, 0.04)
    b.box(12.4, 1.1, -7.05, 0.34, 0.34, 0.16)
    b.box(-19.6, 2.9, 2.0, 0.5, 0.22, 0.04)
    b.box(-19.6, 1.1, 2.0, 0.34, 0.34, 0.16)
    b.box(-27.9, 2.9, -10.7, 0.5, 0.22, 0.04)
    b.box(-27.9, 1.1, -10.7, 0.34, 0.34, 0.16)
    return b.geometry()
  }, [])
  const glows = useMemo(() => {
    const b = new GeoBuilder()
    b.box(12.4, 2.85, -7.02, 0.36, 0.1, 0.02)
    b.box(12.4, 1.1, -6.95, 0.2, 0.2, 0.02)
    b.box(-19.56, 2.9, 2.0, 0.36, 0.1, 0.02)
    b.box(-19.54, 1.1, 2.0, 0.2, 0.2, 0.02)
    b.box(-27.9, 2.9, -10.66, 0.36, 0.1, 0.02)
    return b.geometry()
  }, [])
  const flick = useRef<THREE.PointLight>(null)
  useFrame((state) => {
    if (!flick.current) return
    const t = state.clock.elapsedTime
    const n = Math.sin(t * 13.1) * Math.sin(t * 3.7) + Math.sin(t * 31.0) * 0.4
    flick.current.intensity = n > 0.55 ? 0 : 2.4
  })
  return (
    <group>
      {/* large mirror puddle in the hall — planar reflection of the roof lights/windows */}
      <mesh geometry={geos.mirror} rotation={[-Math.PI / 2, 0, 0.4]} position={[-7.8, 0.014, 6.2]}>
        <MeshReflectorMaterial
          resolution={128}
          mirror={0.62}
          blur={[180, 70]}
          mixBlur={1.4}
          mixStrength={2.6}
          roughness={0.42}
          depthScale={0.6}
          minDepthThreshold={0.3}
          maxDepthThreshold={1.3}
          color="#121719"
          metalness={0.5}
        />
      </mesh>
      {[
        [5.4, 0.016, -2.1, -0.6],
        [-13.4, 0.016, -3.2, 1.1],
        [-24.6, 0.016, 8.2, 0.2],
        [-30.2, 0.012, -6.4, 2.0],
      ].map(([x, y, z, r], i) => (
        <mesh key={i} geometry={geos.wet[i]} material={wetMat} rotation={[-Math.PI / 2, 0, r]} position={[x, y, z]} receiveShadow />
      ))}
      <Merged geo={boxes} mat={m.steelDark} cast={false} />
      <Merged geo={glows} mat={lampMat} cast={false} />
      <pointLight ref={flick} position={[12.4, 1.15, -6.5]} color="#ffd9a0" intensity={2.4} distance={7} decay={2} />
      <pointLight position={[-19.2, 1.15, 2.4]} color="#ffd9a0" intensity={1.8} distance={6} decay={2} />
      <mesh position={[12.4, 2.85, -7.06]} material={redMat}>
        <boxGeometry args={[0.4, 0.13, 0.01]} />
      </mesh>
      <mesh position={[HOUSE.xMin - 0.16, 3.0, 3.2]} rotation={[0, -Math.PI / 2, 0]} material={redMat}>
        <boxGeometry args={[0.4, 0.13, 0.01]} />
      </mesh>
      <mesh position={[3, HZ + 0.6, 0]} visible={false}>
        <boxGeometry args={[0.01, 0.01, 0.01]} />
      </mesh>
    </group>
  )
}

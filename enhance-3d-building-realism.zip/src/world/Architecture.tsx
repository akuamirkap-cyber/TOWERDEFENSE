import * as THREE from 'three'
import { useMemo } from 'react'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { WALLS, HX, HZ, EAVE, RIDGE, SLOPE, HOUSE, H_ROOF, H_CEIL2, ROOF_PANELS, roofY, boxCollider, type WallDef, type AABB } from './layout'
import { useMaterials } from './materials'

// ---------------------------------------------------------------------------
// Geometry builders: merged boxes with world-space (metre) UVs -> one draw call per material
export class GeoBuilder {
  pos: number[] = []
  nor: number[] = []
  uv: number[] = []
  idx: number[] = []
  private q = new THREE.Quaternion()
  private e = new THREE.Euler(0, 0, 0, 'YXZ')
  private v = new THREE.Vector3()
  private n = new THREE.Vector3()
  box(cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, ry = 0, rx = 0, rz = 0) {
    this.e.set(rx, ry, rz)
    this.q.setFromEuler(this.e)
    const hx = sx / 2, hy = sy / 2, hz = sz / 2
    const F: [number[], number[], number[], number, number, number][] = [
      [[1, 0, 0], [0, 0, -1], [0, 1, 0], sz, sy, hx],
      [[-1, 0, 0], [0, 0, 1], [0, 1, 0], sz, sy, hx],
      [[0, 1, 0], [1, 0, 0], [0, 0, -1], sx, sz, hy],
      [[0, -1, 0], [1, 0, 0], [0, 0, 1], sx, sz, hy],
      [[0, 0, 1], [1, 0, 0], [0, 1, 0], sx, sy, hz],
      [[0, 0, -1], [-1, 0, 0], [0, 1, 0], sx, sy, hz],
    ]
    const offU = (cx + cz) * 0.37
    const offV = cy - hy
    for (const [n, u, v, us, vs, d] of F) {
      const base = this.pos.length / 3
      this.n.set(n[0], n[1], n[2]).applyQuaternion(this.q)
      for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
        this.v
          .set(n[0] * d + u[0] * a * us * 0.5 + v[0] * b * vs * 0.5, n[1] * d + u[1] * a * us * 0.5 + v[1] * b * vs * 0.5, n[2] * d + u[2] * a * us * 0.5 + v[2] * b * vs * 0.5)
          .applyQuaternion(this.q)
        this.pos.push(this.v.x + cx, this.v.y + cy, this.v.z + cz)
        this.nor.push(this.n.x, this.n.y, this.n.z)
        this.uv.push(((a + 1) / 2) * us + offU, ((b + 1) / 2) * vs + offV)
      }
      this.idx.push(base, base + 1, base + 2, base, base + 2, base + 3)
    }
    return this
  }
  geometry() {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3))
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3))
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2))
    g.setIndex(this.idx)
    g.computeBoundingSphere()
    g.computeBoundingBox()
    return g
  }
}

export class CylBuilder {
  list: THREE.BufferGeometry[] = []
  cyl(x: number, y: number, z: number, r: number, h: number, seg = 12, rx = 0, rz = 0, r2?: number, ry = 0) {
    const g = new THREE.CylinderGeometry(r2 ?? r, r, h, seg)
    if (rx) g.rotateX(rx)
    if (rz) g.rotateZ(rz)
    if (ry) g.rotateY(ry)
    g.translate(x, y, z)
    this.list.push(g)
    return this
  }
  add(g: THREE.BufferGeometry) {
    this.list.push(g)
    return this
  }
  geometry() {
    const g = this.list.length ? mergeGeometries(this.list.map((x) => (x.index ? x.toNonIndexed() : x)), false) : new THREE.BufferGeometry()
    g.computeBoundingSphere()
    return g
  }
}

export function Merged({ geo, mat, cast = true }: { geo: THREE.BufferGeometry; mat: THREE.Material; cast?: boolean }) {
  return <mesh geometry={geo} material={mat} castShadow={cast} receiveShadow />
}

// ---------------------------------------------------------------------------
// wall helpers
const isHouse = (w: WallDef) => w.style === 'house'
const outDir = (w: WallDef) =>
  isHouse(w) ? (w.axis === 'x' ? (w.z > -4 ? 1 : -1) : w.x > -31 ? 1 : -1) : w.axis === 'x' ? Math.sign(w.z) : Math.sign(w.x)
const topOf = (o: WallDef['openings'][number]) => (o.kind === 'rollup' ? o.t + 0.1 : o.t)
const CORNERS: [number, number][] = [
  [-HX, -HZ], [HX, -HZ], [HX, HZ], [-HX, HZ], [HOUSE.xMin, HOUSE.zMax], [HOUSE.xMin, HOUSE.zMin],
]
function endIsCorner(w: WallDef, u: number) {
  const x = w.axis === 'x' ? w.x + u : w.x
  const z = w.axis === 'x' ? w.z : w.z + u
  return CORNERS.some(([cx, cz]) => Math.abs(cx - x) < 0.35 && Math.abs(cz - z) < 0.35)
}
/** box on the outer face of a wall between u0..u1 (absolute y) */
function faceBox(b: GeoBuilder, w: WallDef, u0: number, u1: number, y0: number, y1: number, depth: number, gap = 0) {
  const out = outDir(w)
  const off = w.t / 2 + gap + depth / 2
  const uc = (u0 + u1) / 2
  const L = u1 - u0
  if (w.axis === 'x') b.box(w.x + uc, (y0 + y1) / 2, w.z + out * off, L, y1 - y0, depth)
  else b.box(w.x + out * off, (y0 + y1) / 2, w.z + uc, depth, y1 - y0, L)
}
function facePoint(w: WallDef, u: number, off: number): [number, number] {
  const out = outDir(w)
  return w.axis === 'x' ? [w.x + u, w.z + out * (w.t / 2 + off)] : [w.x + out * (w.t / 2 + off), w.z + u]
}
/** horizontal band around exterior walls, interrupted by openings */
function band(b: GeoBuilder, y0: number, y1: number, depth: number, filter: (w: WallDef) => boolean) {
  for (const w of WALLS) {
    if (!w.exterior || !filter(w)) continue
    if (!(w.y <= y0 + 1e-3 && w.y + w.h > y0 + 1e-3)) continue
    const blocks = w.openings
      .filter((o) => w.y + o.b < y1 && w.y + topOf(o) > y0)
      .map((o) => [o.at - o.w / 2 - 0.04, o.at + o.w / 2 + 0.04] as [number, number])
      .sort((a, c) => a[0] - c[0])
    let cur = w.u0
    const segs: [number, number][] = []
    for (const [a, c] of blocks) {
      if (a > cur) segs.push([cur, a])
      cur = Math.max(cur, c)
    }
    if (cur < w.u0 + w.len) segs.push([cur, w.u0 + w.len])
    const ext = w.t / 2 + depth
    for (let [s0, s1] of segs) {
      if (w.axis === 'x') {
        if (Math.abs(s0 - w.u0) < 1e-3 && endIsCorner(w, w.u0)) s0 -= ext
        if (Math.abs(s1 - (w.u0 + w.len)) < 1e-3 && endIsCorner(w, w.u0 + w.len)) s1 += ext
      }
      if (s1 - s0 > 0.04) faceBox(b, w, s0, s1, y0, y1, depth)
    }
  }
}

// ---------------------------------------------------------------------------
// static data shared with the player (colliders)
interface PierDef {
  w: WallDef
  u0: number
  u1: number
}
function computePiers(): PierDef[] {
  const out: PierDef[] = []
  for (const w of WALLS) {
    if (!w.exterior || isHouse(w)) continue
    const end = w.u0 + w.len
    const occ = w.openings.map((o) => [o.at - o.w / 2 - 0.2, o.at + o.w / 2 + 0.2] as [number, number]).sort((a, b) => a[0] - b[0])
    const free: [number, number][] = []
    let cur = w.u0
    for (const [a, b] of occ) {
      if (a > cur) free.push([cur, a])
      cur = Math.max(cur, b)
    }
    if (cur < end) free.push([cur, end])
    const PW = 0.5
    const startCorner = endIsCorner(w, w.u0)
    const endCorner = endIsCorner(w, end)
    if (w.axis === 'x') {
      if (startCorner) out.push({ w, u0: w.u0 - (w.t / 2 + 0.24), u1: w.u0 + 0.45 })
      if (endCorner) out.push({ w, u0: end - 0.45, u1: end + w.t / 2 + 0.24 })
    }
    for (const [a, b] of free) {
      const aa = Math.max(a, w.u0 + 1.1)
      const bb = Math.min(b, end - 1.1)
      const L = bb - aa
      if (L < PW + 0.1) continue
      const n = L < 6 ? 1 : Math.max(2, Math.round(L / 4.5))
      for (let i = 0; i < n; i++) {
        const c = n === 1 ? (aa + bb) / 2 : aa + PW / 2 + (i / (n - 1)) * (L - PW)
        out.push({ w, u0: c - PW / 2, u1: c + PW / 2 })
      }
    }
  }
  return out
}
const PIERS = computePiers()
const PIER_D = 0.24

export const ARCH_COLLIDERS: AABB[] = (() => {
  const out: AABB[] = []
  for (const p of PIERS) {
    const out1 = outDir(p.w)
    const off = p.w.t / 2 + PIER_D / 2
    const uc = (p.u0 + p.u1) / 2
    const L = p.u1 - p.u0
    if (p.w.axis === 'x') out.push(boxCollider(p.w.x + uc, p.w.z + out1 * off, L, PIER_D, 0, EAVE))
    else out.push(boxCollider(p.w.x + out1 * off, p.w.z + uc, PIER_D, L, 0, EAVE))
  }
  // safety bollards by the roll-up doors
  for (const x of [-14.6, -9.4, -4.6, 0.6, 5.4, 10.6]) out.push(boxCollider(x, HZ + 0.75, 0.3, 0.3, 0, 1.1))
  // AC condensers + electrical cabinet along the house
  out.push(boxCollider(-36, HOUSE.zMin - 0.75, 1.0, 0.6, 0, 0.8))
  out.push(boxCollider(-30.5, HOUSE.zMin - 0.75, 1.0, 0.6, 0, 0.8))
  out.push(boxCollider(HX + 0.45, 4.2, 0.5, 1.2, 0, 1.9))
  return out
})()

// ---------------------------------------------------------------------------
export function Architecture() {
  const m = useMaterials()
  const mats = useMemo(() => {
    const concreteTrim = m.concrete.clone()
    concreteTrim.color.set('#c4c0b8')
    const concreteDark = m.concrete.clone()
    concreteDark.color.set('#8e8a83')
    const pier = m.concrete.clone()
    pier.color.set('#b3afa7')
    const yellow = new THREE.MeshStandardMaterial({ color: '#d9a21b', roughness: 0.6, metalness: 0.2 })
    const pipe = new THREE.MeshStandardMaterial({ color: '#5d6166', roughness: 0.5, metalness: 0.7 })
    const roofEdge = m.corrugated.clone()
    roofEdge.side = THREE.FrontSide
    const tar = new THREE.MeshStandardMaterial({ color: '#3b3b3a', roughness: 0.95 })
    const sandbag = new THREE.MeshStandardMaterial({ color: '#8a7b5c', roughness: 1, map: m.tex.ground.map, normalMap: m.tex.ground.normal })
    const lampGlow = new THREE.MeshStandardMaterial({ color: '#fff4dc', emissive: new THREE.Color('#ffe9c2'), emissiveIntensity: 1.6 })
    return { concreteTrim, concreteDark, pier, yellow, pipe, roofEdge, tar, sandbag, lampGlow }
  }, [m])

  const geos = useMemo(() => {
    const trim = new GeoBuilder()
    const dark = new GeoBuilder()
    const pier = new GeoBuilder()
    const steel = new GeoBuilder()
    const roof = new GeoBuilder()
    const bars = new GeoBuilder()
    const yellow = new GeoBuilder()
    const tar = new GeoBuilder()
    const sand = new GeoBuilder()
    const glow = new GeoBuilder()
    const pipes = new CylBuilder()
    const metal = new CylBuilder()
    const yel = new CylBuilder()

    const hall = (w: WallDef) => !isHouse(w)
    const house = (w: WallDef) => isHouse(w)

    // ---------------- hall facades ----------------
    band(dark, 0, 0.75, 0.07, hall) // plinth
    band(trim, 4.58, 4.9, 0.1, hall) // mid ring beam
    band(trim, 8.62, EAVE + 0.06, 0.14, hall) // top ring beam / coping
    for (const p of PIERS) faceBox(pier, p.w, p.u0, p.u1, 0, EAVE + 0.06, PIER_D)
    // pier caps & bases
    for (const p of PIERS) {
      faceBox(trim, p.w, p.u0 - 0.04, p.u1 + 0.04, 0, 0.35, PIER_D + 0.05)
    }

    // ---------------- windows / doors (exterior) ----------------
    for (const w of WALLS) {
      if (!w.exterior) continue
      const H = isHouse(w)
      for (const o of w.openings) {
        const y0 = w.y + o.b
        const y1 = w.y + o.t
        if (o.kind === 'window') {
          // sill
          faceBox(trim, w, o.at - o.w / 2 - 0.08, o.at + o.w / 2 + 0.08, y0 - 0.07, y0 + 0.01, H ? 0.14 : 0.18)
          // lintel
          faceBox(trim, w, o.at - o.w / 2 - 0.15, o.at + o.w / 2 + 0.15, y1, y1 + (H ? 0.2 : 0.28), H ? 0.05 : 0.07)
          // side reveals / architrave on house windows
          if (H) {
            faceBox(trim, w, o.at - o.w / 2 - 0.1, o.at - o.w / 2, y0, y1, 0.04)
            faceBox(trim, w, o.at + o.w / 2, o.at + o.w / 2 + 0.1, y0, y1, 0.04)
          }
          // security bars on ground floor windows at the back / sides of the house
          const back = H && w.y < 1 && (w.axis === 'z' || w.z < -4)
          if (back) {
            const n = Math.max(4, Math.round(o.w / 0.13))
            for (let i = 1; i < n; i++) {
              const u = o.at - o.w / 2 + (i / n) * o.w
              faceBox(bars, w, u - 0.012, u + 0.012, y0, y1, 0.024, 0.06)
            }
            for (const yy of [y0 + 0.15, (y0 + y1) / 2, y1 - 0.15]) faceBox(bars, w, o.at - o.w / 2, o.at + o.w / 2, yy - 0.02, yy + 0.02, 0.012, 0.075)
          }
        } else if (o.kind === 'door') {
          if (H) {
            // concrete canopy + steps
            faceBox(trim, w, o.at - o.w / 2 - 0.5, o.at + o.w / 2 + 0.5, y1 + 0.3, y1 + 0.42, 1.0)
            faceBox(trim, w, o.at - o.w / 2 - 0.15, o.at - o.w / 2, y0, y1 + 0.15, 0.06)
            faceBox(trim, w, o.at + o.w / 2, o.at + o.w / 2 + 0.15, y0, y1 + 0.15, 0.06)
            faceBox(trim, w, o.at - o.w / 2 - 0.15, o.at + o.w / 2 + 0.15, y1, y1 + 0.15, 0.06)
            if (w.y < 1) {
              faceBox(dark, w, o.at - o.w / 2 - 0.45, o.at + o.w / 2 + 0.45, 0, 0.16, 0.9)
            }
          } else {
            faceBox(trim, w, o.at - o.w / 2 - 0.3, o.at + o.w / 2 + 0.3, y1 + 0.5, y1 + 0.6, 0.9)
            faceBox(steel, w, o.at - o.w / 2 - 0.25, o.at - o.w / 2 - 0.2, y1 + 0.1, y1 + 0.55, 0.85)
            faceBox(steel, w, o.at + o.w / 2 + 0.2, o.at + o.w / 2 + 0.25, y1 + 0.1, y1 + 0.55, 0.85)
            // lamp over the door
            const [lx, lz] = facePoint(w, o.at, 0.18)
            steel.box(lx, y1 + 0.35, lz, 0.36, 0.08, 0.36)
            glow.box(lx, y1 + 0.3, lz, 0.26, 0.03, 0.26)
          }
        } else if (o.kind === 'rollup') {
          // steel guide frame outside + hazard striped bumper
          faceBox(steel, w, o.at - o.w / 2 - 0.2, o.at - o.w / 2, 0, o.t + 0.05, 0.12)
          faceBox(steel, w, o.at + o.w / 2, o.at + o.w / 2 + 0.2, 0, o.t + 0.05, 0.12)
          faceBox(yellow, w, o.at - o.w / 2 - 0.2, o.at - o.w / 2, 0, 1.2, 0.14)
          faceBox(yellow, w, o.at + o.w / 2, o.at + o.w / 2 + 0.2, 0, 1.2, 0.14)
          // flood light
          const [lx, lz] = facePoint(w, o.at, 0.35)
          steel.box(lx, o.t + 0.75, lz, 0.6, 0.12, 0.4, 0, 0.25)
          glow.box(lx, o.t + 0.69, lz, 0.5, 0.02, 0.3, 0, 0.25)
          // bollards
          for (const s of [-1, 1]) {
            const [bx, bz] = facePoint(w, o.at + s * (o.w / 2 + 0.6), 0.55)
            yel.cyl(bx, 0.55, bz, 0.12, 1.1, 14)
          }
        }
      }
    }

    // ---------------- hall roof: eaves overhang, verges, gutters, ridge cap ----------------
    const tilt = Math.atan(SLOPE)
    const OV = 0.8
    const VG = 0.5
    for (const s of [-1, 1]) {
      const zc = s * (HZ + OV / 2)
      const yc = EAVE + 0.035 - (OV / 2) * SLOPE
      roof.box(-0.0, yc, zc, 2 * HX + 2 * VG, 0.05, OV / Math.cos(tilt), 0, s * tilt)
      // verges along both gables
      for (const gx of [-1, 1]) {
        const half = (HZ + OV) / 2
        roof.box(gx * (HX + VG / 2), roofY(s * half) + 0.035, s * half, VG, 0.05, (HZ + OV) / Math.cos(tilt) - 0.02, 0, s * tilt)
        steel.box(gx * (HX + VG), roofY(s * half) - 0.05, s * half, 0.05, 0.22, (HZ + OV) / Math.cos(tilt), 0, s * tilt)
      }
      // fascia + gutter
      const zf = s * (HZ + OV + 0.03)
      const yf = EAVE - OV * SLOPE
      steel.box(0, yf - 0.06, zf, 2 * HX + 2 * VG + 0.1, 0.22, 0.05)
      steel.box(0, yf - 0.16, zf + s * 0.09, 2 * HX + 2 * VG + 0.1, 0.03, 0.18)
      steel.box(0, yf - 0.08, zf + s * 0.18, 2 * HX + 2 * VG + 0.1, 0.18, 0.03)
      // downpipes
      for (const x of [-18.6, -6.9, 5.25, 18.9]) {
        const pz = s * (HZ + 0.2 + 0.09)
        pipes.cyl(x, (yf - 0.2) / 2 + 0.15, pz, 0.065, yf - 0.5, 10)
        pipes.cyl(x, yf - 0.28, s * (HZ + 0.2 + 0.09 + (OV - 0.1) / 2), 0.065, OV - 0.05, 10, Math.PI / 2)
        pipes.cyl(x, 0.2, pz + s * 0.12, 0.075, 0.35, 10, Math.PI / 2)
      }
    }
    // ridge cap
    steel.box(0, RIDGE + 0.07, 0, 2 * HX + 2 * VG, 0.06, 0.55)
    // roof ventilators on intact panels
    let vents = 0
    for (const p of ROOF_PANELS) {
      if (p.state !== 'ok' || vents >= 6 || (p.i + p.j * 3) % 7 !== 0) continue
      const cx = (p.x0 + p.x1) / 2
      const cz = (p.z0 + p.z1) / 2
      const y = roofY(cz) + 0.05
      metal.cyl(cx, y + 0.3, cz, 0.22, 0.6, 14)
      metal.cyl(cx, y + 0.75, cz, 0.12, 0.3, 14, 0, 0, 0.36)
      vents++
    }
    // gable louvres
    for (const gx of [-1, 1]) {
      for (let k = 0; k < 6; k++) steel.box(gx * (HX + 0.24), RIDGE - 0.9 - k * 0.12, 0, 0.06, 0.04, 1.6, 0, 0, gx * 0.35)
      steel.box(gx * (HX + 0.22), RIDGE - 1.2, 0, 0.05, 0.85, 0.06)
    }

    // ---------------- fire escape ladder on the east wall ----------------
    {
      const lx = HX + 0.45
      const lz = 6.0
      for (const dz of [-0.28, 0.28]) steel.box(lx, (EAVE + 1.2) / 2 + 0.6, lz + dz, 0.06, EAVE + 0.6, 0.06)
      for (let y = 2.6; y < EAVE + 0.8; y += 0.3) steel.box(lx, y, lz, 0.03, 0.03, 0.56)
      for (let y = 3.2; y < EAVE + 0.8; y += 0.8) {
        // safety cage hoops (open box approximation)
        steel.box(lx + 0.38, y, lz, 0.03, 0.04, 0.72)
        steel.box(lx + 0.19, y, lz - 0.36, 0.4, 0.04, 0.03)
        steel.box(lx + 0.19, y, lz + 0.36, 0.4, 0.04, 0.03)
      }
      for (const dz of [-0.36, 0, 0.36]) steel.box(lx + 0.38 - (dz === 0 ? 0 : 0.19) + (dz === 0 ? 0 : 0.19), (EAVE + 4) / 2 + 0.6, lz + dz, 0.03, EAVE - 2.6, 0.03)
      for (const y of [1.0, 4.5, 8.0]) steel.box(HX + 0.25, y, lz, 0.25, 0.06, 0.06)
      // electrical cabinet & conduit
      steel.box(HX + 0.42, 0.95, 4.2, 0.4, 1.9, 1.15)
      pipes.cyl(HX + 0.3, 5.0, 4.75, 0.04, 6.2, 8)
    }

    // ---------------- house facades ----------------
    band(dark, 0, 0.55, 0.06, house) // plinth
    band(trim, 3.82, 4.18, 0.09, house) // string course between floors
    band(trim, 6.98, H_ROOF + 0.02, 0.16, house) // cornice
    // parapet coping (parapets from House.tsx: y 7.3..7.7, t 0.25 at zMin-0.2 / zMax+0.2 / xMin-0.2)
    const W = HOUSE.xMax - HOUSE.xMin
    const cx = (HOUSE.xMin + HOUSE.xMax) / 2
    const D = HOUSE.zMax - HOUSE.zMin
    const czH = (HOUSE.zMin + HOUSE.zMax) / 2
    trim.box(cx - 0.1, H_CEIL2 + 0.73, HOUSE.zMin - 0.2, W + 0.7, 0.07, 0.4)
    trim.box(cx - 0.1, H_CEIL2 + 0.73, HOUSE.zMax + 0.2, W + 0.7, 0.07, 0.4)
    trim.box(HOUSE.xMin - 0.2, H_CEIL2 + 0.73, czH, 0.4, 0.07, D + 0.3)
    // flat roof membrane edge strip (tar) visible from above
    tar.box(cx - 0.1, H_ROOF + 0.004, HOUSE.zMin + 0.15, W + 0.4, 0.008, 0.5)
    tar.box(cx - 0.1, H_ROOF + 0.004, HOUSE.zMax - 0.15, W + 0.4, 0.008, 0.5)
    // corner quoins
    for (const [qx, qz] of [[HOUSE.xMin, HOUSE.zMax], [HOUSE.xMin, HOUSE.zMin]] as [number, number][]) {
      const sz = qz > 0 ? 1 : -1
      for (let k = 0; k < 11; k++) {
        const y = 0.6 + k * 0.6
        if (y > 6.9) break
        const long = k % 2 === 0
        trim.box(qx - 0.15 - 0.025 + (long ? 0.25 : 0.15), y + 0.25, qz + sz * (0.15 + 0.025), long ? 0.55 : 0.35, 0.5, 0.05)
        trim.box(qx - 0.15 - 0.025, y + 0.25, qz + sz * (0.15 + 0.025) - sz * (long ? 0.15 : 0.25), 0.05, 0.5, long ? 0.35 : 0.55)
      }
    }
    // downpipes on the house
    for (const [px, pz] of [[HOUSE.xMin - 0.25, HOUSE.zMax + 0.25], [HOUSE.xMin - 0.25, HOUSE.zMin - 0.25], [-21.0, HOUSE.zMax + 0.24], [-21.0, HOUSE.zMin - 0.24]] as [number, number][]) {
      pipes.cyl(px, H_ROOF / 2, pz, 0.055, H_ROOF, 10)
      pipes.cyl(px, H_ROOF + 0.2, pz, 0.09, 0.3, 10, 0, 0, 0.13)
    }
    // wall mounted AC units on the south facade (upper floor)
    for (const x of [-35.1, -25.0]) {
      steel.box(x, 4.5, HOUSE.zMax + 0.15 + 0.17, 0.82, 0.55, 0.32)
      bars.box(x + 0.15, 4.5, HOUSE.zMax + 0.15 + 0.34, 0.42, 0.42, 0.02)
      steel.box(x - 0.3, 4.2, HOUSE.zMax + 0.15 + 0.16, 0.05, 0.05, 0.3)
      steel.box(x + 0.3, 4.2, HOUSE.zMax + 0.15 + 0.16, 0.05, 0.05, 0.3)
    }
    // ground AC condensers + gas meter at the back
    for (const x of [-36, -30.5]) {
      steel.box(x, 0.4, HOUSE.zMin - 0.75, 0.95, 0.8, 0.55)
      bars.box(x, 0.45, HOUSE.zMin - 1.03, 0.6, 0.6, 0.02)
      pipes.cyl(x + 0.3, 0.9, HOUSE.zMin - 0.42, 0.02, 1.2, 6)
    }
    steel.box(-27.0, 1.3, HOUSE.zMin - 0.32, 0.6, 0.8, 0.25)

    // ---------------- house rooftop ----------------
    const RY = H_ROOF
    // stair bulkhead / roof access
    trim.box(-28.6, RY + 1.2, -9.3, 2.4, 2.4, 2.2)
    trim.box(-28.6, RY + 2.45, -9.3, 2.7, 0.12, 2.5)
    steel.box(-28.6, RY + 1.0, -8.18, 0.95, 2.0, 0.06)
    // water tank on a steel stand
    for (const [dx, dz] of [[-0.6, -0.6], [0.6, -0.6], [0.6, 0.6], [-0.6, 0.6]]) steel.box(-39 + dx, RY + 0.7, -9 + dz, 0.08, 1.4, 0.08)
    steel.box(-39, RY + 1.42, -9, 1.5, 0.06, 1.5)
    metal.cyl(-39, RY + 2.25, -9, 0.75, 1.6, 20)
    metal.cyl(-39, RY + 3.1, -9, 0.2, 0.1, 12, 0, 0, 0.75)
    // HVAC units
    for (const [x, z] of [[-38.5, 0.6], [-24.5, 0.5]] as [number, number][]) {
      steel.box(x, RY + 0.55, z, 1.8, 1.1, 1.2)
      steel.box(x, RY + 0.06, z, 2.0, 0.12, 1.4)
      metal.cyl(x - 0.4, RY + 1.14, z, 0.4, 0.08, 18)
      metal.cyl(x + 0.45, RY + 1.14, z, 0.4, 0.08, 18)
      pipes.cyl(x + 1.4, RY + 0.25, z, 0.12, 1.2, 10, 0, Math.PI / 2)
    }
    // antenna mast + satellite dish
    pipes.cyl(-41.2, RY + 3.0, 2.2, 0.04, 6.0, 8)
    for (let k = 0; k < 4; k++) pipes.cyl(-41.2, RY + 3.5 + k * 0.6, 2.2, 0.012, 1.2 - k * 0.2, 6, 0, Math.PI / 2)
    pipes.cyl(-41.2 + 0.4, RY + 2.4, 2.2, 0.01, 2.5, 4, 0, 0.35)
    metal.add(new THREE.SphereGeometry(0.45, 18, 10, 0, Math.PI * 2, 0, 0.9).rotateX(-Math.PI / 2 + 0.5).translate(-40.6, RY + 1.3, -2.3))
    pipes.cyl(-40.6, RY + 0.6, -2.0, 0.035, 1.2, 8)
    // sandbag nest on the house roof (sniper spot vibe)
    {
      const bx = -41.0
      const bz = -4.0
      for (let row = 0; row < 3; row++) {
        for (let i = 0; i < 6; i++) {
          const z = bz - 1.4 + i * 0.52 + (row % 2) * 0.26
          sand.box(bx + 0.3, RY + 0.11 + row * 0.2, z, 0.34, 0.2, 0.5, (i * 0.13) % 0.2 - 0.1)
        }
        for (let i = 0; i < 4; i++) sand.box(bx + 0.55 + i * 0.5 + (row % 2) * 0.25, RY + 0.11 + row * 0.2, bz - 1.65, 0.5, 0.2, 0.34, (i * 0.17) % 0.2 - 0.1)
      }
    }
    // roof membrane patches
    tar.box(-31, RY + 0.003, -1.0, 4.0, 0.006, 3.0)
    tar.box(-25.5, RY + 0.003, -8.8, 3.0, 0.006, 2.2)

    return {
      trim: trim.geometry(),
      dark: dark.geometry(),
      pier: pier.geometry(),
      steel: steel.geometry(),
      roof: roof.geometry(),
      bars: bars.geometry(),
      yellow: yellow.geometry(),
      tar: tar.geometry(),
      sand: sand.geometry(),
      glow: glow.geometry(),
      pipes: pipes.geometry(),
      metal: metal.geometry(),
      yel: yel.geometry(),
    }
  }, [])

  return (
    <group>
      <Merged geo={geos.trim} mat={mats.concreteTrim} />
      <Merged geo={geos.dark} mat={mats.concreteDark} />
      <Merged geo={geos.pier} mat={mats.pier} />
      <Merged geo={geos.steel} mat={m.steelDark} />
      <Merged geo={geos.roof} mat={mats.roofEdge} />
      <Merged geo={geos.bars} mat={m.metalDark} />
      <Merged geo={geos.yellow} mat={mats.yellow} />
      <Merged geo={geos.tar} mat={mats.tar} cast={false} />
      <Merged geo={geos.sand} mat={mats.sandbag} />
      <Merged geo={geos.glow} mat={mats.lampGlow} cast={false} />
      <Merged geo={geos.pipes} mat={mats.pipe} />
      <Merged geo={geos.metal} mat={m.steel} />
      <Merged geo={geos.yel} mat={mats.yellow} />
    </group>
  )
}

import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { wallColliders, floorHeightAt, ROOMS } from './layout'
void ROOMS
import { PROP_COLLIDERS } from './Props'
import { HOUSE_COLLIDERS } from './HouseProps'
import { ARCH_COLLIDERS } from './Architecture'
import { EXT_COLLIDERS } from './Exterior'
import { store } from '../state'
import { fx } from '../player/shared'

const R = 0.3
const FOLLOW_DIST = 2.9
const LINES = [
  'Aman, saya di belakangmu.',
  'Area ini sudah saya cek sekilas. Cukup sepi.',
  'Hati-hati, lantai kayunya rapuh.',
  'Kalau perlu cover, pakai kontainer di timur.',
  'Saya jaga pintu masuk. Kamu lanjut saja.',
  'Ada suara angin di lorong tadi. Mungkin cuma bangunan tua.',
  'Tangga besi di barat mengarah ke atap. Pandangan bagus dari sana.',
  'Amunisi cadangan masih banyak. Santai.',
  'Jangan berdiri terlalu lama di jendela.',
  'Saya lihat bekas tembakan di dinding utara.',
]
const ROOM_LINES: Record<string, string> = {
  hall: 'Hall utama. Banyak sudut buta di sini.',
  house: 'Kita masuk area rumah. Sempit, hati-hati.',
  roof: 'Di atap. Angin kencang, jangan terlalu dekat tepi.',
  tower: 'Menara jaga. Posisi bagus untuk mengawasi halaman.',
}

function nameTexture() {
  const c = document.createElement('canvas')
  c.width = 512
  c.height = 128
  const ctx = c.getContext('2d')!
  ctx.clearRect(0, 0, 512, 128)
  ctx.fillStyle = 'rgba(8,14,16,0.72)'
  ctx.fillRect(6, 16, 500, 88)
  ctx.strokeStyle = 'rgba(120,220,225,0.9)'
  ctx.lineWidth = 4
  ctx.strokeRect(6, 16, 500, 88)
  ctx.fillStyle = '#d7fbfb'
  ctx.font = 'bold 46px monospace'
  ctx.fillText('GHOST-2', 26, 68)
  ctx.fillStyle = '#7fd4d8'
  ctx.font = '24px monospace'
  ctx.fillText('FRIENDLY · SUPPORT BOT', 26, 96)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

export function Bot() {
  const colliders = useMemo(() => [...wallColliders(), ...PROP_COLLIDERS, ...HOUSE_COLLIDERS, ...ARCH_COLLIDERS, ...EXT_COLLIDERS], [])
  const tag = useMemo(() => nameTexture(), [])
  const rig = useMemo(() => {
    const boot = new THREE.MeshStandardMaterial({ color: '#23231f', roughness: 0.9 })
    const trouser = new THREE.MeshStandardMaterial({ color: '#3d4133', roughness: 0.95 })
    const shirt = new THREE.MeshStandardMaterial({ color: '#4b5340', roughness: 0.92 })
    const vest = new THREE.MeshStandardMaterial({ color: '#2f3529', roughness: 0.85 })
    const glove = new THREE.MeshStandardMaterial({ color: '#2a2824', roughness: 0.9 })
    const gun = new THREE.MeshStandardMaterial({ color: '#26282b', roughness: 0.45, metalness: 0.7 })
    const helmet = new THREE.MeshStandardMaterial({ color: '#3c4234', roughness: 0.75 })
    const visor = new THREE.MeshStandardMaterial({ color: '#111417', roughness: 0.15, metalness: 0.6 })
    const patch = new THREE.MeshStandardMaterial({ color: '#66d3d8', emissive: new THREE.Color('#3fb9c0'), emissiveIntensity: 1.3, roughness: 0.4 })

    const root = new THREE.Group()
    const body = new THREE.Group()
    root.add(body)
    const box = (mat: THREE.Material, s: [number, number, number], p: [number, number, number], parent: THREE.Object3D = body) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(...s), mat)
      m.position.set(...p)
      m.castShadow = true
      m.receiveShadow = true
      parent.add(m)
      return m
    }
    // torso + plate carrier
    box(shirt, [0.4, 0.55, 0.23], [0, 1.22, 0])
    box(vest, [0.44, 0.42, 0.3], [0, 1.24, 0])
    box(vest, [0.3, 0.16, 0.07], [0, 1.28, 0.18])
    box(vest, [0.12, 0.1, 0.05], [0.13, 1.16, 0.19])
    box(patch, [0.09, 0.06, 0.02], [-0.13, 1.36, 0.17])
    // backpack + radio
    box(vest, [0.36, 0.42, 0.18], [0, 1.22, -0.22])
    box(vest, [0.09, 0.2, 0.08], [0.14, 1.38, -0.3])
    box(gun, [0.02, 0.2, 0.02], [0.17, 1.52, -0.28])
    // neck / head / helmet
    box(shirt, [0.12, 0.09, 0.12], [0, 1.52, 0])
    const head = new THREE.Group()
    head.position.set(0, 1.62, 0)
    body.add(head)
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.125, 16, 12), visor)
    skull.scale.set(1, 1.1, 1)
    skull.castShadow = true
    head.add(skull)
    const helm = new THREE.Mesh(new THREE.SphereGeometry(0.155, 16, 12, 0, Math.PI * 2, 0, Math.PI / 1.7), helmet)
    helm.position.y = 0.015
    helm.castShadow = true
    head.add(helm)
    box(visor, [0.2, 0.06, 0.04], [0, 0.01, 0.11], head)
    box(helmet, [0.06, 0.06, 0.08], [0.12, 0.03, 0], head)
    box(patch, [0.03, 0.03, 0.02], [-0.1, 0.02, 0.1], head)
    // arms (right hand grips rifle, left supports)
    const armL = new THREE.Group()
    armL.position.set(-0.24, 1.44, 0)
    body.add(armL)
    box(shirt, [0.13, 0.3, 0.14], [-0.01, -0.15, 0.02], armL)
    box(shirt, [0.12, 0.28, 0.13], [-0.03, -0.36, 0.16], armL)
    box(glove, [0.1, 0.1, 0.1], [-0.03, -0.5, 0.24], armL)
    const armR = new THREE.Group()
    armR.position.set(0.24, 1.44, 0)
    body.add(armR)
    box(shirt, [0.13, 0.3, 0.14], [0.01, -0.16, -0.02], armR)
    box(shirt, [0.12, 0.26, 0.13], [0.02, -0.36, 0.08], armR)
    box(glove, [0.1, 0.1, 0.1], [0.02, -0.46, 0.16], armR)
    // legs
    const legL = new THREE.Group()
    legL.position.set(-0.11, 0.95, 0)
    body.add(legL)
    box(trouser, [0.17, 0.44, 0.19], [0, -0.22, 0], legL)
    box(trouser, [0.15, 0.4, 0.16], [0, -0.6, 0.02], legL)
    box(boot, [0.16, 0.12, 0.26], [0, -0.84, 0.05], legL)
    const legR = new THREE.Group()
    legR.position.set(0.11, 0.95, 0)
    body.add(legR)
    box(trouser, [0.17, 0.44, 0.19], [0, -0.22, 0], legR)
    box(trouser, [0.15, 0.4, 0.16], [0, -0.6, 0.02], legR)
    box(boot, [0.16, 0.12, 0.26], [0, -0.84, 0.05], legR)
    // rifle held across the chest
    const rifle = new THREE.Group()
    rifle.position.set(0.02, 1.04, 0.22)
    rifle.rotation.set(0.08, 0.15, 0.35)
    body.add(rifle)
    box(gun, [0.055, 0.06, 0.62], [0, 0, 0], rifle)
    box(gun, [0.045, 0.045, 0.26], [0, -0.02, -0.44], rifle)
    box(gun, [0.05, 0.09, 0.16], [0, -0.06, 0.12], rifle)
    box(gun, [0.045, 0.16, 0.07], [0, -0.13, 0.06], rifle)
    box(gun, [0.035, 0.05, 0.14], [0, 0.02, -0.1], rifle)
    // name tag
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tag, transparent: true, depthWrite: false, depthTest: false }))
    sprite.scale.set(1.15, 0.29, 1)
    sprite.position.set(0, 2.02, 0)
    root.add(sprite)
    // friendly identification light
    const lamp = new THREE.PointLight('#63d6dc', 0.5, 2.4, 2)
    lamp.position.set(-0.15, 1.6, 0.1)
    root.add(lamp)
    root.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.isMesh) {
        m.castShadow = true
        m.receiveShadow = true
        m.userData.noHit = false
      }
    })
    return { root, body, head, armL, armR, legL, legR, sprite }
  }, [tag])

  const st = useRef({
    pos: new THREE.Vector3(-24.4, 0, 28.8),
    yaw: Math.PI,
    phase: 0,
    speed: 0,
    stuck: 0,
    barkT: 0,
    room: '',
    greet: false,
    tick: 0,
    anchor: new THREE.Vector3(-24.4, 0, 28.8),
  })

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'KeyG' || e.repeat) return
      if (document.pointerLockElement === null) return
      const cur = store.get().botMode
      const next = cur === 'follow' ? 'stay' : 'follow'
      store.set({ botMode: next })
      st.current.barkT = -6
      store.set({ barkText: next === 'follow' ? 'Oke, saya ikut lagi. Jangan terlalu jauh.' : 'Baik, saya tunggu di sini. Hati-hati.', barkId: store.get().barkId + 1 })
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  useFrame((_, rawDt) => {
    const dt = Math.min(0.05, rawDt)
    const s = st.current
    const gs = store.get()
    const locked = document.pointerLockElement !== null
    const px = fx.px
    const pz = fx.pz
    const py = fx.py
    const dx = px - s.pos.x
    const dz = pz - s.pos.z
    const dist = Math.hypot(dx, dz)

    let wishX = 0
    let wishZ = 0
    if (gs.botMode === 'follow' && dist > FOLLOW_DIST) {
      const fxDir = -Math.sin(fx.yaw)
      const fzDir = -Math.cos(fx.yaw)
      const tx = px + fxDir * -2.1 + Math.cos(fx.yaw) * -0.9
      const tz = pz + fzDir * -2.1 - Math.sin(fx.yaw) * -0.9
      const ddx = tx - s.pos.x
      const ddz = tz - s.pos.z
      const dl = Math.hypot(ddx, ddz) || 1
      wishX = ddx / dl
      wishZ = ddz / dl
      // if the direct line is long, just head straight for the player
      if (dist > 9) {
        wishX = dx / dist
        wishZ = dz / dist
      }
    } else if (gs.botMode === 'stay') {
      s.anchor.copy(s.pos)
    }
    // safety teleport if the bot got separated / stuck on another floor
    if (locked && dist > 26) {
      const bx = px + Math.sin(fx.yaw) * 2.4
      const bz = pz + Math.cos(fx.yaw) * 2.4
      const h = floorHeightAt(bx, bz, py + 1)
      if (Math.abs(h - py) < 1.2) {
        s.pos.set(bx, h, bz)
        s.stuck = 0
      }
    }

    const wantSpeed = wishX || wishZ ? (dist > 9 ? 5.2 : dist > 4.6 ? 3.6 : 2.4) : 0
    s.speed += (wantSpeed - s.speed) * (1 - Math.exp(-dt * 8))
    const move = s.speed * dt
    const beforeX = s.pos.x
    const beforeZ = s.pos.z
    s.pos.x += wishX * move
    s.pos.z += wishZ * move

    // circle vs AABB collision (same rules as the player)
    const feet = s.pos.y
    const head = feet + 1.75
    for (let pass = 0; pass < 2; pass++) {
      for (const c of colliders) {
        if (c.maxY <= feet + 0.42) continue
        if (c.minY >= head) continue
        const cx = Math.max(c.minX, Math.min(c.maxX, s.pos.x))
        const cz = Math.max(c.minZ, Math.min(c.maxZ, s.pos.z))
        let ddx = s.pos.x - cx
        let ddz = s.pos.z - cz
        const d2 = ddx * ddx + ddz * ddz
        if (d2 >= R * R) continue
        if (d2 < 1e-8) {
          const pdx = Math.min(s.pos.x - c.minX, c.maxX - s.pos.x)
          const pdz = Math.min(s.pos.z - c.minZ, c.maxZ - s.pos.z)
          if (pdx < pdz) s.pos.x += s.pos.x - c.minX < c.maxX - s.pos.x ? -(pdx + R) : pdx + R
          else s.pos.z += s.pos.z - c.minZ < c.maxZ - s.pos.z ? -(pdz + R) : pdz + R
          continue
        }
        const d = Math.sqrt(d2)
        const push = R - d
        s.pos.x += (ddx / d) * push
        s.pos.z += (ddz / d) * push
      }
    }
    // vertical follow
    const support = floorHeightAt(s.pos.x, s.pos.z, s.pos.y)
    if (support <= s.pos.y + 0.6) s.pos.y += (support - s.pos.y) * (1 - Math.exp(-dt * 12))
    else {
      s.pos.x = beforeX
      s.pos.z = beforeZ
    }
    const moved = Math.hypot(s.pos.x - beforeX, s.pos.z - beforeZ) / Math.max(1e-4, move)
    if (wantSpeed > 0 && moved < 0.35) s.stuck += dt
    else s.stuck = Math.max(0, s.stuck - dt * 2)
    if (s.stuck > 3) {
      // sidestep to unstick
      s.pos.x += Math.cos(fx.yaw) * 0.6
      s.pos.z -= Math.sin(fx.yaw) * 0.6
      s.stuck = 0
    }

    // facing
    const moving = Math.hypot(wishX, wishZ) > 0.05 && s.speed > 0.2
    const face = moving ? Math.atan2(wishX, wishZ) : Math.atan2(px - s.pos.x, pz - s.pos.z)
    let diff = ((face - s.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI
    s.yaw += diff * (1 - Math.exp(-dt * 7))

    // animation
    s.phase += dt * (2.2 + s.speed * 1.9)
    const amp = Math.min(1, s.speed / 3.2)
    const swing = Math.sin(s.phase) * 0.6 * amp
    rig.legL.rotation.x = swing
    rig.legR.rotation.x = -swing
    rig.armL.rotation.x = -swing * 0.55
    rig.armR.rotation.x = swing * 0.3
    rig.body.position.y = Math.abs(Math.sin(s.phase * 2)) * 0.025 * amp + Math.sin(s.phase * 0.5) * 0.008
    rig.body.rotation.z = Math.sin(s.phase) * 0.02 * amp
    rig.head.rotation.y = Math.sin(performance.now() * 0.0004) * 0.22 * (1 - amp)
    rig.sprite.visible = dist < 16 && dist > 1.2
    rig.root.position.copy(s.pos)
    rig.root.rotation.y = s.yaw

    // barks
    s.barkT += dt
    const roomKey = s.pos.y > 6.6 ? 'roof' : s.pos.x < -20.2 ? 'house' : 'hall'
    if (locked && roomKey !== s.room) {
      s.room = roomKey
      if (s.phase > 1 && Math.random() < 0.7) {
        s.barkT = -8
        store.set({ barkText: ROOM_LINES[roomKey], barkId: store.get().barkId + 1 })
      }
    }
    if (!locked) return
    if (!s.greet && performance.now() > 1500) {
      s.greet = true
      store.set({ barkText: 'Siap. Saya GHOST-2, ikut dari belakang. Tekan G kalau mau saya berhenti.', barkId: store.get().barkId + 1 })
      s.barkT = 0
    } else if (s.barkT > 26 + Math.random() * 14) {
      s.barkT = 0
      store.set({ barkText: LINES[Math.floor(Math.random() * LINES.length)], barkId: store.get().barkId + 1 })
    }
    if (s.tick++ % 15 === 0) store.set({ botX: Math.round(s.pos.x * 10) / 10, botZ: Math.round(s.pos.z * 10) / 10 })
  })

  return <primitive object={rig.root} />
}

import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials, floorGeometry } from './materials'
import { HX, HZ, HOUSE, boxCollider, type AABB } from './layout'
import { GeoBuilder, CylBuilder, Merged } from './Architecture'
import { mergeGeometries, mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ---------------------------------------------------------------------------
// compound layout
export const BOUNDS = { x0: -60, x1: 36, z0: -28, z1: 40 }
const GATE = { x0: -10, x1: -4 }
const WALL_H = 3.0

type Rot = { x: number; z: number; r: number }
const CARS: (Rot & { burnt: boolean; color: string })[] = [
  { x: -4, z: 19, r: 0.4, burnt: false, color: '#5d6461' },
  { x: -14, z: 30, r: 2.2, burnt: true, color: '#2a2622' },
  { x: 24, z: 16, r: 0.9, burnt: true, color: '#2a2622' },
  { x: -46, z: -18, r: 1.2, burnt: false, color: '#6e5a3e' },
]
const JERSEYS: Rot[] = [
  { x: -22, z: 22, r: 0.1 },
  { x: -18.7, z: 22.6, r: -0.25 },
  { x: 2, z: 27, r: 1.57 },
  { x: 2.3, z: 30.1, r: 1.45 },
  { x: 16, z: 25, r: 0.3 },
  { x: 26, z: 5.5, r: 1.4 },
  { x: 27, z: -9, r: 1.65 },
  { x: -32, z: 30, r: 0.05 },
  { x: -50, z: 8, r: 1.5 },
]
const SANDBAGS: (Rot & { len: number })[] = [
  { x: -35, z: 17.5, r: 0, len: 3.2 },
  { x: 24, z: -20, r: 0.5, len: 3.6 },
  { x: 8, z: 33, r: 0, len: 4 },
  { x: -52, z: -8, r: 1.57, len: 3 },
  { x: 30, z: 30, r: -0.6, len: 3 },
]
const CONTAINERS: (Rot & { y: number; color: string })[] = [
  { x: 11, z: 18.5, r: 0.25, y: 0, color: '#8a3a2b' },
  { x: 11.4, z: 18.3, r: 0.2, y: 2.6, color: '#2b5a96' },
  { x: -48, z: 26, r: 0.05, y: 0, color: '#3f5b3a' },
  { x: -48.3, z: 29, r: 0.0, y: 0, color: '#8b6d2f' },
  { x: -48.1, z: 27.5, r: 0.03, y: 2.6, color: '#7a7d80' },
  { x: 29, z: -20.5, r: 1.57, y: 0, color: '#2b5a96' },
  { x: -50, z: -2, r: 1.45, y: 0, color: '#6e4a32' },
  { x: 30.5, z: 22, r: 1.2, y: 0, color: '#8a3a2b' },
]
const POLES: [number, number][] = [
  [-30, 21],
  [3, 36],
  [30, -14],
  [-54, -18],
  [30, 34],
  [-54, 34],
]
const TOWER = { x: -55.5, z: -23.5 }
const BOOTH = { x: -13.2, z: 37.4 }

function rotCollider(cx: number, cz: number, w: number, d: number, r: number, y0: number, y1: number): AABB {
  const c = Math.abs(Math.cos(r))
  const s = Math.abs(Math.sin(r))
  return boxCollider(cx, cz, w * c + d * s, w * s + d * c, y0, y1)
}

export const EXT_COLLIDERS: AABB[] = (() => {
  const out: AABB[] = []
  const { x0, x1, z0, z1 } = BOUNDS
  out.push({ minX: x0 - 0.3, maxX: x0 + 0.3, minZ: z0, maxZ: z1, minY: 0, maxY: 20 })
  out.push({ minX: x1 - 0.3, maxX: x1 + 0.3, minZ: z0, maxZ: z1, minY: 0, maxY: 20 })
  out.push({ minX: x0, maxX: x1, minZ: z0 - 0.3, maxZ: z0 + 0.3, minY: 0, maxY: 20 })
  out.push({ minX: x0, maxX: x1, minZ: z1 - 0.3, maxZ: z1 + 0.3, minY: 0, maxY: 20 })
  for (const c of CARS) out.push(rotCollider(c.x, c.z, 4.4, 1.85, c.r, 0, 1.45))
  for (const j of JERSEYS) out.push(rotCollider(j.x, j.z, 3.0, 0.6, j.r, 0, 0.82))
  for (const s of SANDBAGS) out.push(rotCollider(s.x, s.z, s.len, 0.6, s.r, 0, 1.0))
  for (const c of CONTAINERS) if (c.y === 0) out.push(rotCollider(c.x, c.z, 6.06, 2.44, c.r, 0, 2.6 * (CONTAINERS.some((o) => o.y > 0 && Math.hypot(o.x - c.x, o.z - c.z) < 2) ? 2 : 1)))
  for (const [x, z] of POLES) out.push(boxCollider(x, z, 0.3, 0.3, 0, 8))
  for (const dx of [-1.6, 1.6]) for (const dz of [-1.6, 1.6]) out.push(boxCollider(TOWER.x + dx, TOWER.z + dz, 0.3, 0.3, 0, 4.5))
  out.push(boxCollider(BOOTH.x, BOOTH.z, 2.3, 2.3, 0, 2.8))
  out.push(boxCollider(16.7, HZ + 2.25, 2.2, 1.0, 0, 0.95)) // drums
  return out
})()

// ---------------------------------------------------------------------------
// procedural textures
function canvas(size: number) {
  const c = document.createElement('canvas')
  c.width = c.height = size
  return c
}
function makeAsphalt() {
  const size = 512
  const c = canvas(size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const rnd = mulberry(91)
  for (let i = 0; i < size * size; i++) {
    const v = 58 + rnd() * 26 + (rnd() < 0.04 ? 40 : 0)
    img.data[i * 4] = v
    img.data[i * 4 + 1] = v
    img.data[i * 4 + 2] = v + 2
    img.data[i * 4 + 3] = 255
  }
  ctx.putImageData(img, 0, 0)
  // large tonal patches
  for (let i = 0; i < 26; i++) {
    const x = rnd() * size
    const y = rnd() * size
    const r = 30 + rnd() * 90
    const g = ctx.createRadialGradient(x, y, 0, x, y, r)
    const dark = rnd() < 0.6
    g.addColorStop(0, dark ? 'rgba(20,20,20,0.35)' : 'rgba(150,150,145,0.18)')
    g.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, size, size)
  }
  // cracks
  ctx.strokeStyle = 'rgba(15,15,15,0.75)'
  for (let i = 0; i < 14; i++) {
    ctx.lineWidth = 0.8 + rnd() * 1.4
    ctx.beginPath()
    let x = rnd() * size
    let y = rnd() * size
    ctx.moveTo(x, y)
    for (let k = 0; k < 12; k++) {
      x += (rnd() - 0.5) * 40
      y += (rnd() - 0.5) * 40
      ctx.lineTo(x, y)
    }
    ctx.stroke()
  }
  return c
}
function makeFacade(seed: number) {
  // 4 x 4 bays, each bay = 3 m x 3 m  -> texture covers 12 m
  const size = 1024
  const c = canvas(size)
  const ctx = c.getContext('2d')!
  const rnd = mulberry(seed)
  ctx.fillStyle = '#9a958c'
  ctx.fillRect(0, 0, size, size)
  const img = ctx.getImageData(0, 0, size, size)
  for (let i = 0; i < size * size; i++) {
    const n = (rnd() - 0.5) * 18
    img.data[i * 4] += n
    img.data[i * 4 + 1] += n
    img.data[i * 4 + 2] += n
  }
  ctx.putImageData(img, 0, 0)
  const bay = size / 4
  for (let by = 0; by < 4; by++) {
    for (let bx = 0; bx < 4; bx++) {
      const x0 = bx * bay
      const y0 = by * bay
      // panel joints
      ctx.fillStyle = 'rgba(40,38,35,0.5)'
      ctx.fillRect(x0, y0, bay, 3)
      ctx.fillRect(x0, y0, 3, bay)
      // slab band
      ctx.fillStyle = 'rgba(180,176,168,0.6)'
      ctx.fillRect(x0, y0 + bay - 22, bay, 18)
      // window
      const k = rnd()
      const wx = x0 + bay * 0.22
      const wy = y0 + bay * 0.2
      const ww = bay * 0.56
      const wh = bay * 0.5
      ctx.fillStyle = '#6f6b64'
      ctx.fillRect(wx - 6, wy - 6, ww + 12, wh + 14)
      if (k < 0.45) ctx.fillStyle = '#0d0f12'
      else if (k < 0.7) ctx.fillStyle = '#3a4650'
      else if (k < 0.85) ctx.fillStyle = '#6b5638'
      else ctx.fillStyle = '#1c1a17'
      ctx.fillRect(wx, wy, ww, wh)
      if (k >= 0.45 && k < 0.7) {
        ctx.fillStyle = 'rgba(200,215,225,0.25)'
        ctx.fillRect(wx, wy, ww * 0.5, wh * 0.4)
        ctx.fillStyle = '#4a4741'
        ctx.fillRect(wx + ww / 2 - 3, wy, 6, wh)
      }
      if (k >= 0.7 && k < 0.85) {
        ctx.strokeStyle = 'rgba(60,45,25,0.8)'
        ctx.lineWidth = 4
        for (let p = 0; p < 4; p++) {
          ctx.beginPath()
          ctx.moveTo(wx, wy + (p + 0.5) * (wh / 4))
          ctx.lineTo(wx + ww, wy + (p + 0.5) * (wh / 4) + (rnd() - 0.5) * 8)
          ctx.stroke()
        }
      }
      // soot above dark/burnt windows
      if (k < 0.2) {
        const g = ctx.createLinearGradient(0, wy, 0, wy - bay * 0.5)
        g.addColorStop(0, 'rgba(10,10,10,0.75)')
        g.addColorStop(1, 'rgba(10,10,10,0)')
        ctx.fillStyle = g
        ctx.fillRect(wx - 10, wy - bay * 0.45, ww + 20, bay * 0.45)
      }
      // streaks
      ctx.fillStyle = 'rgba(60,55,48,0.22)'
      ctx.fillRect(wx + rnd() * ww, wy + wh, 4 + rnd() * 6, bay * 0.5)
    }
  }
  return c
}
function canvasTex(c: HTMLCanvasElement, rep: number, srgb = true) {
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(1 / rep, 1 / rep)
  t.anisotropy = 8
  if (srgb) t.colorSpace = THREE.SRGBColorSpace
  return t
}

// ---------------------------------------------------------------------------
function Trees() {
  const data = useMemo(() => {
    const rnd = mulberry(42)
    const pts: { x: number; z: number; s: number; pine: boolean }[] = []
    const ok = (x: number, z: number) =>
      !(x > BOUNDS.x0 - 3 && x < BOUNDS.x1 + 3 && z > BOUNDS.z0 - 3 && z < BOUNDS.z1 + 3) && !(z > 43 && z < 60)
    let guard = 0
    while (pts.length < 110 && guard++ < 2000) {
      const a = rnd() * Math.PI * 2
      const d = 50 + rnd() * 70
      const x = -12 + Math.cos(a) * d * 1.15
      const z = 6 + Math.sin(a) * d
      if (!ok(x, z)) continue
      pts.push({ x, z, s: 0.75 + rnd() * 0.7, pine: rnd() < 0.35 })
    }
    // a few inside the compound
    for (const [x, z] of [[-56, 14], [-57, 2], [33, -25], [-38, -24], [-20, -25], [33, 38]] as [number, number][]) pts.push({ x, z, s: 0.7 + rnd() * 0.3, pine: false })
    // foliage geometry: cluster of jittered, smooth shaded icosahedrons
    const blobs: THREE.BufferGeometry[] = []
    const r2 = mulberry(7)
    const blob = (r: number, x: number, y: number, z: number, sy = 0.85) => {
      const base = new THREE.IcosahedronGeometry(r, 2)
      base.deleteAttribute('normal')
      base.deleteAttribute('uv')
      const g = mergeVertices(base)
      const p = g.attributes.position as THREE.BufferAttribute
      for (let k = 0; k < p.count; k++) {
        const f = 0.8 + r2() * 0.4
        p.setXYZ(k, p.getX(k) * f, p.getY(k) * f * sy, p.getZ(k) * f)
      }
      g.translate(x, y, z)
      blobs.push(g)
    }
    blob(1.15, 0, 1.15, 0)
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2 + r2() * 0.4
      blob(0.75 + r2() * 0.3, Math.cos(a) * 0.95, 0.35 + r2() * 1.0, Math.sin(a) * 0.95)
    }
    blob(0.8, 0.1, 2.0, -0.1)
    const leafGeo = mergeGeometries(blobs, false)
    leafGeo.computeVertexNormals()
    leafGeo.computeBoundingSphere()
    const pine = new CylBuilder()
    for (let k = 0; k < 4; k++) pine.add(new THREE.ConeGeometry(1.7 - k * 0.35, 2.2, 9).translate(0, k * 1.25, 0))
    const pineGeo = pine.geometry()
    return { pts, leafGeo, pineGeo }
  }, [])

  const meshes = useMemo(() => {
    const trunkMat = new THREE.MeshStandardMaterial({ color: '#4a3d31', roughness: 1 })
    const leafMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 })
    const pineMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 })
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 1, 7).translate(0, 0.5, 0)
    const decid = data.pts.filter((p) => !p.pine)
    const pines = data.pts.filter((p) => p.pine)
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, data.pts.length)
    const leaves = new THREE.InstancedMesh(data.leafGeo, leafMat, decid.length)
    const pineM = new THREE.InstancedMesh(data.pineGeo, pineMat, pines.length)
    const m4 = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    const col = new THREE.Color()
    const rnd = mulberry(5)
    data.pts.forEach((p, i) => {
      const h = (p.pine ? 3.2 : 3.6) * p.s
      m4.compose(new THREE.Vector3(p.x, 0, p.z), q, new THREE.Vector3(p.s, h, p.s))
      trunks.setMatrixAt(i, m4)
    })
    decid.forEach((p, i) => {
      q.setFromEuler(new THREE.Euler(0, rnd() * 6.28, 0))
      m4.compose(new THREE.Vector3(p.x, 3.4 * p.s, p.z), q, new THREE.Vector3(1.6 * p.s, 1.5 * p.s, 1.6 * p.s))
      leaves.setMatrixAt(i, m4)
      col.setHSL(0.19 + rnd() * 0.07, 0.3 + rnd() * 0.15, 0.11 + rnd() * 0.06)
      leaves.setColorAt(i, col)
    })
    pines.forEach((p, i) => {
      m4.compose(new THREE.Vector3(p.x, 2.0 * p.s, p.z), new THREE.Quaternion(), new THREE.Vector3(1.2 * p.s, 1.5 * p.s, 1.2 * p.s))
      pineM.setMatrixAt(i, m4)
      col.setHSL(0.3 + rnd() * 0.05, 0.25 + rnd() * 0.1, 0.08 + rnd() * 0.04)
      pineM.setColorAt(i, col)
    })
    for (const im of [trunks, leaves, pineM]) {
      im.castShadow = true
      im.receiveShadow = true
      im.computeBoundingSphere()
    }
    return { trunks, leaves, pineM }
  }, [data])
  return (
    <group>
      <primitive object={meshes.trunks} />
      <primitive object={meshes.leaves} />
      <primitive object={meshes.pineM} />
    </group>
  )
}

// ---------------------------------------------------------------------------
function carGeometry() {
  const s = new THREE.Shape()
  const pts: [number, number][] = [
    [-2.2, 0.32], [2.2, 0.32], [2.25, 0.62], [2.15, 0.9], [1.15, 0.98], [0.55, 1.44], [-0.95, 1.47], [-1.65, 1.0], [-2.22, 0.95], [-2.26, 0.6],
  ]
  pts.forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)))
  s.closePath()
  const g = new THREE.ExtrudeGeometry(s, { depth: 1.72, bevelEnabled: true, bevelSize: 0.05, bevelThickness: 0.05, bevelSegments: 2 })
  g.translate(0, 0, -0.86)
  g.computeVertexNormals()
  return g
}
function Car({ c, geo }: { c: (typeof CARS)[number]; geo: THREE.BufferGeometry }) {
  const m = useMaterials()
  const body = useMemo(() => {
    if (c.burnt) {
      const mm = m.rust.clone()
      mm.color.set('#5a4a40')
      return mm
    }
    return new THREE.MeshStandardMaterial({ color: c.color, roughness: 0.45, metalness: 0.55 })
  }, [c, m])
  const glass = useMemo(() => new THREE.MeshStandardMaterial({ color: '#0c0e10', roughness: 0.15, metalness: 0.6 }), [])
  return (
    <group position={[c.x, c.burnt ? -0.12 : 0, c.z]} rotation={[c.burnt ? 0.03 : 0, c.r, c.burnt ? 0.04 : 0]}>
      <mesh geometry={geo} material={body} castShadow receiveShadow />
      {/* windows */}
      {[-0.9, 0.9].map((z) => (
        <mesh key={z} position={[-0.2, 1.2, z * 0.985]} material={glass}>
          <boxGeometry args={[1.95, 0.36, 0.02]} />
        </mesh>
      ))}
      <mesh position={[0.86, 1.2, 0]} rotation={[0, 0, 0.68]} material={glass}>
        <boxGeometry args={[0.02, 0.62, 1.6]} />
      </mesh>
      <mesh position={[-1.32, 1.22, 0]} rotation={[0, 0, -0.6]} material={glass}>
        <boxGeometry args={[0.02, 0.5, 1.6]} />
      </mesh>
      {/* bumpers / lights */}
      <mesh position={[2.28, 0.5, 0]} material={m.metalDark} castShadow>
        <boxGeometry args={[0.12, 0.2, 1.8]} />
      </mesh>
      <mesh position={[-2.3, 0.5, 0]} material={m.metalDark} castShadow>
        <boxGeometry args={[0.12, 0.2, 1.8]} />
      </mesh>
      {[-1.42, 1.38].map((x) =>
        [-0.86, 0.86].map((z) => (
          <group key={`${x}${z}`} position={[x, 0.34, z]}>
            {!(c.burnt && x > 0 && z > 0) && (
              <mesh rotation={[Math.PI / 2, 0, 0]} material={m.black} castShadow>
                <cylinderGeometry args={[0.34, 0.34, 0.24, 18]} />
              </mesh>
            )}
            <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, z > 0 ? 0.12 : -0.12]} material={c.burnt ? m.rust : m.metal}>
              <cylinderGeometry args={[0.2, 0.2, 0.02, 14]} />
            </mesh>
          </group>
        )),
      )}
    </group>
  )
}

function Container({ c }: { c: (typeof CONTAINERS)[number] }) {
  const m = useMaterials()
  const mat = useMemo(() => {
    const mm = m.corrugatedRed.clone()
    mm.color.set(c.color)
    return mm
  }, [c, m])
  return (
    <group position={[c.x, c.y, c.z]} rotation={[0, c.r, 0]}>
      <mesh position={[0, 1.3, 0]} material={mat} castShadow receiveShadow>
        <boxGeometry args={[6.06, 2.5, 2.44]} />
      </mesh>
      {/* corner castings + rails */}
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => (
          <mesh key={`${sx}${sz}`} position={[sx * 2.98, 1.3, sz * 1.18]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.16, 2.6, 0.16]} />
          </mesh>
        )),
      )}
      {[0.06, 2.54].map((y) =>
        [-1, 1].map((sz) => (
          <mesh key={`${y}${sz}`} position={[0, y, sz * 1.18]} material={m.steelDark} castShadow>
            <boxGeometry args={[6.1, 0.14, 0.14]} />
          </mesh>
        )),
      )}
      {/* doors with locking bars */}
      {[-0.75, -0.3, 0.3, 0.75].map((z) => (
        <mesh key={z} position={[3.06, 1.3, z]} material={m.metal} castShadow>
          <cylinderGeometry args={[0.025, 0.025, 2.4, 6]} />
        </mesh>
      ))}
      <mesh position={[3.04, 1.3, 0]} material={m.steelDark}>
        <boxGeometry args={[0.03, 2.4, 0.04]} />
      </mesh>
    </group>
  )
}

function Jersey({ geo }: { geo: THREE.BufferGeometry }) {
  const m = useMaterials()
  const mat = useMemo(() => {
    const mm = m.concrete.clone()
    mm.color.set('#bdb8ae')
    return mm
  }, [m])
  return (
    <>
      {JERSEYS.map((j, i) => (
        <mesh key={i} geometry={geo} material={mat} position={[j.x, 0, j.z]} rotation={[0, j.r, 0]} castShadow receiveShadow />
      ))}
    </>
  )
}

// ---------------------------------------------------------------------------
export function Exterior() {
  const m = useMaterials()
  const carGeo = useMemo(() => carGeometry(), [])
  const jerseyGeo = useMemo(() => {
    const s = new THREE.Shape()
    ;[[-0.3, 0], [0.3, 0], [0.3, 0.08], [0.12, 0.3], [0.08, 0.82], [-0.08, 0.82], [-0.12, 0.3], [-0.3, 0.08]].forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)))
    s.closePath()
    const g = new THREE.ExtrudeGeometry(s, { depth: 3, bevelEnabled: false })
    g.translate(0, 0, -1.5)
    g.rotateY(Math.PI / 2)
    g.computeVertexNormals()
    return g
  }, [])

  const mats = useMemo(() => {
    const asphaltTex = canvasTex(makeAsphalt(), 6)
    const asphalt = new THREE.MeshStandardMaterial({ map: asphaltTex, color: '#9a9ea3', roughness: 0.92, bumpMap: asphaltTex, bumpScale: 0.45 })
    const facades = [101, 202, 303].map((s) => {
      const t = canvasTex(makeFacade(s), 12)
      return new THREE.MeshStandardMaterial({ map: t, roughness: 0.95 })
    })
    const paint = new THREE.MeshStandardMaterial({ color: '#d8c35a', roughness: 0.8 })
    const white = new THREE.MeshStandardMaterial({ color: '#d9d6cf', roughness: 0.8 })
    const wire = new THREE.MeshStandardMaterial({ color: '#4a4c4f', roughness: 0.5, metalness: 0.8 })
    const lampGlow = new THREE.MeshStandardMaterial({ color: '#fff5df', emissive: new THREE.Color('#ffefcf'), emissiveIntensity: 1.4 })
    const wallMat = m.concrete.clone()
    wallMat.color.set('#bab5ab')
    const sandbag = new THREE.MeshStandardMaterial({ color: '#8d7e5f', roughness: 1, map: m.tex.ground.map, normalMap: m.tex.ground.normal })
    const wood = new THREE.MeshStandardMaterial({ color: '#5b4a39', roughness: 1 })
    return { asphalt, facades, paint, white, wire, lampGlow, wallMat, sandbag, wood }
  }, [m])

  const geos = useMemo(() => {
    const rnd = mulberry(77)
    const { x0, x1, z0, z1 } = BOUNDS
    const wall = new GeoBuilder()
    const posts = new GeoBuilder()
    const steel = new GeoBuilder()
    const paint = new GeoBuilder()
    const white = new GeoBuilder()
    const sand = new GeoBuilder()
    const glow = new GeoBuilder()
    const wood = new GeoBuilder()
    const facade = [new GeoBuilder(), new GeoBuilder(), new GeoBuilder()]
    const roofCap = new GeoBuilder()
    const poles = new CylBuilder()
    const wires = new CylBuilder()

    // ---------------- perimeter wall ----------------
    const side = (ax: 'x' | 'z', fixed: number, a: number, b: number) => {
      for (let t = a; t < b - 0.01; t += 3) {
        const e = Math.min(b, t + 3)
        const c = (t + e) / 2
        const isGate = ax === 'x' && fixed === z1 && c > GATE.x0 && c < GATE.x1
        if (!isGate) {
          const h = WALL_H - (rnd() < 0.08 ? 0.6 + rnd() * 0.8 : 0)
          if (ax === 'x') wall.box(c, h / 2, fixed, e - t - 0.02, h, 0.22)
          else wall.box(fixed, h / 2, c, 0.22, h, e - t - 0.02)
        }
        if (ax === 'x') posts.box(t, (WALL_H + 0.3) / 2, fixed, 0.34, WALL_H + 0.3, 0.34)
        else posts.box(fixed, (WALL_H + 0.3) / 2, t, 0.34, WALL_H + 0.3, 0.34)
      }
    }
    side('x', z0, x0, x1)
    side('x', z1, x0, x1)
    side('z', x0, z0, z1)
    side('z', x1, z0, z1)
    posts.box(x1, (WALL_H + 0.3) / 2, z1, 0.34, WALL_H + 0.3, 0.34)
    // sliding steel gate
    {
      const gx = (GATE.x0 + GATE.x1) / 2
      const gw = GATE.x1 - GATE.x0
      steel.box(gx, 0.1, z1, gw, 0.08, 0.1)
      steel.box(gx, 2.6, z1, gw, 0.08, 0.1)
      steel.box(gx, 1.35, z1, gw, 0.06, 0.06)
      for (let i = 0; i <= 30; i++) steel.box(GATE.x0 + (i / 30) * gw, 1.35, z1, 0.035, 2.5, 0.035)
      paint.box(gx, 1.35, z1 - 0.06, 1.2, 0.5, 0.01)
    }

    // ---------------- guard booth ----------------
    {
      const { x, z } = BOOTH
      white.box(x, 0.55, z, 2.2, 1.1, 2.2)
      white.box(x - 1.05, 1.85, z, 0.1, 1.5, 2.2)
      white.box(x + 1.05, 1.85, z - 0.8, 0.1, 1.5, 0.6)
      white.box(x, 1.85, z + 1.05, 2.2, 1.5, 0.1)
      steel.box(x, 2.68, z, 2.6, 0.16, 2.6)
      steel.box(x + 1.05, 1.85, z + 0.25, 0.04, 1.4, 0.04)
      steel.box(x, 1.85, z - 1.05, 0.04, 1.4, 0.04)
    }
    // barrier arm at the gate
    paint.box(-7, 1.0, z1 - 1.2, 5.5, 0.1, 0.1)
    steel.box(-10.2, 0.5, z1 - 1.2, 0.3, 1.0, 0.3)

    // ---------------- watchtower ----------------
    {
      const { x, z } = TOWER
      for (const dx of [-1.6, 1.6]) for (const dz of [-1.6, 1.6]) wood.box(x + dx, 2.4, z + dz, 0.2, 4.8, 0.2)
      for (const dx of [-1.6, 1.6]) {
        wood.box(x + dx, 2.2, z, 0.08, 0.12, 3.6, 0, 0.75)
        wood.box(x, 2.2, z + dx, 3.6, 0.12, 0.08, 0, 0, 0.75)
      }
      wood.box(x, 4.55, z, 3.8, 0.15, 3.8)
      for (const s of [-1, 1]) {
        wood.box(x + s * 1.85, 5.15, z, 0.08, 1.05, 3.8)
        wood.box(x, 5.15, z + s * 1.85, 3.8, 1.05, 0.08)
      }
      for (const dx of [-1.75, 1.75]) for (const dz of [-1.75, 1.75]) wood.box(x + dx, 6.0, z + dz, 0.12, 2.8, 0.12)
      steel.box(x, 7.45, z, 4.4, 0.08, 4.4, 0, 0.06)
      for (let y = 0.4; y < 4.5; y += 0.35) wood.box(x + 1.95, y, z, 0.05, 0.05, 0.5)
      for (const dz of [-0.25, 0.25]) wood.box(x + 1.95, 2.3, z + dz, 0.06, 4.6, 0.06)
      for (let r = 0; r < 2; r++) for (let i = 0; i < 7; i++) sand.box(x - 1.5 + i * 0.5, 4.75 + r * 0.2, z + 1.65, 0.48, 0.2, 0.3, 0, 0, (i % 2) * 0.05)
    }

    // ---------------- sandbag walls ----------------
    for (const s of SANDBAGS) {
      const n = Math.round(s.len / 0.52)
      const c = Math.cos(s.r)
      const sn = Math.sin(s.r)
      for (let row = 0; row < 5; row++) {
        for (let i = 0; i < n - (row % 2); i++) {
          const u = -s.len / 2 + 0.26 + i * 0.52 + (row % 2) * 0.26
          const jitter = (rnd() - 0.5) * 0.1
          sand.box(s.x + c * u, 0.1 + row * 0.19, s.z - sn * u, 0.5, 0.2, 0.32 + (row < 2 ? 0.25 : 0), s.r + jitter)
        }
      }
    }

    // ---------------- yard markings ----------------
    for (let i = 0; i < 8; i++) paint.box(-34 + i * 3.2, 0.012, 33, 0.12, 0.004, 5)
    paint.box(-22.8, 0.012, 30.5, 25.6, 0.004, 0.12)
    for (const x of [-12, -2, 8]) {
      for (let k = 0; k < 6; k++) paint.box(x - 2.4 + k * 0.96, 0.012, HZ + 3.4, 0.5, 0.004, 0.12, 0.6)
    }

    // ---------------- light poles ----------------
    for (const [x, z] of POLES) {
      poles.cyl(x, 4, z, 0.09, 8, 10, 0, 0, 0.06)
      poles.cyl(x + 0.6, 7.9, z, 0.04, 1.3, 6, 0, Math.PI / 2)
      steel.box(x + 1.25, 7.85, z, 0.6, 0.14, 0.3)
      glow.box(x + 1.25, 7.77, z, 0.5, 0.02, 0.22)
      steel.box(x, 0.3, z, 0.5, 0.6, 0.5)
    }

    // ---------------- outside: road, power line, apartment blocks ----------------
    for (let x = -240; x < 240; x += 6) paint.box(x, 0.012, 51, 3, 0.004, 0.15)
    white.box(0, 0.06, 45.6, 480, 0.12, 1.2)
    white.box(0, 0.06, 56.4, 480, 0.12, 1.2)
    const poleXs: number[] = []
    for (let x = -200; x <= 200; x += 32) poleXs.push(x)
    for (const x of poleXs) {
      poles.cyl(x, 5, 58.5, 0.14, 10, 8, 0, 0, 0.18)
      wood.box(x, 9.4, 58.5, 0.12, 0.12, 2.2)
    }
    for (let i = 0; i < poleXs.length - 1; i++) {
      for (const dz of [-0.9, 0, 0.9]) {
        const a = new THREE.Vector3(poleXs[i], 9.5, 58.5 + dz)
        const b = new THREE.Vector3(poleXs[i + 1], 9.5, 58.5 + dz)
        const mid = a.clone().lerp(b, 0.5)
        mid.y -= 1.1
        const curve = new THREE.QuadraticBezierCurve3(a, mid, b)
        wires.add(new THREE.TubeGeometry(curve, 10, 0.012, 4, false))
      }
    }
    // apartment blocks
    const blocks: { x: number; z: number; w: number; d: number; h: number; r: number }[] = []
    let guard = 0
    while (blocks.length < 24 && guard++ < 600) {
      const a = rnd() * Math.PI * 2
      const dist = 95 + rnd() * 70
      const x = -12 + Math.cos(a) * dist * 1.2
      const z = 6 + Math.sin(a) * dist
      if (z > 40 && z < 66) continue
      const w = 18 + Math.floor(rnd() * 4) * 6
      const d = 12
      const h = 3 * (4 + Math.floor(rnd() * 6))
      if (blocks.some((b) => Math.hypot(b.x - x, b.z - z) < 34)) continue
      blocks.push({ x, z, w, d, h, r: Math.round((Math.atan2(z - 6, x + 12) + Math.PI / 2) / (Math.PI / 2)) * (Math.PI / 2) + (rnd() - 0.5) * 0.15 })
    }
    blocks.forEach((b, i) => {
      const fb = facade[i % 3]
      fb.box(b.x, b.h / 2, b.z, b.w, b.h, b.d, b.r)
      roofCap.box(b.x, b.h + 0.25, b.z, b.w + 0.3, 0.5, b.d + 0.3, b.r)
      // damaged blocks: a missing corner chunk replaced by a lower stump + rubble
      if (i % 4 === 1) {
        const c = Math.cos(b.r)
        const s = Math.sin(b.r)
        const off = b.w / 2 + 4
        fb.box(b.x + c * off, (b.h * 0.45) / 2, b.z - s * off, 8, b.h * 0.45, b.d, b.r)
        roofCap.box(b.x + c * (off + 5), 1.2, b.z - s * (off + 5), 6, 2.4, b.d * 0.9, b.r + 0.3)
      }
      // rooftop boxes
      roofCap.box(b.x, b.h + 1.3, b.z, 3, 2.1, 3, b.r)
    })
    return {
      wall: wall.geometry(),
      posts: posts.geometry(),
      steel: steel.geometry(),
      paint: paint.geometry(),
      white: white.geometry(),
      sand: sand.geometry(),
      glow: glow.geometry(),
      wood: wood.geometry(),
      facade: facade.map((f) => f.geometry()),
      roofCap: roofCap.geometry(),
      poles: poles.geometry(),
      wires: wires.geometry(),
    }
  }, [])

  // barbed wire coils on top of the perimeter wall
  const barbed = useMemo(() => {
    const { x0, x1, z0, z1 } = BOUNDS
    const list: THREE.Matrix4[] = []
    const add = (x: number, z: number, along: 'x' | 'z', k: number) => {
      const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(along === 'x' ? 0 : 0, along === 'x' ? Math.PI / 2 + 0.35 * Math.sin(k) : 0.35 * Math.sin(k), 0))
      list.push(new THREE.Matrix4().compose(new THREE.Vector3(x, WALL_H + 0.28, z), q, new THREE.Vector3(1, 1, 1)))
    }
    let k = 0
    for (let x = x0; x < x1; x += 0.32) {
      add(x, z0, 'x', k++)
      if (x < GATE.x0 - 0.3 || x > GATE.x1 + 0.3) add(x, z1, 'x', k++)
    }
    for (let z = z0; z < z1; z += 0.32) {
      add(x0, z, 'z', k++)
      add(x1, z, 'z', k++)
    }
    const im = new THREE.InstancedMesh(new THREE.TorusGeometry(0.27, 0.008, 4, 14), mats.wire, list.length)
    list.forEach((mm, i) => im.setMatrixAt(i, mm))
    im.computeBoundingSphere()
    return im
  }, [mats.wire])

  const ground = useMemo(() => floorGeometry(700, 700, 0, 0), [])
  const yard = useMemo(() => floorGeometry(BOUNDS.x1 - BOUNDS.x0, BOUNDS.z1 - HZ - 0.3, (BOUNDS.x0 + BOUNDS.x1) / 2, (BOUNDS.z1 + HZ + 0.3) / 2), [])
  const yardE = useMemo(() => floorGeometry(BOUNDS.x1 - HX - 0.3, HZ + 0.3 - BOUNDS.z0, (BOUNDS.x1 + HX + 0.3) / 2, (HZ + 0.3 + BOUNDS.z0) / 2), [])
  const road = useMemo(() => floorGeometry(480, 10.4, 0, 51), [])
  const walk = useMemo(() => floorGeometry(HOUSE.xMax - HOUSE.xMin, HZ - HOUSE.zMax, (HOUSE.xMin + HOUSE.xMax) / 2, (HZ + HOUSE.zMax) / 2), [])

  return (
    <group>
      <mesh geometry={ground} material={m.ground} position={[0, -0.015, 0]} receiveShadow />
      <mesh geometry={yard} material={mats.asphalt} position={[(BOUNDS.x0 + BOUNDS.x1) / 2, 0.002, (BOUNDS.z1 + HZ + 0.3) / 2]} receiveShadow />
      <mesh geometry={yardE} material={mats.asphalt} position={[(BOUNDS.x1 + HX + 0.3) / 2, 0.002, (HZ + 0.3 + BOUNDS.z0) / 2]} receiveShadow />
      <mesh geometry={walk} material={m.concreteFloor} position={[(HOUSE.xMin + HOUSE.xMax) / 2, 0.004, (HZ + HOUSE.zMax) / 2]} receiveShadow />
      <mesh geometry={road} material={mats.asphalt} position={[0, 0.003, 51]} receiveShadow />
      <Merged geo={geos.wall} mat={mats.wallMat} />
      <Merged geo={geos.posts} mat={m.concrete} />
      <Merged geo={geos.steel} mat={m.steelDark} />
      <Merged geo={geos.paint} mat={mats.paint} cast={false} />
      <Merged geo={geos.white} mat={mats.white} />
      <Merged geo={geos.sand} mat={mats.sandbag} />
      <Merged geo={geos.glow} mat={mats.lampGlow} cast={false} />
      <Merged geo={geos.wood} mat={mats.wood} />
      {geos.facade.map((g, i) => (
        <mesh key={i} geometry={g} material={mats.facades[i]} receiveShadow />
      ))}
      <Merged geo={geos.roofCap} mat={m.concrete} cast={false} />
      <Merged geo={geos.poles} mat={m.steel} />
      <Merged geo={geos.wires} mat={m.black} cast={false} />
      <primitive object={barbed} />
      <Trees />
      {CARS.map((c, i) => (
        <Car key={i} c={c} geo={carGeo} />
      ))}
      {CONTAINERS.map((c, i) => (
        <Container key={i} c={c} />
      ))}
      <Jersey geo={jerseyGeo} />
      {/* drums by the loading dock */}
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[16 + i * 0.7, 0.45, HZ + 2 + (i % 2) * 0.5]} material={i === 1 ? m.plasticBlue : m.rust} castShadow receiveShadow>
          <cylinderGeometry args={[0.3, 0.3, 0.9, 20]} />
        </mesh>
      ))}
    </group>
  )
}

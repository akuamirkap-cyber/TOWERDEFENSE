import { useMemo } from 'react'
import { EffectComposer, Bloom, ToneMapping, N8AO, BrightnessContrast, HueSaturation } from '@react-three/postprocessing'
import { ToneMappingMode } from 'postprocessing'
import { BodycamEffectImpl } from './BodycamEffect'
import type { Texture } from 'three'

/** Clean cinematic "tactical shooter" grade: no fisheye, light vignette, subtle grain + sharpening */
export function PostFX({ dirt }: { dirt: Texture }) {
  const lens = useMemo(
    () =>
      new BodycamEffectImpl({
        distortion: 0.0,
        aberration: 0.22,
        edgeBlur: 0.06,
        vignetteStart: 0.66,
        vignetteEnd: 1.5,
        grain: 0.026,
        sharpen: 0.3,
        dirt,
        dirtAmount: 0.1,
      }),
    [dirt],
  )
  return (
    <EffectComposer mergeMode="none" multisampling={4}>
      <N8AO aoRadius={1.35} intensity={3.1} distanceFalloff={0.75} quality="high" halfRes color="#000000" />
      <Bloom luminanceThreshold={0.95} luminanceSmoothing={0.3} intensity={0.55} mipmapBlur radius={0.7} levels={6} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <BrightnessContrast brightness={0.015} contrast={0.12} />
      <HueSaturation saturation={-0.02} />
      <primitive object={lens} />
    </EffectComposer>
  )
}

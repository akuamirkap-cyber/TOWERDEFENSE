import { useSyncExternalStore } from 'react'

export interface GameState {
  locked: boolean
  flashlight: boolean
  sprint: boolean
  crouch: boolean
  floor: number
  px: number
  pz: number
  heading: number
  exposure: number
  everStarted: boolean
  ammo: number
  reserve: number
  reloading: boolean
  ads: boolean
  hits: number
  botMode: 'follow' | 'stay'
  botX: number
  botZ: number
  barkText: string
  barkId: number
}

let state: GameState = {
  locked: false,
  flashlight: false,
  sprint: false,
  crouch: false,
  floor: 1,
  px: 0,
  pz: 0,
  heading: 0,
  exposure: 1,
  everStarted: false,
  ammo: 30,
  reserve: 210,
  reloading: false,
  ads: false,
  hits: 0,
  botMode: 'follow',
  botX: -24,
  botZ: 28.5,
  barkText: '',
  barkId: 0,
}

const listeners = new Set<() => void>()

export const store = {
  get: () => state,
  set: (partial: Partial<GameState>) => {
    let changed = false
    for (const k in partial) {
      if ((state as unknown as Record<string, unknown>)[k] !== (partial as Record<string, unknown>)[k]) {
        changed = true
        break
      }
    }
    if (!changed) return
    state = { ...state, ...partial }
    listeners.forEach((l) => l())
  },
  subscribe: (l: () => void) => {
    listeners.add(l)
    return () => {
      listeners.delete(l)
    }
  },
}

export function useGame<T>(selector: (s: GameState) => T): T {
  return useSyncExternalStore(store.subscribe, () => selector(state), () => selector(state))
}

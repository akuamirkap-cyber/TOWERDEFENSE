// ---------------------------------------------------------------------------
// SITE 14 – abandoned industrial hall + attached two storey manager's house.
// x: west(-) -> east(+)   z: north(-) -> south(+)   y: up   (metres)
// ---------------------------------------------------------------------------

export const HX = 20
export const HZ = 12
export const EAVE = 9.0
export const RIDGE = 10.4
export const EXT_T = 0.4
export const INT_T = 0.2
export const MEZZ_Y = 4.0
export const MEZZ_T = 0.25
export const MEZZ = { xMin: -HX, xMax: HX, zMin: -HZ, zMax: -7 }
export const CATWALK = { xMin: 17.6, xMax: HX, zMin: -7, zMax: 4.2 }
export const STAIRWELL = { xMin: 14, xMax: HX, zMin: 4.2, zMax: HZ }
export const OFFICE = { xMin: -16, xMax: -4, zMin: -HZ, zMax: -7, h: 3.75 }
export const SLOPE = (RIDGE - EAVE) / HZ

export function roofY(z: number) {
  return EAVE + (1 - Math.min(1, Math.abs(z) / HZ)) * (RIDGE - EAVE)
}

// ---------------- house (two storeys, west of the hall) ----------------
export const HOUSE = { xMin: -42, xMax: -20.2, zMin: -11, zMax: 3 }
export const H_T = 0.3
export const H_IT = 0.15
export const H_CEIL1 = 3.7
export const F2 = 4.0
export const H_CEIL2 = 7.0
export const H_ROOF = 7.3
export const HALL_W = -31.4
export const HALL_E = -26.6
export const H_STAIR = { xMin: -27.8, xMax: -26.6, zBottom: 1.2, steps: 22, run: 22 * 0.26, rise: F2 }
export const H_STAIR_Z_TOP = H_STAIR.zBottom - H_STAIR.run // -4.52
export const H_STAIR_HOLE = { xMin: -27.8, xMax: -26.6, zMin: H_STAIR_Z_TOP - 0.08, zMax: -1.4 }

function blob(cx: number, cz: number, rx: number, rz: number): [number, number][] {
  const pts: [number, number][] = []
  const n = 14
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2
    const jitter = 0.78 + 0.3 * Math.abs(Math.sin(i * 2.3) * Math.cos(i * 1.7))
    pts.push([cx + Math.cos(a) * rx * jitter, cz + Math.sin(a) * rz * jitter])
  }
  return pts
}
export const H_ROOF_HOLES: { x: number; z: number; poly: [number, number][] }[] = [
  { x: -34, z: -7.2, poly: blob(-34, -7.2, 1.6, 1.3) },
  {
    x: -23.4,
    z: -4.25,
    poly: [
      [-23.95, -4.8],
      [-22.85, -4.8],
      [-22.85, -3.7],
      [-23.95, -3.7],
    ],
  },
]

export type MatKey = 'wallPale' | 'wallPlaster' | 'wallStripe' | 'bath' | 'concrete' | 'brickWhite'
export type OpeningKind = 'door' | 'window' | 'hole' | 'rollup'

export interface Opening {
  at: number
  w: number
  b: number
  t: number
  kind: OpeningKind
  leaf?: 'open' | 'ajar' | 'none' | 'fallen' | 'closed'
  hinge?: 'left' | 'right'
  swing?: number
  flip?: boolean
  sunlit?: boolean
  rollup?: 'open' | 'half' | 'closed'
}

export interface WallDef {
  id: string
  axis: 'x' | 'z'
  x: number
  z: number
  u0: number
  len: number
  y: number
  h: number
  t: number
  matNeg: MatKey // face toward -z (x walls) / -x (z walls)
  matPos: MatKey // face toward +z / +x
  openings: Opening[]
  exterior?: boolean
  style?: 'house' | 'industrial'
  trim?: 'both' | 'neg' | 'pos'
}

const hwin = (at: number, w = 3, b = 6, t = 8.2, sunlit = false): Opening => ({ at, w, b, t, kind: 'window', sunlit })
const ewin = (at: number, sunlit = false): Opening => ({ at, w: 2.4, b: 5, t: 8, kind: 'window', sunlit })
const win = (at: number, w: number, b: number, t: number): Opening => ({ at, w, b, t, kind: 'window' })
const hw = (at: number, w = 1.4, b = 0.9, t = 2.5, sunlit = false): Opening => ({ at, w, b, t, kind: 'window', sunlit })
const door = (at: number, leaf: Opening['leaf'] = 'open', swing = 1.5, hinge: 'left' | 'right' = 'left', w = 0.95, t = 2.1): Opening => ({
  at,
  w,
  b: 0,
  t,
  kind: 'door',
  leaf,
  swing,
  hinge,
})
const hd = (at: number, leaf: Opening['leaf'] = 'open', swing = 1.4, hinge: 'left' | 'right' = 'left'): Opening => door(at, leaf, swing, hinge, 1.0, 2.1)
const rollup = (at: number, state: 'open' | 'half' | 'closed'): Opening => ({ at, w: 4, b: 0, t: 4.5, kind: 'rollup', rollup: state, sunlit: state !== 'closed' })

const W = (
  id: string,
  axis: 'x' | 'z',
  x: number,
  z: number,
  u0: number,
  len: number,
  y: number,
  h: number,
  t: number,
  matNeg: MatKey,
  matPos: MatKey,
  openings: Opening[],
  exterior = false,
): WallDef => ({ id, axis, x, z, u0, len, y, h, t, matNeg, matPos, openings, exterior, style: 'industrial' })

const HWx = (id: string, x: number, z: number, u0: number, len: number, y: number, h: number, t: number, matNeg: MatKey, matPos: MatKey, openings: Opening[], trim: WallDef['trim'], exterior = false): WallDef => ({
  id, axis: 'x', x, z, u0, len, y, h, t, matNeg, matPos, openings, exterior, style: 'house', trim,
})
const HWz = (id: string, x: number, z: number, u0: number, len: number, y: number, h: number, t: number, matNeg: MatKey, matPos: MatKey, openings: Opening[], trim: WallDef['trim'], exterior = false): WallDef => ({
  id, axis: 'z', x, z, u0, len, y, h, t, matNeg, matPos, openings, exterior, style: 'house', trim,
})

const HX0 = HOUSE.xMin
const G = [0, 4.0, H_T] as const // ground exterior: y, h, t
const U = [F2, H_ROOF - F2, H_T] as const
const GI = [0, H_CEIL1, H_IT] as const
const UI = [F2, H_CEIL2 - F2, H_IT] as const

export const WALLS: WallDef[] = [
  // ============ HALL – exterior shell ============
  W('S', 'x', -HX, HZ, 0, 40, 0, EAVE, EXT_T, 'wallPale', 'brickWhite', [
    rollup(8, 'open'),
    rollup(18, 'half'),
    rollup(28, 'closed'),
    hwin(4, 3, 6, 8.2, true),
    hwin(13, 3, 6, 8.2, true),
    hwin(23, 3, 6, 8.2, true),
    hwin(33, 3, 6, 8.2, true),
    hwin(38, 3, 6, 8.2, true),
    { ...door(35, 'ajar', 0.5, 'left', 1.0, 2.2), sunlit: true },
  ], true),
  W('N', 'x', -HX, -HZ, 0, 40, 0, EAVE, EXT_T, 'brickWhite', 'wallPale', [hwin(3), hwin(8), hwin(13), hwin(18), hwin(23), hwin(28), hwin(33), hwin(37.5, 2.4)], true),
  W('E', 'z', HX, -HZ, 0, 24, 0, EAVE, EXT_T, 'wallPale', 'brickWhite', [ewin(2.5, true), ewin(8, true), ewin(13, true), ewin(20, true), { ...door(10, 'open', 1.4, 'left', 1.2, 2.4), sunlit: true }], true),
  // west wall: shared with the house (z -12..3) + exterior part (z 3..12)
  {
    id: 'Wst-a', axis: 'z', x: -HX, z: -HZ, u0: 0, len: 15, y: 0, h: EAVE, t: EXT_T, matNeg: 'wallPlaster', matPos: 'wallPale', style: 'house',
    openings: [
      { at: 2.2, w: 2.2, b: 0, t: 2.6, kind: 'hole' },
      door(4.5, 'open', 1.4, 'left', 1.1, 2.2),
      door(12.8, 'ajar', 0.5, 'left', 1.1, 2.2),
      { at: 3.5, w: 1.3, b: MEZZ_Y, t: MEZZ_Y + 2.2, kind: 'door', leaf: 'none' },
    ],
  },
  W('Wst-b', 'z', -HX, -HZ, 15, 9, 0, EAVE, EXT_T, 'brickWhite', 'wallPale', [ewin(20)], true),

  // ============ HALL – stairwell (SE corner) ============
  W('sw-W', 'z', 14, 4.2, 0, 7.8, 0, EAVE, INT_T, 'wallPale', 'wallPlaster', [door(3.3, 'none', 0, 'left', 1.1, 2.2)]),
  W('sw-N', 'x', 14, 4.2, 0, 6, 0, EAVE, INT_T, 'wallPale', 'wallPlaster', [
    { at: 5.1, w: 1.3, b: MEZZ_Y, t: MEZZ_Y + 2.2, kind: 'door', leaf: 'none' },
    door(2.5, 'none', 0, 'left', 1.1, 2.2),
  ]),

  // ============ HALL – offices under the mezzanine ============
  W('of-front', 'x', -16, -7, 0, 12, 0, OFFICE.h, INT_T, 'wallPale', 'wallPlaster', [
    door(1.0, 'open', 1.3, 'left'),
    win(2.9, 1.5, 1.0, 2.3),
    door(5.0, 'ajar', 0.45, 'left'),
    win(6.9, 1.5, 1.0, 2.3),
    door(9.0, 'none'),
    win(10.9, 1.5, 1.0, 2.3),
  ]),
  W('of-p0', 'z', -16, -11.8, 0, 4.9, 0, OFFICE.h, INT_T, 'wallPale', 'wallPlaster', []),
  W('of-p1', 'z', -12, -11.8, 0, 4.9, 0, OFFICE.h, INT_T, 'wallPlaster', 'wallPlaster', [door(2.4, 'open', 1.2, 'left')]),
  W('of-p2', 'z', -8, -11.8, 0, 4.9, 0, OFFICE.h, INT_T, 'wallPlaster', 'wallPlaster', []),
  W('of-p3', 'z', -4, -11.8, 0, 4.9, 0, OFFICE.h, INT_T, 'wallPlaster', 'wallPale', []),

  // ============ HOUSE – exterior ground floor ============
  HWx('hS-lib', HX0, 3, 0, 5.3, ...G, 'wallPlaster', 'brickWhite', [hw(2.6, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hS-liv', HX0, 3, 5.3, 5.3, ...G, 'wallStripe', 'brickWhite', [hw(6.9, 1.4, 0.9, 2.5, true), hw(9.0, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hS-hall', HX0, 3, 10.6, 4.8, ...G, 'wallStripe', 'brickWhite', [{ ...door(13, 'open', 1.7, 'left', 1.1, 2.3), sunlit: true }], 'neg', true),
  HWx('hS-din', HX0, 3, 15.4, 6.4, ...G, 'wallPlaster', 'brickWhite', [hw(17, 1.4, 0.9, 2.5, true), hw(20, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hN-lau', HX0, -11, 0, 5.3, ...G, 'brickWhite', 'wallPale', [hw(2.6, 1.4, 1.0, 2.5)], 'pos', true),
  HWx('hN-kit', HX0, -11, 5.3, 5.3, ...G, 'brickWhite', 'wallPale', [hw(8, 1.6, 1.0, 2.4)], 'pos', true),
  HWx('hN-hall', HX0, -11, 10.6, 4.8, ...G, 'brickWhite', 'wallStripe', [door(13, 'ajar', 0.5, 'left', 1.1, 2.3)], 'pos', true),
  HWx('hN-back', HX0, -11, 15.4, 6.4, ...G, 'brickWhite', 'wallPale', [hw(17, 1.2, 1.0, 2.5), hw(20.5, 1.2, 1.0, 2.5)], 'pos', true),
  HWz('hW-lau', HX0, -11, 0, 4, ...G, 'brickWhite', 'wallPale', [hw(2, 1.4, 1.0, 2.5)], 'pos', true),
  HWz('hW-pan', HX0, -11, 4, 3.5, ...G, 'brickWhite', 'wallPale', [hw(5.8, 1.4, 1.0, 2.5)], 'pos', true),
  HWz('hW-lib', HX0, -11, 7.5, 6.5, ...G, 'brickWhite', 'wallPlaster', [hw(11, 1.4, 0.9, 2.5)], 'pos', true),
  // ============ HOUSE – exterior upper floor ============
  HWx('hS2-bed2', HX0, 3, 0, 5.3, ...U, 'wallStripe', 'brickWhite', [hw(2.6, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hS2-bed1', HX0, 3, 5.3, 5.3, ...U, 'wallStripe', 'brickWhite', [hw(6.9, 1.4, 0.9, 2.5, true), hw(9.0, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hS2-land', HX0, 3, 10.6, 4.8, ...U, 'wallStripe', 'brickWhite', [hw(13, 1.2, 0.9, 2.5, true)], 'neg', true),
  HWx('hS2-bed5', HX0, 3, 15.4, 6.4, ...U, 'wallStripe', 'brickWhite', [hw(17, 1.4, 0.9, 2.5, true), hw(20, 1.4, 0.9, 2.5, true)], 'neg', true),
  HWx('hN2-box', HX0, -11, 0, 5.3, ...U, 'brickWhite', 'wallPlaster', [hw(2.6, 1.4, 1.0, 2.5)], 'pos', true),
  HWx('hN2-bed4', HX0, -11, 5.3, 5.3, ...U, 'brickWhite', 'wallPale', [hw(8, 1.6, 1.0, 2.4)], 'pos', true),
  HWx('hN2-land', HX0, -11, 10.6, 4.8, ...U, 'brickWhite', 'wallStripe', [hw(13, 1.2, 1.0, 2.5)], 'pos', true),
  HWx('hN2-bed6', HX0, -11, 15.4, 6.4, ...U, 'brickWhite', 'wallStripe', [hw(17, 1.2, 1.0, 2.5), hw(20.5, 1.2, 1.0, 2.5)], 'pos', true),
  HWz('hW2-box', HX0, -11, 0, 4, ...U, 'brickWhite', 'wallPlaster', [hw(2, 1.4, 1.0, 2.5)], 'pos', true),
  HWz('hW2-nur', HX0, -11, 4, 3.5, ...U, 'brickWhite', 'wallStripe', [hw(5.8, 1.4, 1.0, 2.5)], 'pos', true),
  HWz('hW2-bed2', HX0, -11, 7.5, 6.5, ...U, 'brickWhite', 'wallStripe', [hw(11, 1.4, 0.9, 2.5)], 'pos', true),

  // ============ HOUSE – interior ground floor ============
  HWz('hHallW-N', HALL_W, -11, 0, 7.5, ...GI, 'wallPale', 'wallStripe', [hd(2.3, 'open', 1.4)], 'both'),
  HWz('hHallW-S', HALL_W, -11, 7.5, 6.5, ...GI, 'wallStripe', 'wallStripe', [hd(11.7, 'ajar', 0.6, 'right')], 'both'),
  HWz('hHallE-N', HALL_E, -11, 0, 5.5, ...GI, 'wallStripe', 'wallPale', [hd(3, 'open', 1.3)], 'both'),
  HWz('hHallE-M', HALL_E, -11, 5.5, 3, ...GI, 'wallStripe', 'wallPlaster', [], 'both'),
  HWz('hHallE-S', HALL_E, -11, 8.5, 5.5, ...GI, 'wallStripe', 'wallPlaster', [hd(13, 'open', 1.5, 'right')], 'both'),
  HWz('hMidW-N', -36.7, -11, 0, 4, ...GI, 'wallPale', 'wallPale', [hd(2, 'open', 1.2)], 'both'),
  HWz('hMidW-M', -36.7, -11, 4, 3.5, ...GI, 'wallPale', 'wallPale', [hd(5.8, 'ajar', 0.5)], 'both'),
  HWz('hMidW-S', -36.7, -11, 7.5, 6.5, ...GI, 'wallPlaster', 'wallStripe', [hd(11, 'open', 1.6)], 'both'),
  HWx('hRowA-W', HX0, -3.5, 0, 5.3, ...GI, 'wallPale', 'wallPlaster', [hd(2.6, 'open', 1.3)], 'both'),
  HWx('hRowA-E', HX0, -3.5, 5.3, 5.3, ...GI, 'wallPale', 'wallStripe', [hd(8, 'none', 0)], 'both'),
  HWx('hRowB', HX0, -7, 0, 5.3, ...GI, 'wallPale', 'wallPale', [hd(2.6, 'open', 1.4, 'right')], 'both'),
  HWx('hEastA', HALL_E, -2.5, 0, 6.4, ...GI, 'wallPlaster', 'wallPlaster', [], 'both'),
  HWx('hEastB', HALL_E, -5.5, 0, 6.4, ...GI, 'wallPale', 'wallPlaster', [door(1.5, 'ajar', 0.6, 'left', 0.9, 2.1), hd(4.7, 'open', 1.4)], 'both'),
  HWz('hWCst', -23.6, -5.5, 0, 3, ...GI, 'wallPlaster', 'wallPlaster', [], 'both'),
  // ============ HOUSE – interior upper floor ============
  HWz('hHallW2-N', HALL_W, -11, 0, 7.5, ...UI, 'wallPale', 'wallStripe', [hd(2.3, 'open', 1.2, 'right')], 'both'),
  HWz('hHallW2-S', HALL_W, -11, 7.5, 6.5, ...UI, 'wallStripe', 'wallStripe', [hd(11.7, 'open', 1.5)], 'both'),
  HWz('hHallE2-N', HALL_E, -11, 0, 5, ...UI, 'wallStripe', 'wallStripe', [hd(2.5, 'open', 1.4)], 'both'),
  HWz('hHallE2-M', HALL_E, -11, 5, 3.5, ...UI, 'wallStripe', 'bath', [door(5.6, 'ajar', 0.5, 'right', 0.9, 2.1)], 'both'),
  HWz('hHallE2-S', HALL_E, -11, 8.5, 5.5, ...UI, 'wallStripe', 'wallStripe', [hd(13, 'none', 0)], 'both'),
  HWz('hMidW2-N', -36.7, -11, 0, 4, ...UI, 'wallPlaster', 'wallPale', [hd(2, 'open', 1.3)], 'both'),
  HWz('hMidW2-M', -36.7, -11, 4, 3.5, ...UI, 'wallStripe', 'wallPale', [hd(5.8, 'open', 1.4, 'right')], 'both'),
  HWz('hMidW2-S', -36.7, -11, 7.5, 6.5, ...UI, 'wallStripe', 'wallStripe', [hd(11.7, 'ajar', 0.6)], 'both'),
  HWx('hRowA2-W', HX0, -3.5, 0, 5.3, ...UI, 'wallStripe', 'wallStripe', [hd(2.6, 'open', 1.3)], 'both'),
  HWx('hRowA2-E', HX0, -3.5, 5.3, 5.3, ...UI, 'wallPale', 'wallStripe', [hd(8, 'fallen', 0)], 'both'),
  HWx('hRowB2', HX0, -7, 0, 5.3, ...UI, 'wallPlaster', 'wallStripe', [hd(2.6, 'open', 1.5)], 'both'),
  HWx('hEastA2', HALL_E, -2.5, 0, 6.4, ...UI, 'bath', 'wallStripe', [], 'both'),
  HWx('hEastB2', HALL_E, -6, 0, 6.4, ...UI, 'wallStripe', 'bath', [], 'both'),
]

// ---------------------------------------------------------------------------
// Roof panels of the hall
export const PANEL_W = 2.5
export const PANEL_D = 3
export const PANEL_COLS = 16
export const PANEL_ROWS = 8
export type PanelState = 'ok' | 'missing' | 'hanging' | 'skylight' | 'skylightMissing'
export interface RoofPanel {
  i: number
  j: number
  x0: number
  x1: number
  z0: number
  z1: number
  state: PanelState
}

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export const ROOF_PANELS: RoofPanel[] = (() => {
  const rnd = mulberry(2024)
  const out: RoofPanel[] = []
  for (let j = 0; j < PANEL_ROWS; j++) {
    for (let i = 0; i < PANEL_COLS; i++) {
      const x0 = -HX + i * PANEL_W
      const z0 = -HZ + j * PANEL_D
      const skylight = j === 3 || j === 4
      let state: PanelState = skylight ? 'skylight' : 'ok'
      const r = rnd()
      const centre = i >= 5 && i <= 10 && j >= 2 && j <= 5
      const stairwell = i >= 14 && j >= 6
      const p = skylight ? 0.38 : centre ? 0.34 : 0.17
      if (stairwell) state = i === 14 && j === 6 ? 'hanging' : 'missing'
      else if (r < p) state = skylight ? 'skylightMissing' : rnd() < 0.3 ? 'hanging' : 'missing'
      out.push({ i, j, x0, x1: x0 + PANEL_W, z0, z1: z0 + PANEL_D, state })
    }
  }
  for (const p of out) if (p.j === 0 && p.i <= 6 && p.state !== 'ok') p.state = 'ok'
  return out
})()

export const SUN_DIR = (() => {
  const el = (52 * Math.PI) / 180
  const az = (32 * Math.PI) / 180
  const h = Math.cos(el)
  const v = [-h * Math.sin(az), -Math.sin(el), -h * Math.cos(az)]
  const l = Math.hypot(v[0], v[1], v[2])
  return { x: v[0] / l, y: v[1] / l, z: v[2] / l }
})()
export const SUN_POS = { x: -SUN_DIR.x * 70, y: -SUN_DIR.y * 70, z: -SUN_DIR.z * 70 }

// ---------------------------------------------------------------------------
// Walkable platforms and ramps
export interface Platform {
  xMin: number
  xMax: number
  zMin: number
  zMax: number
  y: number
  holes?: { xMin: number; xMax: number; zMin: number; zMax: number }[]
}
export interface Ramp {
  xMin: number
  xMax: number
  z0: number
  z1: number
  h0: number
  h1: number
}

export const PLATFORMS: Platform[] = [
  { xMin: -HX, xMax: HX, zMin: -HZ, zMax: -7, y: MEZZ_Y },
  { xMin: CATWALK.xMin, xMax: HX, zMin: -7, zMax: 4.2, y: MEZZ_Y },
  { xMin: 15.4, xMax: 19.8, zMin: 10.4, zMax: 11.8, y: 2 },
  { xMin: 16.6, xMax: 19.8, zMin: 3.9, zMax: 5.2, y: MEZZ_Y },
  { xMin: HOUSE.xMin + 0.2, xMax: -19.8, zMin: HOUSE.zMin + 0.2, zMax: HOUSE.zMax - 0.2, y: F2, holes: [H_STAIR_HOLE] },
]
export const RAMPS: Ramp[] = [
  { xMin: -19.6, xMax: -18.4, z0: -1, z1: -7, h0: 0, h1: MEZZ_Y }, // west steel stair (hall)
  { xMin: 15.9, xMax: 17.1, z0: 5.2, z1: 10.4, h0: 0, h1: 2 }, // stairwell flight A
  { xMin: 18.6, xMax: 19.8, z0: 10.4, z1: 5.2, h0: 2, h1: MEZZ_Y }, // stairwell flight B
  { xMin: H_STAIR.xMin, xMax: H_STAIR.xMax, z0: H_STAIR.zBottom, z1: H_STAIR_Z_TOP, h0: 0, h1: F2 }, // house stair
]

export function rampHeight(r: Ramp, z: number) {
  const t = Math.min(1, Math.max(0, (z - r.z0) / (r.z1 - r.z0)))
  return r.h0 + (r.h1 - r.h0) * t
}
function inRamp(r: Ramp, x: number, z: number) {
  const zMin = Math.min(r.z0, r.z1) - 0.12
  const zMax = Math.max(r.z0, r.z1) + 0.12
  return x >= r.xMin - 0.05 && x <= r.xMax + 0.05 && z >= zMin && z <= zMax
}

/** Highest walkable platform/ramp at (x,z) reachable from currentY */
export function floorHeightAt(x: number, z: number, currentY: number) {
  let best = 0
  const consider = (h: number) => {
    if (h <= currentY + 0.6 && h > best) best = h
  }
  for (const p of PLATFORMS) {
    if (x < p.xMin || x > p.xMax || z < p.zMin || z > p.zMax) continue
    if (p.holes && p.holes.some((h) => x > h.xMin && x < h.xMax && z > h.zMin && z < h.zMax)) continue
    consider(p.y)
  }
  for (const r of RAMPS) if (inRamp(r, x, z)) consider(rampHeight(r, z))
  return best
}

export function insideFootprint(x: number, z: number) {
  if (Math.abs(x) < HX && Math.abs(z) < HZ) return true
  return x > HOUSE.xMin && x < HOUSE.xMax && z > HOUSE.zMin && z < HOUSE.zMax
}

// ---------------------------------------------------------------------------
// Colliders
export interface AABB {
  minX: number
  maxX: number
  minZ: number
  maxZ: number
  minY: number
  maxY: number
}
export function boxCollider(cx: number, cz: number, w: number, d: number, y0: number, y1: number): AABB {
  return { minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2, minY: y0, maxY: y1 }
}
const thinX = (x: number, z0: number, z1: number, y0: number, y1: number): AABB => ({ minX: x - 0.05, maxX: x + 0.05, minZ: Math.min(z0, z1), maxZ: Math.max(z0, z1), minY: y0, maxY: y1 })
const thinZ = (z: number, x0: number, x1: number, y0: number, y1: number): AABB => ({ minZ: z - 0.05, maxZ: z + 0.05, minX: Math.min(x0, x1), maxX: Math.max(x0, x1), minY: y0, maxY: y1 })

/** blocks walking under the low part of a stair flight (tops stay below the feet of people on the flight) */
function underRamp(r: Ramp, maxClear = 2.4): AABB[] {
  const out: AABB[] = []
  const zMin = Math.min(r.z0, r.z1)
  const zMax = Math.max(r.z0, r.z1)
  const step = 0.6
  for (let z = zMin; z < zMax - 0.01; z += step) {
    const zEnd = Math.min(zMax, z + step)
    const hMin = Math.min(rampHeight(r, z), rampHeight(r, zEnd))
    if (hMin < 0.85 || hMin > maxClear) continue
    out.push({ minX: r.xMin, maxX: r.xMax, minZ: z, maxZ: zEnd, minY: 0, maxY: hMin - 0.35 })
  }
  return out
}

export function wallColliders(): AABB[] {
  const out: AABB[] = []
  for (const w of WALLS) {
    const gaps = w.openings
      .filter((o) => o.kind === 'door' || (o.kind === 'hole' && o.b < 0.4) || (o.kind === 'rollup' && o.rollup !== 'closed'))
      .sort((a, b) => a.at - b.at)
    const segs: [number, number][] = []
    let cur = w.u0
    for (const g of gaps) {
      segs.push([cur, g.at - g.w / 2])
      cur = g.at + g.w / 2
      if (g.b > 0.3) {
        if (w.axis === 'x') out.push({ minX: w.x + g.at - g.w / 2, maxX: w.x + g.at + g.w / 2, minZ: w.z - w.t / 2, maxZ: w.z + w.t / 2, minY: w.y, maxY: w.y + g.b })
        else out.push({ minZ: w.z + g.at - g.w / 2, maxZ: w.z + g.at + g.w / 2, minX: w.x - w.t / 2, maxX: w.x + w.t / 2, minY: w.y, maxY: w.y + g.b })
      }
    }
    segs.push([cur, w.u0 + w.len])
    for (const [s0, s1] of segs) {
      if (s1 - s0 <= 0.001) continue
      if (w.axis === 'x') out.push({ minX: w.x + s0, maxX: w.x + s1, minZ: w.z - w.t / 2, maxZ: w.z + w.t / 2, minY: w.y, maxY: w.y + w.h })
      else out.push({ minZ: w.z + s0, maxZ: w.z + s1, minX: w.x - w.t / 2, maxX: w.x + w.t / 2, minY: w.y, maxY: w.y + w.h })
    }
  }
  const Y = MEZZ_Y
  // mezzanine + catwalk railings
  out.push(thinZ(-7, -18.4, CATWALK.xMin, Y, Y + 1.3))
  out.push(thinX(CATWALK.xMin, -7, 4.2, Y, Y + 1.3))
  // west steel stair
  out.push(thinX(-18.4, -1, -7.1, 0, 5.4))
  out.push(...underRamp(RAMPS[0]))
  // stairwell
  out.push(thinX(15.9, 5.2, 10.4, 0, 3.3))
  out.push(thinX(17.1, 5.2, 10.4, 0, 3.3))
  out.push(...underRamp(RAMPS[1]))
  out.push({ minX: 15.4, maxX: 19.8, minZ: 10.4, maxZ: 11.8, minY: 0, maxY: 1.8 })
  out.push(thinZ(10.4, 17.1, 18.6, 2, 3.3))
  out.push(thinX(15.4, 10.4, 11.8, 2, 3.3))
  out.push(thinX(18.6, 5.2, 10.4, 2, 5.4))
  out.push(...underRamp(RAMPS[2]))
  out.push(thinZ(5.2, 16.6, 18.6, Y, Y + 1.3))
  out.push(thinX(16.6, 3.9, 5.2, Y, Y + 1.3))
  // house stair: spandrel/banister on the open side, closet at the top end, balustrade upstairs
  out.push(thinX(H_STAIR.xMin, H_STAIR_Z_TOP, H_STAIR.zBottom, 0, 5.0))
  out.push({ minX: H_STAIR.xMin, maxX: H_STAIR.xMax, minZ: H_STAIR_Z_TOP - 0.1, maxZ: H_STAIR_Z_TOP + 0.1, minY: 0, maxY: H_CEIL1 })
  out.push(thinX(H_STAIR_HOLE.xMin, H_STAIR_HOLE.zMin, H_STAIR_HOLE.zMax, F2, F2 + 1.3))
  out.push(thinZ(H_STAIR_HOLE.zMax, H_STAIR_HOLE.xMin, H_STAIR_HOLE.xMax, F2, F2 + 1.3))
  // structural columns
  for (const [cx, cz] of COLUMNS) out.push(boxCollider(cx, cz, 0.5, 0.5, 0, 9))
  for (const [cx, cz] of MEZZ_POSTS) out.push(boxCollider(cx, cz, 0.3, 0.3, 0, Y))
  return out
}

export const COLUMNS: [number, number][] = [
  [-12, -4],
  [-4, -4],
  [4, -4],
  [12, -4],
  [-12, 4],
  [-4, 4],
  [4, 4],
  [12, 4],
]
export const MEZZ_POSTS: [number, number][] = [
  [-4, -7],
  [2, -7],
  [8, -7],
  [14, -7],
  [17.6, -2.5],
  [17.6, 1.5],
]

// ---------------------------------------------------------------------------
// Bright light sources for the fake auto-exposure
export interface BrightSource {
  x: number
  y: number
  z: number
  power: number
  nx: number
  nz: number
}

export function brightSources(): BrightSource[] {
  const out: BrightSource[] = []
  for (const w of WALLS) {
    if (!w.exterior) continue
    for (const o of w.openings) {
      if (o.kind === 'rollup' && o.rollup === 'closed') continue
      const top = o.kind === 'rollup' && o.rollup === 'half' ? 2.0 : o.t
      const cy = w.y + (o.b + top) / 2
      const area = o.w * (top - o.b)
      const power = area * (o.sunlit ? 0.32 : 0.18)
      if (w.axis === 'x') out.push({ x: w.x + o.at, y: cy, z: w.z, power, nx: 0, nz: w.z > 0 ? -1 : 1 })
      else out.push({ x: w.x, y: cy, z: w.z + o.at, power, nx: w.x > 0 ? -1 : 1, nz: 0 })
    }
  }
  for (const p of ROOF_PANELS) {
    if (p.state === 'ok') continue
    const open = p.state === 'missing' || p.state === 'skylightMissing' ? 1 : p.state === 'hanging' ? 0.6 : 0.35
    out.push({ x: (p.x0 + p.x1) / 2, y: roofY((p.z0 + p.z1) / 2), z: (p.z0 + p.z1) / 2, power: PANEL_W * PANEL_D * open * 0.16, nx: 0, nz: 0 })
  }
  for (const h of H_ROOF_HOLES) out.push({ x: h.x, y: H_CEIL2, z: h.z, power: 1.6, nx: 0, nz: 0 })
  return out
}

// Regions for debris distribution
export interface Room {
  id: string
  xMin: number
  xMax: number
  zMin: number
  zMax: number
  y: number
  floor: 'wood' | 'concrete'
  density: number
}
export const ROOMS: Room[] = [
  { id: 'hall', xMin: -19.4, xMax: 13.6, zMin: -6.6, zMax: 11.5, y: 0, floor: 'concrete', density: 1 },
  { id: 'hallSE', xMin: 13.6, xMax: 19.5, zMin: -6.6, zMax: 3.9, y: 0, floor: 'concrete', density: 1 },
  { id: 'underDeck', xMin: -3.6, xMax: 19.5, zMin: -11.5, zMax: -7.3, y: 0, floor: 'concrete', density: 1.3 },
  { id: 'westNook', xMin: -19.4, xMax: -16.3, zMin: -11.5, zMax: -7.3, y: 0, floor: 'concrete', density: 1.5 },
  { id: 'office0', xMin: -15.7, xMax: -12.3, zMin: -11.5, zMax: -7.4, y: 0, floor: 'concrete', density: 1.2 },
  { id: 'office1', xMin: -11.7, xMax: -8.3, zMin: -11.5, zMax: -7.4, y: 0, floor: 'concrete', density: 1.0 },
  { id: 'office2', xMin: -7.7, xMax: -4.3, zMin: -11.5, zMax: -7.4, y: 0, floor: 'concrete', density: 1.4 },
  { id: 'stairwell', xMin: 14.3, xMax: 19.6, zMin: 4.5, zMax: 11.6, y: 0, floor: 'concrete', density: 1.6 },
  { id: 'mezz', xMin: -19.4, xMax: 19.5, zMin: -11.5, zMax: -7.3, y: MEZZ_Y, floor: 'concrete', density: 0.9 },
  { id: 'catwalk', xMin: 17.9, xMax: 19.6, zMin: -7, zMax: 4, y: MEZZ_Y, floor: 'concrete', density: 0.7 },
  // house ground
  { id: 'hHall', xMin: -31.1, xMax: -28.0, zMin: -10.7, zMax: 2.7, y: 0, floor: 'wood', density: 1.0 },
  { id: 'living', xMin: -36.4, xMax: -31.7, zMin: -3.2, zMax: 2.7, y: 0, floor: 'wood', density: 0.8 },
  { id: 'library', xMin: -41.7, xMax: -37.0, zMin: -3.2, zMax: 2.7, y: 0, floor: 'wood', density: 0.8 },
  { id: 'kitchen', xMin: -36.4, xMax: -31.7, zMin: -10.7, zMax: -3.8, y: 0, floor: 'concrete', density: 1.1 },
  { id: 'pantry', xMin: -41.7, xMax: -37.0, zMin: -6.7, zMax: -3.8, y: 0, floor: 'concrete', density: 1.0 },
  { id: 'laundry', xMin: -41.7, xMax: -37.0, zMin: -10.7, zMax: -7.3, y: 0, floor: 'concrete', density: 1.0 },
  { id: 'dining', xMin: -26.3, xMax: -20.5, zMin: -2.2, zMax: 2.7, y: 0, floor: 'wood', density: 0.8 },
  { id: 'wc', xMin: -26.3, xMax: -23.9, zMin: -5.2, zMax: -2.8, y: 0, floor: 'concrete', density: 0.6 },
  { id: 'storage', xMin: -23.3, xMax: -20.5, zMin: -5.2, zMax: -2.8, y: 0, floor: 'concrete', density: 1.0 },
  { id: 'back', xMin: -26.3, xMax: -20.5, zMin: -10.7, zMax: -5.8, y: 0, floor: 'concrete', density: 1.3 },
  // house upper
  { id: 'landing', xMin: -31.1, xMax: -28.0, zMin: -10.7, zMax: 2.7, y: F2, floor: 'wood', density: 0.9 },
  { id: 'bed1', xMin: -36.4, xMax: -31.7, zMin: -3.2, zMax: 2.7, y: F2, floor: 'wood', density: 0.8 },
  { id: 'bed2', xMin: -41.7, xMax: -37.0, zMin: -3.2, zMax: 2.7, y: F2, floor: 'wood', density: 0.7 },
  { id: 'bed4', xMin: -36.4, xMax: -31.7, zMin: -10.7, zMax: -3.8, y: F2, floor: 'wood', density: 2.0 },
  { id: 'nursery', xMin: -41.7, xMax: -37.0, zMin: -6.7, zMax: -3.8, y: F2, floor: 'wood', density: 0.8 },
  { id: 'box', xMin: -41.7, xMax: -37.0, zMin: -10.7, zMax: -7.3, y: F2, floor: 'wood', density: 1.2 },
  { id: 'bed5', xMin: -26.3, xMax: -20.5, zMin: -2.2, zMax: 2.7, y: F2, floor: 'wood', density: 1.0 },
  { id: 'bath', xMin: -26.3, xMax: -20.5, zMin: -5.7, zMax: -2.8, y: F2, floor: 'concrete', density: 0.9 },
  { id: 'bed6', xMin: -26.3, xMax: -20.5, zMin: -10.7, zMax: -6.3, y: F2, floor: 'wood', density: 0.8 },
]

import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials, floorGeometry } from './materials'
import { HX, HZ } from './layout'

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function Trees() {
  const trunkMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#3a2e24', roughness: 1 }), [])
  const leafMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#3f4a2d', roughness: 1 }), [])
  const trees = useMemo(() => {
    const rnd = mulberry(42)
    const arr: { x: number; z: number; h: number; r: number }[] = []
    for (let i = 0; i < 70; i++) {
      const a = rnd() * Math.PI * 2
      const d = 34 + rnd() * 40
      const x = Math.cos(a) * d - 11
      const z = Math.sin(a) * d
      if (x > -47 && x < 25 && Math.abs(z) < 16) continue
      arr.push({ x, z, h: 5 + rnd() * 6, r: 1.6 + rnd() * 1.8 })
    }
    return arr
  }, [])
  return (
    <group>
      {trees.map((t, i) => (
        <group key={i} position={[t.x, 0, t.z]}>
          <mesh position={[0, t.h * 0.3, 0]} material={trunkMat} castShadow>
            <cylinderGeometry args={[0.18, 0.3, t.h * 0.6, 7]} />
          </mesh>
          <mesh position={[0, t.h * 0.55, 0]} material={leafMat} castShadow>
            <coneGeometry args={[t.r, t.h * 0.6, 8]} />
          </mesh>
          <mesh position={[0, t.h * 0.8, 0]} material={leafMat} castShadow>
            <coneGeometry args={[t.r * 0.7, t.h * 0.5, 8]} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

function JunkCar({ p, rot }: { p: [number, number, number]; rot: number }) {
  const m = useMaterials()
  const body = useMemo(() => new THREE.MeshStandardMaterial({ color: '#6b6a62', roughness: 0.8, metalness: 0.3 }), [])
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <mesh position={[0, 0.55, 0]} material={body} castShadow receiveShadow>
        <boxGeometry args={[4.2, 0.7, 1.8]} />
      </mesh>
      <mesh position={[-0.2, 1.15, 0]} material={m.rust} castShadow receiveShadow>
        <boxGeometry args={[2.2, 0.6, 1.6]} />
      </mesh>
      {[-1.4, 1.4].map((x) =>
        [-0.95, 0.95].map((z) => (
          <mesh key={`${x}${z}`} position={[x, 0.32, z]} rotation={[Math.PI / 2, 0, 0]} material={m.black} castShadow>
            <torusGeometry args={[0.26, 0.1, 8, 18]} />
          </mesh>
        )),
      )}
    </group>
  )
}

function OutsideContainer({ p, rot, mat }: { p: [number, number, number]; rot: number; mat: THREE.Material }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <mesh position={[0, 1.3, 0]} material={mat} castShadow receiveShadow>
        <boxGeometry args={[6.06, 2.4, 2.44]} />
      </mesh>
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => (
          <mesh key={`${sx}${sz}`} position={[sx * 2.95, 1.3, sz * 1.21]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.16, 2.6, 0.2]} />
          </mesh>
        )),
      )}
    </group>
  )
}

export function Exterior() {
  const m = useMaterials()
  const ground = useMemo(() => floorGeometry(220, 220, 0, 0), [])
  const apron = useMemo(() => floorGeometry(66, 16, -9, HZ + 8), [])
  const apronE = useMemo(() => floorGeometry(10, HZ * 2, HX + 5, 0), [])
  return (
    <group>
      <mesh geometry={ground} material={m.ground} position={[0, -0.015, 0]} receiveShadow />
      <mesh geometry={apron} material={m.concreteFloor} position={[-9, -0.004, HZ + 8]} receiveShadow />
      <mesh geometry={apronE} material={m.concreteFloor} position={[HX + 5, -0.004, 0]} receiveShadow />
      <Trees />
      <JunkCar p={[-4, 0, 19]} rot={0.4} />
      <OutsideContainer p={[11, 0, 18.5]} rot={0.25} mat={m.corrugatedRed} />
      <OutsideContainer p={[11.4, 2.4, 18.3]} rot={0.2} mat={m.corrugatedBlue} />
      <OutsideContainer p={[-50, 0, -6]} rot={1.45} mat={m.rust} />
      {/* loading dock bumpers & drums */}
      {[-14, -2, 8].map((x) => (
        <mesh key={x} position={[x, 0.5, HZ + 0.35]} material={m.black} castShadow>
          <boxGeometry args={[0.4, 0.5, 0.3]} />
        </mesh>
      ))}
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[16 + i * 0.7, 0.45, HZ + 2 + (i % 2) * 0.5]} material={i === 1 ? m.plasticBlue : m.rust} castShadow receiveShadow>
          <cylinderGeometry args={[0.3, 0.3, 0.9, 20]} />
        </mesh>
      ))}
      {/* fence remains along the west */}
      {Array.from({ length: 14 }).map((_, i) => (
        <mesh key={i} position={[-46, 0.7, -14 + i * 2.2]} rotation={[(i % 3) * 0.06, 0, (i % 2) * 0.08]} material={m.steelDark} castShadow>
          <boxGeometry args={[0.08, 1.4, 0.08]} />
        </mesh>
      ))}
      <mesh position={[-46, 1.3, 0.3]} material={m.steelDark} castShadow>
        <boxGeometry args={[0.04, 0.06, 30]} />
      </mesh>
      {/* rubble around the building */}
      {Array.from({ length: 40 }).map((_, i) => {
        const a = (i / 40) * Math.PI * 2
        const r = 1.6 + (i % 4) * 0.7
        const px = -11 + Math.cos(a) * (32 + r)
        const pz = Math.sin(a) * (HZ + 1 + r)
        if (px > -43 && px < 21 && pz > -12.5 && pz < 12.5) return null
        return (
          <mesh key={i} position={[px, 0.08, pz]} rotation={[0, a, 0]} material={m.cinder} castShadow receiveShadow>
            <boxGeometry args={[0.39, 0.19, 0.19]} />
          </mesh>
        )
      })}
    </group>
  )
}

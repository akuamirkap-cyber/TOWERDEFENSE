// Procedural audio: footsteps + wind ambience (no external files)
let ctx: AudioContext | null = null
let master: GainNode | null = null
let noiseBuf: AudioBuffer | null = null

function ensure() {
  if (ctx) return ctx
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  ctx = new AC()
  master = ctx.createGain()
  master.gain.value = 0.8
  master.connect(ctx.destination)
  // 2 seconds of white noise
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate)
  const d = noiseBuf.getChannelData(0)
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
  startAmbience()
  return ctx
}

export function initAudio() {
  const c = ensure()
  if (c.state === 'suspended') void c.resume()
}

function startAmbience() {
  if (!ctx || !master || !noiseBuf) return
  // wind: looping noise -> lowpass with slow LFO
  const src = ctx.createBufferSource()
  src.buffer = noiseBuf
  src.loop = true
  const lp = ctx.createBiquadFilter()
  lp.type = 'lowpass'
  lp.frequency.value = 320
  lp.Q.value = 0.8
  const g = ctx.createGain()
  g.gain.value = 0.045
  const lfo = ctx.createOscillator()
  lfo.frequency.value = 0.07
  const lfoG = ctx.createGain()
  lfoG.gain.value = 180
  lfo.connect(lfoG)
  lfoG.connect(lp.frequency)
  const lfo2 = ctx.createOscillator()
  lfo2.frequency.value = 0.19
  const lfo2G = ctx.createGain()
  lfo2G.gain.value = 0.02
  lfo2.connect(lfo2G)
  lfo2G.connect(g.gain)
  src.connect(lp)
  lp.connect(g)
  g.connect(master)
  src.start()
  lfo.start()
  lfo2.start()
  // low room tone
  const hum = ctx.createOscillator()
  hum.type = 'sine'
  hum.frequency.value = 48
  const humG = ctx.createGain()
  humG.gain.value = 0.012
  hum.connect(humG)
  humG.connect(master)
  hum.start()
}

export function footstep(surface: 'wood' | 'concrete', strength = 1) {
  if (!ctx || !master || !noiseBuf) return
  const t = ctx.currentTime
  const src = ctx.createBufferSource()
  src.buffer = noiseBuf
  src.playbackRate.value = 0.8 + Math.random() * 0.5
  const bp = ctx.createBiquadFilter()
  bp.type = surface === 'wood' ? 'lowpass' : 'bandpass'
  bp.frequency.value = surface === 'wood' ? 420 + Math.random() * 200 : 1100 + Math.random() * 600
  bp.Q.value = surface === 'wood' ? 0.9 : 1.6
  const g = ctx.createGain()
  const peak = (surface === 'wood' ? 0.32 : 0.22) * strength
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(peak, t + 0.008)
  g.gain.exponentialRampToValueAtTime(0.0001, t + (surface === 'wood' ? 0.17 : 0.11))
  src.connect(bp)
  bp.connect(g)
  g.connect(master)
  src.start(t)
  src.stop(t + 0.25)
  // heel thud
  const osc = ctx.createOscillator()
  osc.frequency.setValueAtTime(surface === 'wood' ? 95 : 70, t)
  osc.frequency.exponentialRampToValueAtTime(40, t + 0.09)
  const og = ctx.createGain()
  og.gain.setValueAtTime(0.0001, t)
  og.gain.exponentialRampToValueAtTime(0.18 * strength, t + 0.006)
  og.gain.exponentialRampToValueAtTime(0.0001, t + 0.1)
  osc.connect(og)
  og.connect(master)
  osc.start(t)
  osc.stop(t + 0.12)
  // wood creak occasionally
  if (surface === 'wood' && Math.random() < 0.18) {
    const c = ctx.createOscillator()
    c.type = 'sawtooth'
    c.frequency.setValueAtTime(180 + Math.random() * 120, t + 0.02)
    c.frequency.linearRampToValueAtTime(120 + Math.random() * 80, t + 0.22)
    const cf = ctx.createBiquadFilter()
    cf.type = 'bandpass'
    cf.frequency.value = 600
    cf.Q.value = 4
    const cg = ctx.createGain()
    cg.gain.setValueAtTime(0.0001, t + 0.02)
    cg.gain.exponentialRampToValueAtTime(0.05, t + 0.06)
    cg.gain.exponentialRampToValueAtTime(0.0001, t + 0.26)
    c.connect(cf)
    cf.connect(cg)
    cg.connect(master)
    c.start(t + 0.02)
    c.stop(t + 0.3)
  }
}

export function clickSound() {
  if (!ctx || !master) return
  const t = ctx.currentTime
  const osc = ctx.createOscillator()
  osc.type = 'square'
  osc.frequency.value = 1800
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(0.06, t + 0.003)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.04)
  osc.connect(g)
  g.connect(master)
  osc.start(t)
  osc.stop(t + 0.05)
}

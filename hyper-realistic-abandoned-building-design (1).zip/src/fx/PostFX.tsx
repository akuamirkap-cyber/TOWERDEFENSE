import { useMemo } from 'react'
import { EffectComposer, Bloom, ToneMapping, N8AO } from '@react-three/postprocessing'
import { ToneMappingMode } from 'postprocessing'
import { BodycamEffectImpl } from './BodycamEffect'
import type { Texture } from 'three'

export function PostFX({ dirt }: { dirt: Texture }) {
  const bodycam = useMemo(
    () =>
      new BodycamEffectImpl({
        distortion: 0.28,
        aberration: 1.1,
        edgeBlur: 1.0,
        vignetteStart: 0.6,
        vignetteEnd: 1.15,
        grain: 0.06,
        sharpen: 0.3,
        dirt,
        dirtAmount: 0.3,
      }),
    [dirt],
  )
  return (
    <EffectComposer mergeMode="none" multisampling={4}>
      <N8AO aoRadius={1.0} intensity={2.2} distanceFalloff={0.8} quality="medium" halfRes />
      <Bloom luminanceThreshold={1.05} luminanceSmoothing={0.25} intensity={0.35} mipmapBlur radius={0.6} levels={6} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <primitive object={bodycam} />
    </EffectComposer>
  )
}

import { Uniform, Vector2, Texture } from 'three'
import { BlendFunction, Effect, EffectAttribute } from 'postprocessing'

const fragment = /* glsl */ `
uniform float distortion;
uniform float aberration;
uniform float edgeBlur;
uniform float vignetteStart;
uniform float vignetteEnd;
uniform float grain;
uniform float sharpen;
uniform vec2 jitter;
uniform sampler2D dirtTex;
uniform float dirtAmount;

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

vec2 distortUv(vec2 uv, float k) {
  vec2 c = uv - 0.5;
  c.x *= aspect;
  float r2 = dot(c, c);
  float f = 1.0 + k * r2 + k * 0.6 * r2 * r2;
  // normalise so the horizontal edge midpoints stay close to the frame
  float re = 0.25 * aspect * aspect;
  float fn = 1.0 + k * re + k * 0.6 * re * re;
  c *= f / fn;
  c.x /= aspect;
  return c + 0.5;
}

vec3 sampleScene(vec2 uv) {
  return texture2D(inputBuffer, uv).rgb;
}

void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  vec2 cc = uv - 0.5;
  cc.x *= aspect;
  float r = length(cc);
  vec2 dir = r > 1e-5 ? cc / r : vec2(0.0);

  // lens distortion
  vec2 duv = distortUv(uv + jitter * texelSize, distortion);

  // radial chromatic aberration (stronger at edges)
  float ca = aberration * (r * r) * 0.0045;
  vec2 caOff = vec2(dir.x / aspect, dir.y) * ca;

  // edge softness: blur radius grows with r
  float blurAmt = edgeBlur * smoothstep(0.35, 1.0, r);
  vec2 px = texelSize * (1.0 + blurAmt * 5.0);

  vec3 col = vec3(0.0);
  vec3 ctr = vec3(
    sampleScene(duv + caOff).r,
    sampleScene(duv).g,
    sampleScene(duv - caOff).b
  );
  if (blurAmt > 0.001) {
    vec3 acc = ctr * 2.0;
    float wsum = 2.0;
    for (int i = 0; i < 8; i++) {
      float a = float(i) * 0.785398;
      vec2 o = vec2(cos(a), sin(a)) * px;
      vec3 s = vec3(
        sampleScene(duv + o + caOff).r,
        sampleScene(duv + o).g,
        sampleScene(duv + o - caOff).b
      );
      acc += s;
      wsum += 1.0;
    }
    col = acc / wsum;
  } else {
    col = ctr;
  }

  // mild unsharp mask in the centre (digital camera look)
  if (sharpen > 0.0 && blurAmt < 0.5) {
    vec3 n = sampleScene(duv + vec2(texelSize.x, 0.0)) + sampleScene(duv - vec2(texelSize.x, 0.0)) + sampleScene(duv + vec2(0.0, texelSize.y)) + sampleScene(duv - vec2(0.0, texelSize.y));
    col += (col - n * 0.25) * sharpen * (1.0 - blurAmt * 2.0);
  }

  // outside of the lens image circle -> black
  vec2 outside = step(vec2(1.0), abs(duv - 0.5) * 2.0);
  float oob = max(outside.x, outside.y);
  col = mix(col, vec3(0.0), oob);

  // vignette (optical + mechanical)
  float v = 1.0 - smoothstep(vignetteStart, vignetteEnd, r);
  v = pow(v, 1.4);
  col *= mix(0.0, 1.0, v);

  // lens dirt catching light from bright areas
  float lum = dot(col, vec3(0.299, 0.587, 0.114));
  float dirt = texture2D(dirtTex, uv).r;
  col += dirt * smoothstep(0.45, 1.0, lum) * dirtAmount * vec3(1.0, 0.97, 0.9);

  // sensor grain (stronger in shadows)
  float n1 = hash12(uv * resolution + vec2(time * 61.0, time * 37.0));
  float n2 = hash12(uv * resolution * 0.5 + vec2(time * 17.0, -time * 29.0));
  float g = (n1 - 0.5) * 0.7 + (n2 - 0.5) * 0.3;
  col += g * grain * (0.35 + (1.0 - lum) * 0.9);

  // slight compression-like colour desaturation in darks, subtle lift
  col = max(col, vec3(0.0));
  col = col * 0.97 + vec3(0.012, 0.013, 0.014);

  outputColor = vec4(col, inputColor.a);
}
`

export interface BodycamOptions {
  distortion?: number
  aberration?: number
  edgeBlur?: number
  vignetteStart?: number
  vignetteEnd?: number
  grain?: number
  sharpen?: number
  dirt?: Texture | null
  dirtAmount?: number
}

export class BodycamEffectImpl extends Effect {
  constructor({
    distortion = 0.32,
    aberration = 1.0,
    edgeBlur = 1.0,
    vignetteStart = 0.55,
    vignetteEnd = 1.05,
    grain = 0.065,
    sharpen = 0.35,
    dirt = null,
    dirtAmount = 0.35,
  }: BodycamOptions = {}) {
    super('BodycamEffect', fragment, {
      blendFunction: BlendFunction.SRC,
      attributes: EffectAttribute.CONVOLUTION,
      uniforms: new Map<string, Uniform>([
        ['distortion', new Uniform(distortion)],
        ['aberration', new Uniform(aberration)],
        ['edgeBlur', new Uniform(edgeBlur)],
        ['vignetteStart', new Uniform(vignetteStart)],
        ['vignetteEnd', new Uniform(vignetteEnd)],
        ['grain', new Uniform(grain)],
        ['sharpen', new Uniform(sharpen)],
        ['jitter', new Uniform(new Vector2())],
        ['dirtTex', new Uniform(dirt)],
        ['dirtAmount', new Uniform(dirtAmount)],
      ]),
    })
  }

  setParam(name: string, value: number) {
    const u = this.uniforms.get(name)
    if (u) u.value = value
  }
}

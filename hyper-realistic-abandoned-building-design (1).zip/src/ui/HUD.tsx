import { useEffect, useState } from 'react'
import { useGame } from '../state'

function pad(n: number) {
  return n.toString().padStart(2, '0')
}

export function HUD() {
  const locked = useGame((s) => s.locked)
  const flashlight = useGame((s) => s.flashlight)
  const sprint = useGame((s) => s.sprint)
  const crouch = useGame((s) => s.crouch)
  const floor = useGame((s) => s.floor)
  const px = useGame((s) => s.px)
  const pz = useGame((s) => s.pz)
  const heading = useGame((s) => s.heading)
  const exposure = useGame((s) => s.exposure)
  const [now, setNow] = useState(() => new Date())
  const [blink, setBlink] = useState(true)
  const [showHelp, setShowHelp] = useState(true)

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    const b = setInterval(() => setBlink((v) => !v), 700)
    return () => {
      clearInterval(t)
      clearInterval(b)
    }
  }, [])

  useEffect(() => {
    if (!locked) return
    setShowHelp(true)
    const t = setTimeout(() => setShowHelp(false), 9000)
    return () => clearTimeout(t)
  }, [locked])

  const date = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
  const time = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`
  const compass = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(heading / 45) % 8]

  return (
    <div className="pointer-events-none absolute inset-0 font-mono text-[11px] tracking-[0.18em] text-white/85 uppercase">
      {/* scanline film layer */}
      <div className="hud-scan absolute inset-0" />
      {/* corner frame marks */}
      <div className="absolute top-6 left-6 h-8 w-8 border-t border-l border-white/40" />
      <div className="absolute top-6 right-6 h-8 w-8 border-t border-r border-white/40" />
      <div className="absolute bottom-6 left-6 h-8 w-8 border-b border-l border-white/40" />
      <div className="absolute bottom-6 right-6 h-8 w-8 border-b border-r border-white/40" />

      {/* top-left: REC */}
      <div className="absolute top-9 left-10 flex flex-col gap-1 drop-shadow-[0_0_4px_rgba(0,0,0,0.9)]">
        <div className="flex items-center gap-2 text-[13px]">
          <span className={`inline-block h-3 w-3 rounded-full ${blink ? 'bg-red-500 shadow-[0_0_10px_rgba(255,0,0,0.9)]' : 'bg-red-900'}`} />
          <span className="font-bold">REC</span>
          <span className="text-white/60">{time}</span>
        </div>
        <div className="text-white/60">AXON BODY 3 · CAM-07 · 1080P/30</div>
        <div className="text-white/50">
          {sprint ? 'MOTION: HIGH' : crouch ? 'MOTION: LOW' : 'MOTION: STABLE'} {flashlight ? '· IR/LED ON' : ''}
        </div>
      </div>

      {/* top-right: date & battery */}
      <div className="absolute top-9 right-10 flex flex-col items-end gap-1 drop-shadow-[0_0_4px_rgba(0,0,0,0.9)]">
        <div className="text-[13px]">{date}</div>
        <div className="flex items-center gap-2 text-white/70">
          <span>BATT</span>
          <span className="flex h-3 w-8 items-center gap-[2px] border border-white/60 p-[1px]">
            <span className="h-full flex-1 bg-white/80" />
            <span className="h-full flex-1 bg-white/80" />
            <span className="h-full flex-1 bg-white/80" />
            <span className="h-full flex-1 bg-white/15" />
          </span>
          <span>74%</span>
        </div>
        <div className="text-white/50">GPS LOCK · {px.toFixed(1)}E {(-pz).toFixed(1)}N</div>
      </div>

      {/* bottom-left: unit info */}
      <div className="absolute bottom-9 left-10 flex flex-col gap-1 drop-shadow-[0_0_4px_rgba(0,0,0,0.9)]">
        <div className="text-white/80">UNIT 2291 · OFFICER R. MENDEZ</div>
        <div className="text-white/55">
          {floor === 2 ? 'UPPER LVL' : 'GROUND LVL'} · HDG {heading.toString().padStart(3, '0')}° {compass} · EXP {exposure.toFixed(2)}
        </div>
        <div className="text-white/40">SITE 14 · ELKRIDGE INDUSTRIAL PLANT · HALL B</div>
      </div>

      {/* bottom-right: logo */}
      <div className="absolute bottom-8 right-10 flex flex-col items-end drop-shadow-[0_0_6px_rgba(0,0,0,0.9)]">
        <div className="bodycam-logo text-[26px] font-black leading-none tracking-[0.02em]">
          <span className="text-white/90">[</span>BODY<span className="text-red-500">CAM</span>
          <span className="text-white/90">]</span>
        </div>
        <div className="text-[9px] text-white/50">EVIDENCE RECORDING · DO NOT DISTRIBUTE</div>
      </div>

      {/* controls hint */}
      {locked && (
        <div
          className={`absolute bottom-24 left-1/2 -translate-x-1/2 rounded-sm border border-white/20 bg-black/40 px-4 py-2 text-center text-[10px] text-white/70 transition-opacity duration-1000 ${
            showHelp ? 'opacity-100' : 'opacity-0'
          }`}
        >
          WASD gerak · SPASI loncat · SHIFT lari · C jongkok · F senter · ESC lepas mouse
        </div>
      )}
    </div>
  )
}

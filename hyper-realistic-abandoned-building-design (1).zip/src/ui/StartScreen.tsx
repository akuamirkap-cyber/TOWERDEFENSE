import { useGame } from '../state'

export function StartScreen({ progress, ready }: { progress: number; ready: boolean }) {
  const locked = useGame((s) => s.locked)
  const everStarted = useGame((s) => s.everStarted)
  if (locked) return null
  const pct = Math.round(progress * 100)
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/55 font-mono text-white">
      <div className="relative mx-6 w-full max-w-xl border border-white/15 bg-black/70 px-8 py-8 shadow-[0_0_60px_rgba(0,0,0,0.8)] backdrop-blur-[2px]">
        <div className="absolute -top-px left-6 h-px w-16 bg-red-500" />
        <div className="text-[10px] tracking-[0.35em] text-red-400 uppercase">Evidence file · body worn camera</div>
        <h1 className="mt-2 text-3xl font-black tracking-tight uppercase">
          Abandoned <span className="text-white/40">//</span> <span className="text-red-500">Bodycam</span>
        </h1>
        <p className="mt-3 text-[12px] leading-relaxed text-white/60">
          Rumah manajer dua lantai yang ditinggalkan — hall dengan tangga baluster putih, graffiti, lantai kayu, 19
          ruangan (ruang tamu, perpustakaan, dapur, kamar-kamar, kamar mandi, kamar yang atapnya runtuh) — menempel pada
          hall pabrik 40×24 m dengan mezzanine, catwalk dan atap yang jebol. Jelajahi sebagai kamera-man.
        </p>

        {!ready ? (
          <div className="mt-6">
            <div className="flex justify-between text-[10px] tracking-[0.3em] text-white/50 uppercase">
              <span>Memproses texture & normal map</span>
              <span>{pct}%</span>
            </div>
            <div className="mt-2 h-[3px] w-full bg-white/10">
              <div className="h-full bg-red-500 transition-all duration-200" style={{ width: `${pct}%` }} />
            </div>
          </div>
        ) : (
          <div className="mt-6">
            <div className="animate-pulse text-center text-sm font-bold tracking-[0.3em] uppercase">
              {everStarted ? '▌▌ Paused — klik untuk lanjut' : '● Klik layar untuk mulai merekam'}
            </div>
            <div className="mt-5 grid grid-cols-2 gap-x-6 gap-y-1 text-[11px] text-white/60">
              <div>
                <span className="text-white">WASD</span> — bergerak
              </div>
              <div>
                <span className="text-white">MOUSE</span> — lihat sekeliling
              </div>
              <div>
                <span className="text-white">SPASI</span> — loncat
              </div>
              <div>
                <span className="text-white">SHIFT</span> — lari
              </div>
              <div>
                <span className="text-white">C</span> — jongkok
              </div>
              <div>
                <span className="text-white">F</span> — senter (ruangan gelap)
              </div>
              <div>
                <span className="text-white">ESC</span> — lepas kursor
              </div>
            </div>
            <div className="mt-5 text-[10px] tracking-[0.25em] text-white/35 uppercase">
              Tip: kamu mulai di hall rumah. Pintu belakang / ruang boot menuju hall pabrik; lantai 2 rumah tersambung ke mezzanine pabrik.
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
